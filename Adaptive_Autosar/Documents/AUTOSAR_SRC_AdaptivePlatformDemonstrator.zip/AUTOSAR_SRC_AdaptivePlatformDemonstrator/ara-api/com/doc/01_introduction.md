Introduction {#introduction}
============================

This document describes the design (approach and decisions) of the Functional Cluster Communication Management for AUTOSAR's Adaptive Platform Demonstrator.

The decisions taken for the AUTOSAR Adaptive Platform Demonstrator may not apply other implementations as the standard is defined by the specifications. Nevertheless, the Demonstrator may supplement and ease the understanding of the specifications.

# Known limitations {#known_limitations}

This is the list of limitations the reference implementation currently has:

* *No common receive pool for events and fields.* The middleware specification obviously expects a common pool of
  received data per event/field. All instantiated proxies then take shared ownership for all data that is valid for
  their specific caching strategy.

* *No proper implementation of `ara::com::InstanceIdentifier`.* The specification requires
  `ara::com::InstanceIdentifier` to be convertible to/from an `ara::core::String`. This might be implemented by either having
  a service directory or a canonical form per binding that can be used to resolve the required instance.

* *The SOME/IP id value of `0xFFFE` cannot be configured in the deployment of Events and Methods (implementation-reserved).* The limitation comes from the current design of offering all possible Field combinations (getter, setter, notifier).

Additionally, the following features are part of the specification but are not implemented yet in the demonstrator:

* DDS methods, fields and data serialization/deserialization.
* Communication APIs that makes use of ara::core::InstanceSpecifier.
* Exception-less APIs.
* SOME/IP structured datatypes and arguments with identifier and optional members.

# Deviations from specification {#spec_deviations}

The actual demonstrator implementation has the following deviations from the specification:

*Application Error*
- The implementation of Application Error for method communication is still based on release 18-03. 

*Event Handling*
- The implementation of Event APIs on receiver side is still based on release 18-10.

*Basic types*
- float32 and float64 are not serialised in IEEE754 format
- no byte order unification but pure dump into the serialisation stream

*Struct data types*
- attribute sizeOfStruct is not written into the output stream
- attribute sizeOfStructLengthFields is ignored

*Strings*
- BOM is not written and not checked against the model value
- string termination ('\0') is not written.
- unicode encoding not supported
- check on size of string depending on encoding (eg UTF-16LE and UTF-16BE strings shall have an even length) not supported
- no padding of unused memory in the serialiser with 0
- network byte order conversion between UTF-16LE and UTF16-BE not supported
- fixed length strings and dynamic strings are treated the same (ara::core::String)
- string size from the model is ignored

*Fixed-length strings*
- size of string is always written
- size of string is read as len when parsing, and then len chars are read
- no '\0'-terminator expected

*Dynamic-length strings*
- size of string assumes 1 byte per character

*Arrays*
- size is always written (no difference between fixed and dynamic length)
- size indicates number of elements, not size in bytes
- attribute sizeOfArrayLengthField is ignored (written size is always 32 bits)
- model is not queried for size of fixed-length arrays
- no support for optional elements/parameters

*Union*
- serialization of unions is not supported
- unions should be serialised with length (if sizeOfUnionLengthFields > 0), type and element field

*Maps, Unordered Maps, Sets, Unordered Sets*
- AUTOSAR_SWS_SOMEIPTransformer doesn't specify maps, set, unordered_map and unordered_set
- elements of type 'map' and 'unordered_map' are serialized like a vector of 2 values (vector of pair)
- elements of type 'set' and 'unordered_set' are serialized like a vector of a single value
- duplicated keys are read from the serialized stream and only the first value is taken, the next ones are ignored


