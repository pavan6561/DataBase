// --------------------------------------------------------------------------
// |              _    _ _______     .----.      _____         _____        |
// |         /\  | |  | |__   __|  .  ____ .    / ____|  /\   |  __ \       |
// |        /  \ | |  | |  | |    .  / __ \ .  | (___   /  \  | |__) |      |
// |       / /\ \| |  | |  | |   .  / / / / v   \___ \ / /\ \ |  _  /       |
// |      / /__\ \ |__| |  | |   . / /_/ /  .   ____) / /__\ \| | \ \       |
// |     /________\____/   |_|   ^ \____/  .   |_____/________\_|  \_\      |
// |                              . _ _  .                                  |
// --------------------------------------------------------------------------
//
// All Rights Reserved.
// Any use of this source code is subject to a license agreement with the
// AUTOSAR development cooperation.
// More information is available at www.autosar.org.
//
// Disclaimer
//
// This work (specification and/or software implementation) and the material
// contained in it, as released by AUTOSAR, is for the purpose of information
// only. AUTOSAR and the companies that have contributed to it shall not be
// liable for any use of the work.
//
// The material contained in this work is protected by copyright and other
// types of intellectual property rights. The commercial exploitation of the
// material contained in this work requires a license to such intellectual
// property rights.
//
// This work may be utilized or reproduced without any modification, in any
// form or by any means, for informational purposes only. For any other
// purpose, no part of the work may be utilized or reproduced, in any form
// or by any means, without permission in writing from the publisher.
//
// The work has been developed for automotive applications only. It has
// neither been developed, nor tested for non-automotive applications.
//
// The word AUTOSAR and the AUTOSAR logo are registered trademarks.
// --------------------------------------------------------------------------

#ifndef ARA_DDS_BINDING_INCLUDES_LIBARA_INTERNAL_DDS_SKELETON_MUTABLE_FIELD_IMPL_H_
#define ARA_DDS_BINDING_INCLUDES_LIBARA_INTERNAL_DDS_SKELETON_MUTABLE_FIELD_IMPL_H_

#include <functional>

#include "ara/com/internal/skeleton/mutable_field.h"
#include "ara/com/illegal_state_exception.h"
#include "ara/com/internal/dds/types.h"
#include "ara/com/internal/dds/common.h"

#include "field_impl.h"

namespace ara
{
namespace com
{
namespace internal
{
namespace dds
{
namespace skeleton
{

/// \brief Mutable field implementation for Skeleton service interface
template <typename T, typename FieldDescriptor>
class MutableFieldImpl
    : public internal::skeleton::MutableField<T>
    , public FieldImpl<T, FieldDescriptor>
{
public:
    using Base = FieldImpl<T, FieldDescriptor>;
    using typename internal::skeleton::MutableField<T>::SetMethodSignature;

    explicit MutableFieldImpl(types::InstanceId instance)
        : FieldImpl<T, FieldDescriptor>(instance)
    {}

    /// \uptrace{SWS_CM_00116}
    virtual void RegisterSetHandler(std::function<SetMethodSignature> handler) override
    {
        Base::PutHandler(set_handler_, std::move(handler));
    }

private:
    std::function<SetMethodSignature> set_handler_;

    /// \brief  This function handles a Set() call from the client.
    /// \param msg The message contains the data the value of the field shall be set to.
    void handleSet(const std::shared_ptr<::dds::message>& msg)
    {}
};

}  // namespace skeleton
}  // namespace dds
}  // namespace internal
}  // namespace com
}  // namespace ara

#endif  // ARA_DDS_BINDING_INCLUDES_LIBARA_INTERNAL_DDS_SKELETON_MUTABLE_FIELD_IMPL_H_
