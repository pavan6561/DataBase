// --------------------------------------------------------------------------
// |              _    _ _______     .----.      _____         _____        |
// |         /\  | |  | |__   __|  .  ____ .    / ____|  /\   |  __ \       |
// |        /  \ | |  | |  | |    .  / __ \ .  | (___   /  \  | |__) |      |
// |       / /\ \| |  | |  | |   .  / / / / v   \___ \ / /\ \ |  _  /       |
// |      / /__\ \ |__| |  | |   . / /_/ /  .   ____) / /__\ \| | \ \       |
// |     /________\____/   |_|   ^ \____/  .   |_____/________\_|  \_\      |
// |                              . _ _  .                                  |
// --------------------------------------------------------------------------
//
// All Rights Reserved.
// Any use of this source code is subject to a license agreement with the
// AUTOSAR development cooperation.
// More information is available at www.autosar.org.
//
// Disclaimer
//
// This work (specification and/or software implementation) and the material
// contained in it, as released by AUTOSAR, is for the purpose of information
// only. AUTOSAR and the companies that have contributed to it shall not be
// liable for any use of the work.
//
// The material contained in this work is protected by copyright and other
// types of intellectual property rights. The commercial exploitation of the
// material contained in this work requires a license to such intellectual
// property rights.
//
// This work may be utilized or reproduced without any modification, in any
// form or by any means, for informational purposes only. For any other
// purpose, no part of the work may be utilized or reproduced, in any form
// or by any means, without permission in writing from the publisher.
//
// The work has been developed for automotive applications only. It has
// neither been developed, nor tested for non-automotive applications.
//
// The word AUTOSAR and the AUTOSAR logo are registered trademarks.
// --------------------------------------------------------------------------

#ifndef COMMUNICATIONMIDDLEWARE_PROLOC_PROXY_FACTORY_IMPL_H
#define COMMUNICATIONMIDDLEWARE_PROLOC_PROXY_FACTORY_IMPL_H

#include <memory>

#include "ara/com/types.h"
#include "ara/com/instance_identifier.h"
#include "ara/com/internal/proxy/proxy_factory.h"
#include "ara/com/internal/skeleton/service_base.h"
#include "ara/com/internal/proxy/proxy_binding_base.h"

namespace ara
{
namespace com
{
namespace internal
{
namespace proloc
{
namespace runtime
{

template <typename ProxyImpl>
class ProxyFactoryImpl : public internal::proxy::ProxyFactory
{
public:
    ProxyFactoryImpl(std::weak_ptr<internal::proloc::skeleton::ServiceImplBase> service)
        : ProxyFactory(0)
        , service_(service)
    {
    }

    std::unique_ptr<internal::proxy::ProxyBindingBase> Create() const override
    {
        return std::make_unique<ProxyImpl>(service_, 0);
    }

    /**
     * \brief Copy assignment operator.
     * \uptrace{SWS_CM_00312}
     *
     * \param other ProxyFactoryImpl to assign from.
     *
     * \return reference to this handle.
     */
    ProxyFactoryImpl& operator=(const ProxyFactoryImpl& other)
    {
        SetInstanceIdentifier(other.GetInstanceIdentifier());
        service_ = other.service_;
        return *this;
    }

private:
    std::weak_ptr<internal::proloc::skeleton::ServiceImplBase> service_;
};

}  // namespace runtime
}  // namespace proloc
}  // namespace internal
}  // namespace com
}  // namespace ara

#endif  // COMMUNICATIONMIDDLEWARE_PROLOC_PROXY_FACTORY_IMPL_H
