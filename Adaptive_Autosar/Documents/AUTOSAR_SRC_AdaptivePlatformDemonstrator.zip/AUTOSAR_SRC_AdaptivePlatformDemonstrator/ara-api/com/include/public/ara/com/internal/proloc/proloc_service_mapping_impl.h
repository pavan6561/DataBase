// --------------------------------------------------------------------------
// |              _    _ _______     .----.      _____         _____        |
// |         /\  | |  | |__   __|  .  ____ .    / ____|  /\   |  __ \       |
// |        /  \ | |  | |  | |    .  / __ \ .  | (___   /  \  | |__) |      |
// |       / /\ \| |  | |  | |   .  / / / / v   \___ \ / /\ \ |  _  /       |
// |      / /__\ \ |__| |  | |   . / /_/ /  .   ____) / /__\ \| | \ \       |
// |     /________\____/   |_|   ^ \____/  .   |_____/________\_|  \_\      |
// |                              . _ _  .                                  |
// --------------------------------------------------------------------------
//
// All Rights Reserved.
// Any use of this source code is subject to a license agreement with the
// AUTOSAR development cooperation.
// More information is available at www.autosar.org.
//
// Disclaimer
//
// This work (specification and/or software implementation) and the material
// contained in it, as released by AUTOSAR, is for the purpose of information
// only. AUTOSAR and the companies that have contributed to it shall not be
// liable for any use of the work.
//
// The material contained in this work is protected by copyright and other
// types of intellectual property rights. The commercial exploitation of the
// material contained in this work requires a license to such intellectual
// property rights.
//
// This work may be utilized or reproduced without any modification, in any
// form or by any means, for informational purposes only. For any other
// purpose, no part of the work may be utilized or reproduced, in any form
// or by any means, without permission in writing from the publisher.
//
// The work has been developed for automotive applications only. It has
// neither been developed, nor tested for non-automotive applications.
//
// The word AUTOSAR and the AUTOSAR logo are registered trademarks.
// --------------------------------------------------------------------------

#ifndef COMMUNICATIONMIDDLEWARE_PROLOC_SERVICE_MAPPING_IMPL_H
#define COMMUNICATIONMIDDLEWARE_PROLOC_SERVICE_MAPPING_IMPL_H

#include "proloc_service_mapping.h"
#include "proloc_proxy_factory_impl.h"
#include "skeleton/proloc_service_impl_base.h"

namespace ara
{
namespace com
{
namespace internal
{
namespace proloc
{
namespace runtime
{

template <typename Adapter>
struct AdapterBuilder
{
    std::unique_ptr<Adapter> make(internal::skeleton::ServiceBase& service, InstanceId instance_id)
    {
        typename Adapter::ServiceInterface& interface = dynamic_cast<typename Adapter::ServiceInterface&>(service);
        std::unique_ptr<Adapter> adapter = std::make_unique<Adapter>(interface, instance_id);
        return adapter;
    }
};

template <typename ProxyType>
struct ProxyBuilder
{
    std::shared_ptr<internal::proxy::ProxyFactory> make(
        std::weak_ptr<internal::proloc::skeleton::ServiceImplBase> service)
    {
        return std::make_shared<ProxyFactoryImpl<ProxyType>>(service);
    }
};

template <ServiceId ARACOMServiceId, typename ProxyType, typename SkeletonType>
class ServiceMappingImpl : public ProLocServiceMapping::Mapping
{
public:
    ServiceId GetServiceId() const override
    {
        return ARACOMServiceId;
    }

    std::shared_ptr<internal::proxy::ProxyFactory> GetProxy(
        std::weak_ptr<internal::proloc::skeleton::ServiceImplBase> service) const override
    {
        return ProxyBuilder<ProxyType>().make(service);
    }

    std::unique_ptr<skeleton::ServiceImplBase> GetSkeleton(internal::skeleton::ServiceBase& service,
        InstanceId instance_id) const override
    {
        return AdapterBuilder<SkeletonType>().make(service, instance_id);
    }
};

}  // namespace runtime
}  // namespace proloc
}  // namespace internal
}  // namespace com
}  // namespace ara

#endif  // COMMUNICATIONMIDDLEWARE_PROLOC_SERVICE_MAPPING_IMPL_H
