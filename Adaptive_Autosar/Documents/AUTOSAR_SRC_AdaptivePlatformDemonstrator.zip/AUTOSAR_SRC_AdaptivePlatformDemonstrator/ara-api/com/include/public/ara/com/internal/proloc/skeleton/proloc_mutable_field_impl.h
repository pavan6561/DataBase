// --------------------------------------------------------------------------
// |              _    _ _______     .----.      _____         _____        |
// |         /\  | |  | |__   __|  .  ____ .    / ____|  /\   |  __ \       |
// |        /  \ | |  | |  | |    .  / __ \ .  | (___   /  \  | |__) |      |
// |       / /\ \| |  | |  | |   .  / / / / v   \___ \ / /\ \ |  _  /       |
// |      / /__\ \ |__| |  | |   . / /_/ /  .   ____) / /__\ \| | \ \       |
// |     /________\____/   |_|   ^ \____/  .   |_____/________\_|  \_\      |
// |                              . _ _  .                                  |
// --------------------------------------------------------------------------
//
// All Rights Reserved.
// Any use of this source code is subject to a license agreement with the
// AUTOSAR development cooperation.
// More information is available at www.autosar.org.
//
// Disclaimer
//
// This work (specification and/or software implementation) and the material
// contained in it, as released by AUTOSAR, is for the purpose of information
// only. AUTOSAR and the companies that have contributed to it shall not be
// liable for any use of the work.
//
// The material contained in this work is protected by copyright and other
// types of intellectual property rights. The commercial exploitation of the
// material contained in this work requires a license to such intellectual
// property rights.
//
// This work may be utilized or reproduced without any modification, in any
// form or by any means, for informational purposes only. For any other
// purpose, no part of the work may be utilized or reproduced, in any form
// or by any means, without permission in writing from the publisher.
//
// The work has been developed for automotive applications only. It has
// neither been developed, nor tested for non-automotive applications.
//
// The word AUTOSAR and the AUTOSAR logo are registered trademarks.
// --------------------------------------------------------------------------

#ifndef COMMUNICATIONMIDDLEWARE_SKELETON_PROLOC_MUTABLE_FIELD_IMPL_H
#define COMMUNICATIONMIDDLEWARE_SKELETON_PROLOC_MUTABLE_FIELD_IMPL_H

#include <functional>

#include "ara/com/internal/skeleton/mutable_field.h"

#include "proloc_field_impl.h"

namespace ara
{
namespace com
{
namespace internal
{
namespace proloc
{
namespace skeleton
{

template <typename T>
class MutableFieldImpl : public internal::skeleton::MutableField<T>, public FieldImpl<T>
{
public:
    using Base = FieldImpl<T>;
    using typename FieldImpl<T>::GetResultType;
    using typename internal::skeleton::MutableField<T>::SetMethodSignature;

    explicit MutableFieldImpl(InstanceId instance)
        : FieldImpl<T>(instance)
    {
        // common::registerMethodHandler(FieldDescriptor::service_id,
        //                              EventImpl<T, FieldDescriptor>::instance_,
        //                              FieldDescriptor::set_method_id,
        //                              [this](const std::shared_ptr<::proloc::message>& msg) {
        //                                handleSet(msg);
        //                              });
    }

    /** \uptrace{SWS_CM_00116} */
    virtual void RegisterSetHandler(std::function<SetMethodSignature> handler) override
    {
        Base::PutHandler(set_handler_, std::move(handler));
    }

    /** \uptrace{SWS_CM_00113} */
    ara::core::Future<T> Set(const T& value)
    {
        if (set_handler_) {
            return set_handler_(value);
        }
        throw std::runtime_error("No Setter defined");
    }

private:
    std::function<SetMethodSignature> set_handler_;
};

}  // namespace skeleton
}  // namespace proloc
}  // namespace internal
}  // namespace com
}  // namespace ara

#endif  // COMMUNICATIONMIDDLEWARE_SKELETON_PROLOC_MUTABLE_FIELD_IMPL_H
