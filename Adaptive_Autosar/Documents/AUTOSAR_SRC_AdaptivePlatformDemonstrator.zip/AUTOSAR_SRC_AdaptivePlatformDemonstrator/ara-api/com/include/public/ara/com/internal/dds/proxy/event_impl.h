// --------------------------------------------------------------------------
// |              _    _ _______     .----.      _____         _____        |
// |         /\  | |  | |__   __|  .  ____ .    / ____|  /\   |  __ \       |
// |        /  \ | |  | |  | |    .  / __ \ .  | (___   /  \  | |__) |      |
// |       / /\ \| |  | |  | |   .  / / / / v   \___ \ / /\ \ |  _  /       |
// |      / /__\ \ |__| |  | |   . / /_/ /  .   ____) / /__\ \| | \ \       |
// |     /________\____/   |_|   ^ \____/  .   |_____/________\_|  \_\      |
// |                              . _ _  .                                  |
// --------------------------------------------------------------------------
//
// All Rights Reserved.
// Any use of this source code is subject to a license agreement with the
// AUTOSAR development cooperation.
// More information is available at www.autosar.org.
//
// Disclaimer
//
// This work (specification and/or software implementation) and the material
// contained in it, as released by AUTOSAR, is for the purpose of information
// only. AUTOSAR and the companies that have contributed to it shall not be
// liable for any use of the work.
//
// The material contained in this work is protected by copyright and other
// types of intellectual property rights. The commercial exploitation of the
// material contained in this work requires a license to such intellectual
// property rights.
//
// This work may be utilized or reproduced without any modification, in any
// form or by any means, for informational purposes only. For any other
// purpose, no part of the work may be utilized or reproduced, in any form
// or by any means, without permission in writing from the publisher.
//
// The work has been developed for automotive applications only. It has
// neither been developed, nor tested for non-automotive applications.
//
// The word AUTOSAR and the AUTOSAR logo are registered trademarks.
// --------------------------------------------------------------------------

#ifndef ARA_DDS_BINDING_INCLUDES_LIBARA_INTERNAL_DDS_PROXY_EVENT_IMPL_H_
#define ARA_DDS_BINDING_INCLUDES_LIBARA_INTERNAL_DDS_PROXY_EVENT_IMPL_H_

#include <mutex>
#include <deque>
#include <unordered_map>

#include "ara/com/internal/proxy/field.h"
#include "ara/com/internal/dds/types.h"
#include "method_impl.h"

#include <dds/sub/ddssub.hpp>
#include <dds/core/BuiltinTopicTypes.hpp>

#ifdef _UT_BUILD_
#    define ns_dds ::mocks::dds
#else
#    define ns_dds ::dds
#endif  // _UT_BUILD_

namespace ara
{
namespace com
{
namespace internal
{
namespace dds
{
namespace proxy
{

using SampleEventType = ns_dds::core::KeyedBytesTopicType;

/// \brief Event implementation for proxy interface
template <typename EventDescriptor, typename T>
class EventImpl
    : public virtual internal::proxy::Event<T>
    , ::dds::sub::DataReaderListener<SampleEventType>
{
public:
    using const_reference = typename internal::proxy::Event<T>::const_reference;
    using value_type = typename internal::proxy::Event<T>::value_type;
    using pointer_type = typename internal::proxy::Event<T>::pointer_type;  // SamplePtr<T>
    using container_value_type = typename internal::proxy::Event<T>::container_value_type;
    using descriptor_type = EventDescriptor;

    /// \brief constructor
    explicit EventImpl(types::InstanceId instance_id, ns_dds::domain::DomainParticipant participant)
        : instance_id_(instance_id)
        , participant_(participant)
        , reader_(::dds::core::null)
        , statusMask_(DDS_STATUS_MASK_NONE)
    {}

    /// \brief virtual destructor
    virtual ~EventImpl()
    {
        Unsubscribe();
    }

    /// \uptrace{SWS_CM_11027}
    virtual void SetSubscriptionStateChangeHandler(ara::com::SubscriptionStateChangeHandler handler) override
    {
        // clang-format off
        static const std::unordered_map<uint64_t,uint64_t> MASKS = 
        {
            {DDS_STATUS_MASK_NONE,               DDS_SUBSCRIPTION_MATCHED_STATUS},
            {DDS_SUBSCRIPTION_MATCHED_STATUS,    DDS_SUBSCRIPTION_MATCHED_STATUS},

            {DDS_DATA_AVAILABLE_STATUS,          DDS_DATA_AVAILABLE_STATUS |
                                                 DDS_SUBSCRIPTION_MATCHED_STATUS},
            {DDS_DATA_AVAILABLE_STATUS |
             DDS_SUBSCRIPTION_MATCHED_STATUS,    DDS_DATA_AVAILABLE_STATUS | 
                                                 DDS_SUBSCRIPTION_MATCHED_STATUS}
        };
        // clang-format on

        std::lock_guard<std::mutex> guard(lock_);
        state_change_handler_ = handler;
        if (!reader_.is_nil()) {
            ::dds::sub::DataReaderListener<SampleEventType>* pListener = reader_.listener();
            if (pListener) {
                auto mask = MASKS.find(statusMask_);
                assert(mask != MASKS.end());
                statusMask_ = mask->second;
                reader_.listener(this, ::dds::core::status::StatusMask(statusMask_));
            }
        }
    }

    /// \uptrace{SWS_CM_11028}
    virtual void UnsetSubscriptionStateChangeHandler() override
    {
        // clang-format off
        static const std::unordered_map<uint64_t,uint64_t> MASKS = 
        {
            {DDS_STATUS_MASK_NONE,               DDS_STATUS_MASK_NONE},
            {DDS_SUBSCRIPTION_MATCHED_STATUS,    DDS_STATUS_MASK_NONE},

            {DDS_DATA_AVAILABLE_STATUS,          DDS_DATA_AVAILABLE_STATUS},
                                                 
            {DDS_DATA_AVAILABLE_STATUS |
             DDS_SUBSCRIPTION_MATCHED_STATUS,    DDS_DATA_AVAILABLE_STATUS}
        };
        // clang-format on

        std::lock_guard<std::mutex> guard(lock_);
        state_change_handler_ = nullptr;
        if (!reader_.is_nil()) {
            ::dds::sub::DataReaderListener<SampleEventType>* pListener = reader_.listener();
            if (pListener) {
                auto mask = MASKS.find(statusMask_);
                assert(mask != MASKS.end());
                statusMask_ = mask->second;
                reader_.listener(this, ::dds::core::status::StatusMask(statusMask_));
            }
        }
    }

    /// \uptrace{SWS_CM_00181}
    /// \uptrace{SWS_CM_00309}
    /// \uptrace{SWS_CM_11025}
    virtual void SetReceiveHandler(ara::com::EventReceiveHandler handler) override
    {
        // clang-format off
        static const std::unordered_map<uint64_t,uint64_t> MASKS = 
        {
            {DDS_STATUS_MASK_NONE,               DDS_DATA_AVAILABLE_STATUS},
            {DDS_DATA_AVAILABLE_STATUS,          DDS_DATA_AVAILABLE_STATUS},

            {DDS_SUBSCRIPTION_MATCHED_STATUS,    DDS_SUBSCRIPTION_MATCHED_STATUS |
                                                 DDS_DATA_AVAILABLE_STATUS},
                                                 
            {DDS_DATA_AVAILABLE_STATUS |
             DDS_SUBSCRIPTION_MATCHED_STATUS,    DDS_DATA_AVAILABLE_STATUS |
                                                 DDS_SUBSCRIPTION_MATCHED_STATUS}
        };
        // clang-format on

        std::lock_guard<std::mutex> guard(lock_);
        receive_handler_ = handler;
        if (!reader_.is_nil()) {
            ::dds::sub::DataReaderListener<SampleEventType>* pListener = reader_.listener();
            if (pListener) {
                auto mask = MASKS.find(statusMask_);
                assert(mask != MASKS.end());
                statusMask_ = mask->second;
                reader_.listener(this, ::dds::core::status::StatusMask(statusMask_));
            }
        }
    }

    /// \uptrace{SWS_CM_00183}
    /// \uptrace{SWS_CM_11026}
    virtual void UnsetReceiveHandler() override
    {
        // clang-format off
        static const std::unordered_map<uint64_t,uint64_t> MASKS = 
        {
            {DDS_STATUS_MASK_NONE,               DDS_STATUS_MASK_NONE},
            {DDS_DATA_AVAILABLE_STATUS,          DDS_STATUS_MASK_NONE},

            {DDS_SUBSCRIPTION_MATCHED_STATUS,    DDS_SUBSCRIPTION_MATCHED_STATUS},

                                                 
            {DDS_DATA_AVAILABLE_STATUS |
             DDS_SUBSCRIPTION_MATCHED_STATUS,    DDS_SUBSCRIPTION_MATCHED_STATUS}
        };
        // clang-format on

        std::lock_guard<std::mutex> guard(lock_);
        receive_handler_ = nullptr;
        if (!reader_.is_nil()) {
            ::dds::sub::DataReaderListener<SampleEventType>* pListener = reader_.listener();
            if (pListener) {
                auto mask = MASKS.find(statusMask_);
                assert(mask != MASKS.end());
                statusMask_ = mask->second;
                reader_.listener(this, ::dds::core::status::StatusMask(statusMask_));
            }
        }
    }

    /// \uptrace{SWS_CM_00316}
    /// \uptrace{SWS_CM_11022}
    /// TODO ERROR: SWS does define GetSubscriptionState but Event does not
    virtual ara::com::SubscriptionState GetSubscriptionState() const  // override
    {
        ara::com::SubscriptionState state = ara::com::SubscriptionState::kNotSubscribed;
        if (!reader_.is_nil()) {
            if (reader_.subscription_matched_status().total_count() > 0) {
                state = ara::com::SubscriptionState::kSubscribed;
            } else {
                // TODO ERROR: SWS does not define kSubscriptionPending  but SWS_CM_11022 does
                state = ara::com::SubscriptionState::kNotSubscribed;
            }
        }
        return state;
    }

    virtual bool IsSubscribed() const override
    {
        return GetSubscriptionState() == ara::com::SubscriptionState::kSubscribed;
    }

    /// \uptrace{SWS_CM_00141}
    /// \uptrace{SWS_CM_11018}
    /// \uptrace{SWS_CM_11019}
    virtual void Subscribe(ara::com::EventCacheUpdatePolicy policy, std::size_t cache_size) override
    {
        if (cache_size < 1) {
            throw std::invalid_argument("cache_size must be at least 1");
        }

        policy_ = policy;

        if (reader_.is_nil()) {

            ns_dds::sub::Subscriber subscriber(participant_);
            /// \uptrace{SWS_CM_11019}
            ns_dds::sub::qos::SubscriberQos qos;
            ns_dds::core::policy::Partition partition(
                common::PREFIX + common::makeServiceString(descriptor_type::serviceId_, instance_id_));
            qos.policy(partition);
            subscriber.qos(qos);

            /// \uptrace{SWS_CM_11019}
            ::dds::sub::qos::DataReaderQos readerQos;
            readerQos.policy(::dds::core::policy::History(::dds::core::policy::HistoryKind::KEEP_LAST, cache_size));

            statusMask_ = DDS_STATUS_MASK_NONE;
            reader_ = ns_dds::sub::DataReader<SampleEventType>(subscriber,
                ns_dds::topic::Topic<SampleEventType>(participant_, EventDescriptor::topicName_),
                readerQos,
                this,
                ::dds::core::status::StatusMask(statusMask_));
        }
    }

    /// \uptrace{SWS_CM_00151}
    /// \uptrace{SWS_CM_11021}
    virtual void Unsubscribe() override
    {
        if (!reader_.is_nil()) {
            reader_.close();
            reader_ = ::dds::core::null;
        }
        Cleanup();
    }

    virtual bool Update() override
    {
        return Update({});
    }

    /// \brief Update the internal caches of this Event instance with new data from the event source, filtering the
    /// data.
    /// \uptrace{SWS_CM_00172}
    /// \uptrace{SWS_CM_00300}
    /// \uptrace{SWS_CM_11023}
    /// \uptrace{SWS_CM_00141}
    virtual bool Update(ara::com::FilterFunction<T> filter) override
    {
        std::lock_guard<std::mutex> guard(lock_);

        /// \uptrace{SWS_CM_11023}
        ns_dds::sub::SharedSamples<SampleEventType> samples
            = (policy_ == ara::com::EventCacheUpdatePolicy::kLastN) ? reader_.take() : reader_.read();

        working_set_.clear();
        for (auto& sample : samples) {
            if (sample.info().valid()) {
                value_type newSample;
                auto value = sample.data().value();
                value_type::deserialize(value, newSample);
                if (filter) {
                    if (filter(newSample)) {
                        working_set_.push_back(ara::com::make_sample_ptr<value_type>(newSample));
                    }
                } else {
                    working_set_.push_back(ara::com::make_sample_ptr<value_type>(newSample));
                }
            }
        }

        return !working_set_.empty();
    }

    /// \uptrace{SWS_CM_00174}
    virtual void Cleanup() override
    {
        std::lock_guard<std::mutex> guard(lock_);
        working_set_.clear();
    }

public:  // Implementing internal::proxy::Event
    virtual std::size_t size() const override
    {
        return working_set_.size();
    }

    virtual const container_value_type& at(std::size_t index) const override
    {
        return working_set_.at(index);
    }

private:
#ifdef _UT_BUILD_
public:
#endif
    virtual void on_requested_deadline_missed(::dds::sub::DataReader<SampleEventType>& reader,
        const ::dds::core::status::RequestedDeadlineMissedStatus& status) override
    {
        (void)(reader);
        (void)(status);
    }

    virtual void on_requested_incompatible_qos(::dds::sub::DataReader<SampleEventType>& reader,
        const ::dds::core::status::RequestedIncompatibleQosStatus& status) override
    {
        (void)(reader);
        (void)(status);
    }

    virtual void on_sample_rejected(::dds::sub::DataReader<SampleEventType>& reader,
        const ::dds::core::status::SampleRejectedStatus& status) override
    {
        (void)(reader);
        (void)(status);
    }

    virtual void on_liveliness_changed(::dds::sub::DataReader<SampleEventType>& reader,
        const ::dds::core::status::LivelinessChangedStatus& status) override
    {
        (void)(reader);
        (void)(status);
    }

    /// \uptrace{SWS_CM_11020}
    virtual void on_data_available(::dds::sub::DataReader<SampleEventType>& reader) override
    {
        (void)(reader);
        std::unique_lock<std::mutex> lock(lock_);
        ara::com::EventReceiveHandler receive_handler = receive_handler_;
        lock.unlock();
        if (receive_handler /*&& reader.datareader_cache_status().sample_count() > 0*/) {
            receive_handler();
        }
    }

    /// \uptrace{SWS_CM_11020}
    virtual void on_subscription_matched(::dds::sub::DataReader<SampleEventType>& reader,
        const ::dds::core::status::SubscriptionMatchedStatus& status) override
    {
        (void)(reader);
        (void)(status);
        std::unique_lock<std::mutex> lock(lock_);
        ara::com::SubscriptionStateChangeHandler state_change_handler = state_change_handler_;
        lock.unlock();
        if (state_change_handler) {
            state_change_handler(GetSubscriptionState());
        }
    }

    virtual void on_sample_lost(::dds::sub::DataReader<SampleEventType>& reader,
        const ::dds::core::status::SampleLostStatus& status) override
    {
        (void)(reader);
        (void)(status);
    }

private:
#ifdef _UT_BUILD_
public:
#endif

    using DataContainer = std::deque<pointer_type>;

    types::InstanceId instance_id_;
    ara::com::EventCacheUpdatePolicy policy_{ara::com::EventCacheUpdatePolicy::kNewestN};

    /// \uptrace{SWS_CM_00307}
    DataContainer working_set_;

    std::mutex lock_;

    /// \uptrace{SWS_CM_11025}
    /// \uptrace{SWS_CM_11026}
    ara::com::EventReceiveHandler receive_handler_;

    ara::com::SubscriptionStateChangeHandler state_change_handler_;

    ns_dds::domain::DomainParticipant participant_;
    ns_dds::sub::DataReader<SampleEventType> reader_;
    uint64_t statusMask_;
};

}  // namespace proxy
}  // namespace dds
}  // namespace internal
}  // namespace com
}  // namespace ara

#endif  // ARA_DDS_BINDING_INCLUDES_LIBARA_INTERNAL_DDS_PROXY_EVENT_IMPL_H_
