// --------------------------------------------------------------------------
// |              _    _ _______     .----.      _____         _____        |
// |         /\  | |  | |__   __|  .  ____ .    / ____|  /\   |  __ \       |
// |        /  \ | |  | |  | |    .  / __ \ .  | (___   /  \  | |__) |      |
// |       / /\ \| |  | |  | |   .  / / / / v   \___ \ / /\ \ |  _  /       |
// |      / /__\ \ |__| |  | |   . / /_/ /  .   ____) / /__\ \| | \ \       |
// |     /________\____/   |_|   ^ \____/  .   |_____/________\_|  \_\      |
// |                              . _ _  .                                  |
// --------------------------------------------------------------------------
//
// All Rights Reserved.
// Any use of this source code is subject to a license agreement with the
// AUTOSAR development cooperation.
// More information is available at www.autosar.org.
//
// Disclaimer
//
// This work (specification and/or software implementation) and the material
// contained in it, as released by AUTOSAR, is for the purpose of information
// only. AUTOSAR and the companies that have contributed to it shall not be
// liable for any use of the work.
//
// The material contained in this work is protected by copyright and other
// types of intellectual property rights. The commercial exploitation of the
// material contained in this work requires a license to such intellectual
// property rights.
//
// This work may be utilized or reproduced without any modification, in any
// form or by any means, for informational purposes only. For any other
// purpose, no part of the work may be utilized or reproduced, in any form
// or by any means, without permission in writing from the publisher.
//
// The work has been developed for automotive applications only. It has
// neither been developed, nor tested for non-automotive applications.
//
// The word AUTOSAR and the AUTOSAR logo are registered trademarks.
// --------------------------------------------------------------------------

#ifndef ARA_DDS_BINDING_INCLUDES_LIBARA_INTERNAL_DDS_SKELETON_EVENT_IMPL_H_
#define ARA_DDS_BINDING_INCLUDES_LIBARA_INTERNAL_DDS_SKELETON_EVENT_IMPL_H_

#include "ara/com/types.h"
#include "ara/com/internal/skeleton/event.h"
#include "ara/com/internal/dds/types.h"
//#include "method_impl.h"

#include <dds/pub/ddspub.hpp>
#include <dds/core/BuiltinTopicTypes.hpp>

#ifdef _UT_BUILD_
#    define ns_dds ::mocks::dds
#else
#    define ns_dds ::dds
#endif  // _UT_BUILD_

namespace ara
{
namespace com
{
namespace internal
{
namespace dds
{
namespace skeleton
{

//!!!!!!!!!!!!!!!!!! TO BE REVIEWED !!!!!!!!!!!!!!!!!
// SWS_CM_11016, DDS Topic datatype definition
// SWS_CM_00162, Send event where application is responsible for the data
// SWS_CM_11004, Adding Service and Service Instance IDs to the DDS Domain Participant’s USER_DATA QoS Policy
// SWS_CM_11005, Mapping of StopOfferService method
//!!!!!!!!!!!!!!!!!! TO BE REVIEWED !!!!!!!!!!!!!!!!!

using SampleEventType = ns_dds::core::KeyedBytesTopicType;

/// \brief Event implementation for Skeleton interface
template <typename EventDescriptor, typename T>
class EventImpl : public virtual internal::skeleton::Event<T>
{
public:
    using Base = internal::skeleton::Event<T>;
    using typename Base::const_reference;
    using typename Base::value_type;
    using descriptor_type = EventDescriptor;

    /// \brief constructor
    explicit EventImpl(types::InstanceId instance_id)
        : instanceId_(instance_id)
        , topic_(ns_dds::core::null)
        , writer_(ns_dds::core::null)
    {}

    /// \brief virtual destructor
    virtual ~EventImpl()
    {}

    /// \uptrace{SWS_CM_11003}
    void Setup(ns_dds::topic::Topic<SampleEventType> topic, ns_dds::pub::DataWriter<SampleEventType> writer)
    {
        assert(topic.name() == EventDescriptor::topicName_);
        topic_ = topic;
        writer_ = writer;
    }

    /// \uptrace{SWS_CM_11017}
    virtual void Send(const_reference data) override
    {
        if (!IsOffered()) {
            // If writer_ does not point to a valid DataWriter, NOP
            return;
        }
        std::vector<uint8_t> bytes;
        value_type::serialize(data, bytes);
        std::string key = std::to_string(instanceId_);
        writer_.write(ns_dds::core::KeyedBytesTopicType(key, bytes));
    }

    /// \uptrace{SWS_CM_90438}
    /// \uptrace{SWS_CM_00308}
    virtual ara::com::SampleAllocateePtr<T> Allocate() override
    {
        return std::make_unique<T>();
    }

    /// \uptrace{SWS_CM_11017}
    virtual void Send(ara::com::SampleAllocateePtr<T> data) override
    {
        Send(*data);
    }

    const ns_dds::topic::Topic<SampleEventType> topic() const
    {
        return topic_;
    }
    bool IsOffered() const
    {
        return !writer_.is_nil();
    }

private:
#ifdef _UT_BUILD_
public:
#endif

    types::InstanceId instanceId_;
    ns_dds::topic::Topic<SampleEventType> topic_;
    ns_dds::pub::DataWriter<SampleEventType> writer_;
};

}  // namespace skeleton
}  // namespace dds
}  // namespace internal
}  // namespace com
}  // namespace ara

#endif  // ARA_DDS_BINDING_INCLUDES_LIBARA_INTERNAL_DDS_SKELETON_EVENT_IMPL_H_
