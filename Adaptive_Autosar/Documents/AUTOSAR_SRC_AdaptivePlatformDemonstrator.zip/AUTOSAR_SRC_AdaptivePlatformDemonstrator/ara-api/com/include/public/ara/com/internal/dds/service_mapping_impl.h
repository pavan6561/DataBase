// --------------------------------------------------------------------------
// |              _    _ _______     .----.      _____         _____        |
// |         /\  | |  | |__   __|  .  ____ .    / ____|  /\   |  __ \       |
// |        /  \ | |  | |  | |    .  / __ \ .  | (___   /  \  | |__) |      |
// |       / /\ \| |  | |  | |   .  / / / / v   \___ \ / /\ \ |  _  /       |
// |      / /__\ \ |__| |  | |   . / /_/ /  .   ____) / /__\ \| | \ \       |
// |     /________\____/   |_|   ^ \____/  .   |_____/________\_|  \_\      |
// |                              . _ _  .                                  |
// --------------------------------------------------------------------------
//
// All Rights Reserved.
// Any use of this source code is subject to a license agreement with the
// AUTOSAR development cooperation.
// More information is available at www.autosar.org.
//
// Disclaimer
//
// This work (specification and/or software implementation) and the material
// contained in it, as released by AUTOSAR, is for the purpose of information
// only. AUTOSAR and the companies that have contributed to it shall not be
// liable for any use of the work.
//
// The material contained in this work is protected by copyright and other
// types of intellectual property rights. The commercial exploitation of the
// material contained in this work requires a license to such intellectual
// property rights.
//
// This work may be utilized or reproduced without any modification, in any
// form or by any means, for informational purposes only. For any other
// purpose, no part of the work may be utilized or reproduced, in any form
// or by any means, without permission in writing from the publisher.
//
// The work has been developed for automotive applications only. It has
// neither been developed, nor tested for non-automotive applications.
//
// The word AUTOSAR and the AUTOSAR logo are registered trademarks.
// --------------------------------------------------------------------------

#ifndef ARA_DDS_BINDING_INCLUDES_LIBARA_INTERNAL_DDS_SERVICE_MAPPING_IMPL_H_
#define ARA_DDS_BINDING_INCLUDES_LIBARA_INTERNAL_DDS_SERVICE_MAPPING_IMPL_H_

#include "service_mapping.h"
#include "proxy_factory_impl.h"

namespace ara
{
namespace com
{
namespace internal
{
namespace dds
{
namespace runtime
{

struct NoProxy
{};

struct NoAdapter
{};

template <typename Adapter>
struct AdapterBuilder
{
    std::unique_ptr<Adapter> make(internal::skeleton::ServiceBase& service, types::InstanceId instance_id)
    {
        try {
            typename Adapter::ServiceInterface& interface = dynamic_cast<typename Adapter::ServiceInterface&>(service);
            std::unique_ptr<Adapter> adapter = std::make_unique<Adapter>(interface, instance_id);
            return adapter;
        } catch (std::bad_cast& e) {
            throw IllegalStateException("Given service interface does not fit to the binding adapter!");
        }
    }
};

template <>
struct AdapterBuilder<NoAdapter>
{
    std::unique_ptr<internal::skeleton::ServiceBase> make(internal::skeleton::ServiceBase&, types::InstanceId)
    {
        return nullptr;
    }
};

template <typename ProxyType>
struct ProxyBuilder
{
    std::shared_ptr<internal::proxy::ProxyFactory> make(InstanceId instance_id)
    {
        return std::make_shared<ProxyFactoryImpl<ProxyType>>(instance_id);
    }
};

template <>
struct ProxyBuilder<NoProxy>
{
    std::shared_ptr<internal::proxy::ProxyFactory> make(InstanceId)
    {
        return nullptr;
    }
};

template <ServiceId ARACOMServiceId, ::dds::service_t ddsServiceId, typename ProxyType, typename SkeletonType>
class ServiceMappingImpl : public DdsServiceMapping::Mapping
{
public:
    /// \brief Get the service ID for the service the mapping represents.
    /// \return Service ID
    ServiceId GetServiceId() const override
    {
        return ARACOMServiceId;
    }

    /// \brief Get the proxy factory that creates proxies for the given service instance.
    /// \param instance_id Instance ID of the service
    /// \return Proxy factory
    std::shared_ptr<internal::proxy::ProxyFactory> GetProxy(InstanceId instance_id) const override
    {
        return ProxyBuilder<ProxyType>().make(instance_id);
    }

    /// \brief Get the skeleton binding class for the given service instance.
    /// \param service Service implementation from the application layer that shall be exported using the DDS binding.
    /// \param instance_id Instance ID of the service
    /// \return Binding instance.
    std::unique_ptr<internal::skeleton::ServiceBase> GetSkeleton(internal::skeleton::ServiceBase& service,
        InstanceId instance_id) const override
    {
        return AdapterBuilder<SkeletonType>().make(service, instance_id);
    }
};

}  // namespace runtime
}  // namespace dds
}  // namespace internal
}  // namespace com
}  // namespace ara

#endif  // ARA_DDS_BINDING_INCLUDES_LIBARA_INTERNAL_DDS_SERVICE_MAPPING_IMPL_H_
