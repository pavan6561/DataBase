// --------------------------------------------------------------------------
// |              _    _ _______     .----.      _____         _____        |
// |         /\  | |  | |__   __|  .  ____ .    / ____|  /\   |  __ \       |
// |        /  \ | |  | |  | |    .  / __ \ .  | (___   /  \  | |__) |      |
// |       / /\ \| |  | |  | |   .  / / / / v   \___ \ / /\ \ |  _  /       |
// |      / /__\ \ |__| |  | |   . / /_/ /  .   ____) / /__\ \| | \ \       |
// |     /________\____/   |_|   ^ \____/  .   |_____/________\_|  \_\      |
// |                              . _ _  .                                  |
// --------------------------------------------------------------------------
//
// All Rights Reserved.
// Any use of this source code is subject to a license agreement with the
// AUTOSAR development cooperation.
// More information is available at www.autosar.org.
//
// Disclaimer
//
// This work (specification and/or software implementation) and the material
// contained in it, as released by AUTOSAR, is for the purpose of information
// only. AUTOSAR and the companies that have contributed to it shall not be
// liable for any use of the work.
//
// The material contained in this work is protected by copyright and other
// types of intellectual property rights. The commercial exploitation of the
// material contained in this work requires a license to such intellectual
// property rights.
//
// This work may be utilized or reproduced without any modification, in any
// form or by any means, for informational purposes only. For any other
// purpose, no part of the work may be utilized or reproduced, in any form
// or by any means, without permission in writing from the publisher.
//
// The work has been developed for automotive applications only. It has
// neither been developed, nor tested for non-automotive applications.
//
// The word AUTOSAR and the AUTOSAR logo are registered trademarks.
// --------------------------------------------------------------------------

/**
 * \file
 * \brief Identifier of a certain instance of a service.
 *
 * This is needed to distinguish different instances of exactly the same service in the system. Only contains instance
 * information. Does NOT contain a fully qualified name, which also contains service type information.
 *
 */
#ifndef ARA_COM_INSTANCE_IDENTIFIER_H
#define ARA_COM_INSTANCE_IDENTIFIER_H

#include <functional>

#include "ara/core/string_view.h"
#include "ara/com/internal/definitions.h"

namespace ara
{
namespace com
{

/**
 * \addtogroup runtime
 *
 * @{
 */

/**
 * \brief Identifier of a certain instance of a service.
 *
 * \uptrace{SWS_CM_00302}
 */
class InstanceIdentifier
{
public:
    /**
     * \brief Implicit converting constructor from the internal InstanceId to InstanceIdentifier.
     * \param id The internal service ID.
     */
    constexpr InstanceIdentifier(const ara::com::internal::InstanceId& id)
        : instance_id_(id)
    {
    }
    /**
     * \brief Explicit constructor to avoid implicit type conversion for instance ID
     * \param value Used for instance ID
     *
     * \uptrace{SWS_CM_00302}
     */
    explicit InstanceIdentifier(ara::core::StringView value);

    /**
     * \brief Converts the contents of the InstanceIdentifier to an implementation-defined string representation.
     * \return String representing the service instance.
     *
     * \uptrace{SWS_CM_00302}
     */
    ara::core::StringView toString() const;
    /**
     * \brief Return instance_id for a Service
     * \return Return instance_id
     */
    ara::com::internal::InstanceId GetInstanceId() const
    {
        return instance_id_;
    }
    /**
     * \brief Compare the equality of two instance IDs.
     * \param other InstanceIdentifier to compare to.
     * \return true if equal else false
     *
     * \uptrace{SWS_CM_00302}
     */
    bool operator==(const InstanceIdentifier& other) const
    {
        return GetInstanceId() == other.GetInstanceId();
    }
    /**
     * \brief Establishes a total order over InstanceIdentifier so that it's usable inside an ara::core::Map or std::set
     * \param other InstanceIdentifier to compare to.
     * \return true if *this < other else false
     *
     * \uptrace{SWS_CM_00302}
     */
    bool operator<(const InstanceIdentifier& other) const
    {
        return GetInstanceId() < other.GetInstanceId();
    }

    /**
     * \uptrace{SWS_CM_00302}
     */
    InstanceIdentifier& operator=(const InstanceIdentifier& other)
    {
        if (this != &other)
        {
            instance_id_ = other.instance_id_;
        }
        return *this;
    }
    /**
     * \brief Cast operator to convert an InstanceIdentifier back to the implementation specific instance ID.
     * \return Implementation specific instance ID.
     */
    explicit operator ara::com::internal::InstanceId() const
    {
        return instance_id_;
    }
    /**
     * \brief Defines the constant that can be used a the wildcard to look for all compatible services.
     *
     * This is used during service discovery for \see FindService or \see StartFindService.
     *
     * ### TOM: This one should uptrace to SWS_CM_00302 - type mismatch though
     * (SWS_CM_00302 specifies that InstanceIdentifier::Any is of type InstanceIdentifier).
     */
    static constexpr ara::com::internal::InstanceId Any{ara::com::internal::INSTANCE_ID_UNKNOWN};

private:
    ara::com::internal::InstanceId instance_id_;
};

/**
 * @}
 */

}  // namespace com
}  // namespace ara

namespace std
{

template <>
struct hash<ara::com::InstanceIdentifier>
{
public:
    using result_type = std::size_t;
    using argument_type = ara::com::InstanceIdentifier;
    /**
     * \brief function-call operator to retrieve the hash value of InstanceIdentifier.
     *
     * By providing this, InstanceIdentifier can be used in std::unordered_map and std::unordered_set.
     *
     * \param id InstanceIdentifier to be hashed.
     * \return Hash value.
     */
    std::size_t operator()(const ara::com::InstanceIdentifier& id) const
    {
        return static_cast<std::size_t>(id.GetInstanceId());
    }
};

}  // namespace std

#endif  // ARA_COM_INSTANCE_IDENTIFIER_H
