// --------------------------------------------------------------------------
// |              _    _ _______     .----.      _____         _____        |
// |         /\  | |  | |__   __|  .  ____ .    / ____|  /\   |  __ \       |
// |        /  \ | |  | |  | |    .  / __ \ .  | (___   /  \  | |__) |      |
// |       / /\ \| |  | |  | |   .  / / / / v   \___ \ / /\ \ |  _  /       |
// |      / /__\ \ |__| |  | |   . / /_/ /  .   ____) / /__\ \| | \ \       |
// |     /________\____/   |_|   ^ \____/  .   |_____/________\_|  \_\      |
// |                              . _ _  .                                  |
// --------------------------------------------------------------------------
//
// All Rights Reserved.
// Any use of this source code is subject to a license agreement with the
// AUTOSAR development cooperation.
// More information is available at www.autosar.org.
//
// Disclaimer
//
// This work (specification and/or software implementation) and the material
// contained in it, as released by AUTOSAR, is for the purpose of information
// only. AUTOSAR and the companies that have contributed to it shall not be
// liable for any use of the work.
//
// The material contained in this work is protected by copyright and other
// types of intellectual property rights. The commercial exploitation of the
// material contained in this work requires a license to such intellectual
// property rights.
//
// This work may be utilized or reproduced without any modification, in any
// form or by any means, for informational purposes only. For any other
// purpose, no part of the work may be utilized or reproduced, in any form
// or by any means, without permission in writing from the publisher.
//
// The work has been developed for automotive applications only. It has
// neither been developed, nor tested for non-automotive applications.
//
// The word AUTOSAR and the AUTOSAR logo are registered trademarks.
// --------------------------------------------------------------------------

/**
 * \file
 * \brief Test
 */

#ifndef ARA_COM_PROXY_EVENT_H
#define ARA_COM_PROXY_EVENT_H

#include "ara/com/types.h"
#include "event_base.h"
#include "event_data_container.h"
#include <ara/com/internal/e2e/is_e2e_enabled.h>
#include <ara/com/e2exf/types.h>

namespace ara
{
namespace com
{
namespace internal
{
namespace proxy
{

/**
 * \addtogroup frontendproxybase
 *
 * @{
 */

/**
 * \class Event
 *
 * \brief Defines the typed interface of all event elements on proxy side.
 *
 * Implementations of this interface have an internal cache that holds references to the current set of data the
 * application may work on. A call to \ref Update() will change this data set by updating the cache with new values that
 * were received from the communications partner.
 *
 * It depends on the caching policy which set of data will be put into the cache. Two parameters exist to tune the
 * cache:
 * - Cache size
 *
 *   This parameter determines a count N that sets a maximum number of packages that are held inside the cache at a
 *   given time.
 *
 * - Cache policy
 *
 *   If set to kLastN, the last N data packages received from the data source are held in the cache. If set to kNewestN,
 *   the last N data packages received from the data source *since the last call to Update* are held in the cache.
 *
 */
template <typename T, bool E2E = ara::com::internal::e2e::is_e2e_enabled<T>::value>
class Event : public virtual bits::EventBase, protected EventDataContainer<ara::com::SamplePtr<T>>
{
public:
    using const_reference = ConstBaseRef<T>;
    using value_type = BaseType<T>;

    using container_type = EventDataContainer<ara::com::SamplePtr<T>>;
    using container_value_type = typename container_type::value_type;

    using pointer_type = SamplePtr<T>;
    using SampleType = value_type;

    Event() = default;
    Event(const Event& e) = delete;
    Event(Event&& e) = delete;
    Event& operator=(const Event& e) = delete;
    Event& operator=(Event&& e) = delete;

    virtual ~Event()
    {
    }

    /**
     * \brief Update the internal caches of this Event instance with new data from the event source.
     *
     * This call will fetch new data from the input buffers and put it into the intetrnal buffers. It depends on the
     * caching policy what data is put into the internal buffers. See the class documentation for an in-depth
     * description
     * of the available strategies.
     *
     * After calling this function, the \ref Values() method may return a different set of data. However, it is
     * guaranteed
     * that in between two calls to Update, \ref Values() will return the same set of data, no matter how often it is
     * called.
     *
     * \return true if data is available in the internal buffers, false otherwise.
     *
     * \note If Update is called and the service is not subscribed the method will raise a \ref NotSubscribedException.
     */
    virtual bool Update() = 0;

    /**
     * \brief Update the internal caches of this Event instance with new data from the event source, filtering the data.
     * \uptrace{SWS_CM_00172}
     *
     * \param filter
     * \parblock
     * Filter function for the samples.
     *
     * This filter will be applied to the deserialized data within the context of the update. If the supplied function
     * returns true, the data will be copied into the internal buffers. Otherwise, the data will not be added to the
     * cache.
     * \parblockend
     *
     * \return true if data is available in the internal buffers, false otherwise.
     *
     * \note If Update is called and the service is not subscribed the method will raise a \ref NotSubscribedException.
     */
    virtual bool Update(ara::com::FilterFunction<T> filter) = 0;

    /**
     * \brief Get the samples that were copied into the cache by the last call to \ref Update().
     * \uptrace{SWS_CM_00173}
     *
     * The container is expected to be stable until update is called again. It is allowed to copy references to the
     * provided data to internal buffers as \ref SamplePtr implements a reference counting mechanism that guarantees the
     * data to stay available until the last instance of \ref SamplePtr that points to the data was dropped.
     *
     * \return Container of SamplePtr
     *
     * \uptrace{SWS_CM_90418}
     */
    const container_type& GetCachedSamples() const
    {
        return *this;
    }

    /// \uptrace{SWS_CM_90424}
    template <typename U = T, typename = std::enable_if_t<E2E, U>>
    ara::com::e2exf::E2EResult GetE2EResult() const noexcept
    {
        return DoCheckResult();
    }

private:
    virtual ara::com::e2exf::E2EResult DoCheckResult() const noexcept
    {
        return ara::com::e2exf::E2EResult{};
    };
};

/**
 * @}
 */

}  // namespace proxy
}  // namespace internal
}  // namespace com
}  // namespace ara

#endif  // ARA_COM_PROXY_EVENT_H
