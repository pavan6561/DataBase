// --------------------------------------------------------------------------
// |              _    _ _______     .----.      _____         _____        |
// |         /\  | |  | |__   __|  .  ____ .    / ____|  /\   |  __ \       |
// |        /  \ | |  | |  | |    .  / __ \ .  | (___   /  \  | |__) |      |
// |       / /\ \| |  | |  | |   .  / / / / v   \___ \ / /\ \ |  _  /       |
// |      / /__\ \ |__| |  | |   . / /_/ /  .   ____) / /__\ \| | \ \       |
// |     /________\____/   |_|   ^ \____/  .   |_____/________\_|  \_\      |
// |                              . _ _  .                                  |
// --------------------------------------------------------------------------
//
// All Rights Reserved.
// Any use of this source code is subject to a license agreement with the
// AUTOSAR development cooperation.
// More information is available at www.autosar.org.
//
// Disclaimer
//
// This work (specification and/or software implementation) and the material
// contained in it, as released by AUTOSAR, is for the purpose of information
// only. AUTOSAR and the companies that have contributed to it shall not be
// liable for any use of the work.
//
// The material contained in this work is protected by copyright and other
// types of intellectual property rights. The commercial exploitation of the
// material contained in this work requires a license to such intellectual
// property rights.
//
// This work may be utilized or reproduced without any modification, in any
// form or by any means, for informational purposes only. For any other
// purpose, no part of the work may be utilized or reproduced, in any form
// or by any means, without permission in writing from the publisher.
//
// The work has been developed for automotive applications only. It has
// neither been developed, nor tested for non-automotive applications.
//
// The word AUTOSAR and the AUTOSAR logo are registered trademarks.
// --------------------------------------------------------------------------

#ifndef PROLOC_SKELETON_FIELD_IMPL_H
#define PROLOC_SKELETON_FIELD_IMPL_H

#include <functional>
#include <mutex>

#include "proloc_event_impl.h"
#include "proloc_service_impl_base.h"

#include "ara/com/types.h"
#include "ara/com/internal/skeleton/field.h"

#include "ara/core/future.h"

namespace ara
{
namespace com
{
namespace internal
{
namespace proloc
{
namespace skeleton
{

template <typename T>
class FieldImpl : public virtual internal::skeleton::Field<T>, public EventImpl<T>
{
public:
    using typename internal::skeleton::Field<T>::GetResultType;
    using Base = internal::skeleton::Field<T>;
    using typename Base::const_reference;
    using typename Base::reference;

    explicit FieldImpl(InstanceId instance)
        : EventImpl<T>(instance)
    {
        //  common::registerMethodHandler(FieldDescriptor::service_id,
        //                                EventImpl<T, FieldDescriptor>::instance_,
        //                                FieldDescriptor::get_method_id,
        //                                [this](const std::shared_ptr<::proloc::message>& msg) {
        //                                  handleGet(msg);
        //                                });
    }

    virtual ~FieldImpl()
    {
        RegisterGetHandler(nullptr);
    }

    /** \uptrace{SWS_CM_00114} */
    virtual void RegisterGetHandler(std::function<ara::core::Future<T>()> handler) override
    {
        PutHandler(get_handler_, std::move(handler));
    }

    virtual void Send(const_reference data) override
    {
        std::lock_guard<std::mutex> guard(lock_);
        value_ = data;
        EventImpl<T>::Send(value_);
    }

    /** \uptrace{SWS_CM_00112} */
    ara::core::Future<T> Get() const
    {
        std::lock_guard<std::mutex> guard(lock_);
        if (get_handler_) {
            T reply;
            get_handler_(reply);
            return reply;
        } else {
            return value_;
        }
    }

protected:
    mutable std::mutex lock_;
    T value_;

    template <typename Signature>
    std::function<Signature> RetrieveHandler(const std::function<Signature>& source) const
    {
        std::lock_guard<std::mutex> guard(lock_);
        return source;
    }

    // TODO
    virtual void Update(const_reference data) override
    {
        this->Send(data);
    }

    template <typename Signature>
    void PutHandler(std::function<Signature>& target, std::function<Signature> source)
    {
        std::lock_guard<std::mutex> guard(lock_);
        target = std::move(source);
    }

private:
    std::function<ara::core::Future<T>()> get_handler_;
};

}  // namespace skeleton
}  // namespace proloc
}  // namespace internal
}  // namespace com
}  // namespace ara

#endif  // COMMUNICATIONMIDDLEWARE_FIELD_IMPL_H
