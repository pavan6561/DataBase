// --------------------------------------------------------------------------
// |              _    _ _______     .----.      _____         _____        |
// |         /\  | |  | |__   __|  .  ____ .    / ____|  /\   |  __ \       |
// |        /  \ | |  | |  | |    .  / __ \ .  | (___   /  \  | |__) |      |
// |       / /\ \| |  | |  | |   .  / / / / v   \___ \ / /\ \ |  _  /       |
// |      / /__\ \ |__| |  | |   . / /_/ /  .   ____) / /__\ \| | \ \       |
// |     /________\____/   |_|   ^ \____/  .   |_____/________\_|  \_\      |
// |                              . _ _  .                                  |
// --------------------------------------------------------------------------
//
// All Rights Reserved.
// Any use of this source code is subject to a license agreement with the
// AUTOSAR development cooperation.
// More information is available at www.autosar.org.
//
// Disclaimer
//
// This work (specification and/or software implementation) and the material
// contained in it, as released by AUTOSAR, is for the purpose of information
// only. AUTOSAR and the companies that have contributed to it shall not be
// liable for any use of the work.
//
// The material contained in this work is protected by copyright and other
// types of intellectual property rights. The commercial exploitation of the
// material contained in this work requires a license to such intellectual
// property rights.
//
// This work may be utilized or reproduced without any modification, in any
// form or by any means, for informational purposes only. For any other
// purpose, no part of the work may be utilized or reproduced, in any form
// or by any means, without permission in writing from the publisher.
//
// The work has been developed for automotive applications only. It has
// neither been developed, nor tested for non-automotive applications.
//
// The word AUTOSAR and the AUTOSAR logo are registered trademarks.
// --------------------------------------------------------------------------

#ifndef PROLOC_PROXY_FIELD_IMPL_H
#define PROLOC_PROXY_FIELD_IMPL_H

#include "proloc_event_impl.h"
#include "proloc_getter_impl.h"

namespace ara
{
namespace com
{
namespace internal
{
namespace proloc
{
namespace proxy
{

template <typename FieldDescriptor, typename T>
class FieldImpl : public virtual internal::proxy::Field<T>, public EventImpl<FieldDescriptor, T>
{
public:
    using MethodGet = typename internal::proxy::Field<T>::MethodGet;

    explicit FieldImpl(std::weak_ptr<internal::proloc::skeleton::ServiceImplBase> service)
        : internal::proxy::Field<T>(get_method_)
        , EventImpl<FieldDescriptor, T>(service)
        , get_method_(service)
    {
    }

    virtual ~FieldImpl()
    {
    }

    virtual void Subscribe(ara::com::EventCacheUpdatePolicy policy, std::size_t cache_size) override
    {
        EventImpl<FieldDescriptor, T>::DoSubscribe(policy, cache_size, true);
    }

protected:
    GetterImpl<FieldDescriptor, typename internal::proxy::Field<T>::MethodGet::signature_type> get_method_;
};

}  // namespace proxy
}  // namespace proloc
}  // namespace internal
}  // namespace com
}  // namespace ara

#endif  // PROLOC_PROXY_FIELD_IMPL_H
