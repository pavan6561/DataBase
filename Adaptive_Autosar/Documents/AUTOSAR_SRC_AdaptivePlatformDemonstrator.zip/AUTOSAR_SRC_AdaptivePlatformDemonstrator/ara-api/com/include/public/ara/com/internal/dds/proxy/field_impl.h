// --------------------------------------------------------------------------
// |              _    _ _______     .----.      _____         _____        |
// |         /\  | |  | |__   __|  .  ____ .    / ____|  /\   |  __ \       |
// |        /  \ | |  | |  | |    .  / __ \ .  | (___   /  \  | |__) |      |
// |       / /\ \| |  | |  | |   .  / / / / v   \___ \ / /\ \ |  _  /       |
// |      / /__\ \ |__| |  | |   . / /_/ /  .   ____) / /__\ \| | \ \       |
// |     /________\____/   |_|   ^ \____/  .   |_____/________\_|  \_\      |
// |                              . _ _  .                                  |
// --------------------------------------------------------------------------
//
// All Rights Reserved.
// Any use of this source code is subject to a license agreement with the
// AUTOSAR development cooperation.
// More information is available at www.autosar.org.
//
// Disclaimer
//
// This work (specification and/or software implementation) and the material
// contained in it, as released by AUTOSAR, is for the purpose of information
// only. AUTOSAR and the companies that have contributed to it shall not be
// liable for any use of the work.
//
// The material contained in this work is protected by copyright and other
// types of intellectual property rights. The commercial exploitation of the
// material contained in this work requires a license to such intellectual
// property rights.
//
// This work may be utilized or reproduced without any modification, in any
// form or by any means, for informational purposes only. For any other
// purpose, no part of the work may be utilized or reproduced, in any form
// or by any means, without permission in writing from the publisher.
//
// The work has been developed for automotive applications only. It has
// neither been developed, nor tested for non-automotive applications.
//
// The word AUTOSAR and the AUTOSAR logo are registered trademarks.
// --------------------------------------------------------------------------

#ifndef ARA_DDS_BINDING_INCLUDES_LIBARA_INTERNAL_DDS_PROXY_FIELD_IMPL_H_
#define ARA_DDS_BINDING_INCLUDES_LIBARA_INTERNAL_DDS_PROXY_FIELD_IMPL_H_

#include "ara/com/internal/dds/types.h"
#include "make_method_descriptor_from.h"
#include "event_impl.h"

namespace ara
{
namespace com
{
namespace internal
{
namespace dds
{
namespace proxy
{

/// \brief Field implementation for Proxy Interface
template <typename FieldDescriptor, typename T>
class FieldImpl
    : public virtual internal::proxy::Field<T>
    , public EventImpl<FieldDescriptor, T>
{
public:
    using MethodGet = typename internal::proxy::Field<T>::MethodGet;

    /// \brief Ctor
    /// \param instance_id InstanceId to create the FieldImpl object
    explicit FieldImpl(types::InstanceId instance_id)
        : internal::proxy::Field<T>(get_method_)
        , EventImpl<FieldDescriptor, T>(instance_id)
        , get_method_(instance_id)
    {}

    /// \brief Dtor
    virtual ~FieldImpl()
    {}

    virtual void Subscribe(ara::com::EventCacheUpdatePolicy policy, std::size_t cache_size) override
    {
        EventImpl<FieldDescriptor, T>::DoSubscribe(policy, cache_size, true);
    }

protected:
    /// \brief This is the get method proxy instance that is used if someone calls Get() on this field.
    MethodImpl<MakeGetMethodDescriptorFrom<FieldDescriptor>,
        typename internal::proxy::Field<T>::MethodGet::signature_type>
        get_method_;
};

}  // namespace proxy
}  // namespace dds
}  // namespace internal
}  // namespace com
}  // namespace ara

#endif  // ARA_DDS_BINDING_INCLUDES_LIBARA_INTERNAL_DDS_PROXY_FIELD_IMPL_H_
