// --------------------------------------------------------------------------
// |              _    _ _______     .----.      _____         _____        |
// |         /\  | |  | |__   __|  .  ____ .    / ____|  /\   |  __ \       |
// |        /  \ | |  | |  | |    .  / __ \ .  | (___   /  \  | |__) |      |
// |       / /\ \| |  | |  | |   .  / / / / v   \___ \ / /\ \ |  _  /       |
// |      / /__\ \ |__| |  | |   . / /_/ /  .   ____) / /__\ \| | \ \       |
// |     /________\____/   |_|   ^ \____/  .   |_____/________\_|  \_\      |
// |                              . _ _  .                                  |
// --------------------------------------------------------------------------
//
// All Rights Reserved.
// Any use of this source code is subject to a license agreement with the
// AUTOSAR development cooperation.
// More information is available at www.autosar.org.
//
// Disclaimer
//
// This work (specification and/or software implementation) and the material
// contained in it, as released by AUTOSAR, is for the purpose of information
// only. AUTOSAR and the companies that have contributed to it shall not be
// liable for any use of the work.
//
// The material contained in this work is protected by copyright and other
// types of intellectual property rights. The commercial exploitation of the
// material contained in this work requires a license to such intellectual
// property rights.
//
// This work may be utilized or reproduced without any modification, in any
// form or by any means, for informational purposes only. For any other
// purpose, no part of the work may be utilized or reproduced, in any form
// or by any means, without permission in writing from the publisher.
//
// The work has been developed for automotive applications only. It has
// neither been developed, nor tested for non-automotive applications.
//
// The word AUTOSAR and the AUTOSAR logo are registered trademarks.
// --------------------------------------------------------------------------

#ifndef PROLOC_PROXY_METHOD_IMPL_H
#define PROLOC_PROXY_METHOD_IMPL_H

#include <exception>
#include <mutex>
#include <utility>
#include <unordered_map>

#include "proloc_method_impl_base.h"

#include "ara/com/internal/proxy/method.h"
#include "ara/com/internal/skeleton/service_base.h"
#include "ara/core/future.h"

namespace ara
{
namespace com
{
namespace internal
{
namespace proloc
{
namespace proxy
{

/**
 * \brief Method implementation for the process local proxy binding
 *
 * Declare the template MethodImpl without an implementation for the general case to force a compilation error if
 * MethodImpl is used with anything else than a MethodDescriptor and a function signature.
 *
 * There will be a specialization for both void and non-void methods.
 *
 */
template <typename MethodDescriptor, typename T>
class MethodImpl;

// Template specialization for MethodImpl using a method descriptor and a non-void function signature
template <typename MethodDescriptor, typename R, typename... Args>
class MethodImpl<MethodDescriptor, R(Args...)> : public internal::proxy::Method<R(Args...)>, public bits::MethodImplBase
{
public:
    using Base = internal::proxy::Method<R(Args...)>;
    using typename Base::result_type;
    using element_type = typename MethodDescriptor::element_type;

    explicit MethodImpl(std::weak_ptr<internal::proloc::skeleton::ServiceImplBase> service)
        : bits::MethodImplBase(service)
    {
    }

    virtual ara::core::Future<result_type> operator()(Args&&... args)
    {
        element_type fct = MethodDescriptor::element;
        std::shared_ptr<ara::com::internal::proloc::skeleton::ServiceImplBase> k = service_.lock();
        if (k == nullptr) {
            throw std::runtime_error("ConnectionLost");
        }
        return k->HandleCall(fct, std::forward<Args>(args)...);
    }
};

// Template specialization for MethodImpl using a method descriptor and a void function signature
template <typename MethodDescriptor, typename... Args>
class MethodImpl<MethodDescriptor, void(Args...)> : public internal::proxy::Method<void(Args...)>,
                                                    public bits::MethodImplBase
{
public:
    using Base = internal::proxy::Method<void(Args...)>;
    using typename Base::result_type;
    using element_type = typename MethodDescriptor::element_type;

    explicit MethodImpl(std::weak_ptr<internal::proloc::skeleton::ServiceImplBase> service)
        : bits::MethodImplBase(service)
    {
    }

    virtual ara::core::Future<void> operator()(Args&&... args)
    {
        element_type fct = MethodDescriptor::element;
        std::shared_ptr<ara::com::internal::proloc::skeleton::ServiceImplBase> k = service_.lock();
        if (k == nullptr) {
            throw std::runtime_error("ConnectionLost");
        }
        return k->HandleVoidCall(fct, std::forward<Args>(args)...);
    }
};

}  // namespace proxy
}  // namespace proloc
}  // namespace internal
}  // namespace com
}  // namespace ara

#endif  // PROLOC_PROXY_METHOD_IMPL_H
