// --------------------------------------------------------------------------
// |              _    _ _______     .----.      _____         _____        |
// |         /\  | |  | |__   __|  .  ____ .    / ____|  /\   |  __ \       |
// |        /  \ | |  | |  | |    .  / __ \ .  | (___   /  \  | |__) |      |
// |       / /\ \| |  | |  | |   .  / / / / v   \___ \ / /\ \ |  _  /       |
// |      / /__\ \ |__| |  | |   . / /_/ /  .   ____) / /__\ \| | \ \       |
// |     /________\____/   |_|   ^ \____/  .   |_____/________\_|  \_\      |
// |                              . _ _  .                                  |
// --------------------------------------------------------------------------
//
// All Rights Reserved.
// Any use of this source code is subject to a license agreement with the
// AUTOSAR development cooperation.
// More information is available at www.autosar.org.
//
// Disclaimer
//
// This work (specification and/or software implementation) and the material
// contained in it, as released by AUTOSAR, is for the purpose of information
// only. AUTOSAR and the companies that have contributed to it shall not be
// liable for any use of the work.
//
// The material contained in this work is protected by copyright and other
// types of intellectual property rights. The commercial exploitation of the
// material contained in this work requires a license to such intellectual
// property rights.
//
// This work may be utilized or reproduced without any modification, in any
// form or by any means, for informational purposes only. For any other
// purpose, no part of the work may be utilized or reproduced, in any form
// or by any means, without permission in writing from the publisher.
//
// The work has been developed for automotive applications only. It has
// neither been developed, nor tested for non-automotive applications.
//
// The word AUTOSAR and the AUTOSAR logo are registered trademarks.
// --------------------------------------------------------------------------

#ifndef PROLOC_SKELETON_EVENT_IMPL_H
#define PROLOC_SKELETON_EVENT_IMPL_H

#include "ara/com/internal/skeleton/event.h"
#include "ara/com/internal/proloc/proxy/proloc_event.h"
#include <list>
#include <mutex>
#include <memory>

namespace ara
{
namespace com
{
namespace internal
{
namespace proloc
{
namespace skeleton
{

template <typename T>
class EventImpl : public virtual internal::skeleton::Event<T>
{
public:
    using Base = internal::skeleton::Event<T>;
    using typename Base::const_reference;
    using EventProxy = internal::proloc::proxy::Event<T>;

    explicit EventImpl(InstanceId instance)
        : instance_(instance)
        , subscribers_()
    {
    }

    virtual ~EventImpl()
    {
    }

    virtual void Send(const_reference data) override
    {
        std::lock_guard<std::mutex> lock(lock_);
        SamplePtr<T> value(new T(data));
        for (EventProxy* p : subscribers_) {
            p->NewValue(value);
        }
    }

    virtual ara::com::SampleAllocateePtr<T> Allocate() override
    {
        return std::make_unique<T>();
    }

    virtual void Send(ara::com::SampleAllocateePtr<T> data) override
    {
        std::lock_guard<std::mutex> lock(lock_);
        active_values_.push_back(ValueObject{std::move(data), subscribers_});
    }

    void Subscribe(EventProxy* subscriber)
    {
        std::lock_guard<std::mutex> lock(lock_);
        subscribers_.push_back(subscriber);
    }

    void Unsubscribe(EventProxy* subscriber)
    {
        std::lock_guard<std::mutex> lock(lock_);
        subscribers_.remove(subscriber);
    }

    void FillQueue(EventProxy* subscriber, typename EventProxy::DataContainer& queue)
    {
        std::lock_guard<std::mutex> lock(lock_);
        for (ValueObject& v : active_values_) {
            v.subscribers_.remove(subscriber);
            queue.push_back(v.data_);
        }
    }

protected:
    InstanceId instance_;
    struct ValueObject
    {
        std::shared_ptr<T> data_;
        std::list<EventProxy*> subscribers_;
    };

    std::list<ValueObject> active_values_;
    std::list<EventProxy*> subscribers_;
    std::mutex lock_;
};

}  // namespace skeleton
}  // namespace proloc
}  // namespace internal
}  // namespace com
}  // namespace ara

#endif  // PROLOC_SKELETON_EVENT_IMPL_H
