// --------------------------------------------------------------------------
// |              _    _ _______     .----.      _____         _____        |
// |         /\  | |  | |__   __|  .  ____ .    / ____|  /\   |  __ \       |
// |        /  \ | |  | |  | |    .  / __ \ .  | (___   /  \  | |__) |      |
// |       / /\ \| |  | |  | |   .  / / / / v   \___ \ / /\ \ |  _  /       |
// |      / /__\ \ |__| |  | |   . / /_/ /  .   ____) / /__\ \| | \ \       |
// |     /________\____/   |_|   ^ \____/  .   |_____/________\_|  \_\      |
// |                              . _ _  .                                  |
// --------------------------------------------------------------------------
//
// All Rights Reserved.
// Any use of this source code is subject to a license agreement with the
// AUTOSAR development cooperation.
// More information is available at www.autosar.org.
//
// Disclaimer
//
// This work (specification and/or software implementation) and the material
// contained in it, as released by AUTOSAR, is for the purpose of information
// only. AUTOSAR and the companies that have contributed to it shall not be
// liable for any use of the work.
//
// The material contained in this work is protected by copyright and other
// types of intellectual property rights. The commercial exploitation of the
// material contained in this work requires a license to such intellectual
// property rights.
//
// This work may be utilized or reproduced without any modification, in any
// form or by any means, for informational purposes only. For any other
// purpose, no part of the work may be utilized or reproduced, in any form
// or by any means, without permission in writing from the publisher.
//
// The work has been developed for automotive applications only. It has
// neither been developed, nor tested for non-automotive applications.
//
// The word AUTOSAR and the AUTOSAR logo are registered trademarks.
// --------------------------------------------------------------------------

#ifndef ARA_DDS_BINDING_INCLUDES_LIBARA_INTERNAL_DDS_PROXY_METHOD_IMPL_H_
#define ARA_DDS_BINDING_INCLUDES_LIBARA_INTERNAL_DDS_PROXY_METHOD_IMPL_H_

#include <exception>
#include <mutex>
#include <utility>
#include <unordered_map>

#include "method_impl_base.h"

#include "ara/com/internal/proxy/method.h"
#include "ara/core/future.h"
#include "ara/core/promise.h"
#include "ara/com/internal/dds/common.h"

namespace ara
{
namespace com
{
namespace internal
{
namespace dds
{
namespace proxy
{

/// \brief Method implementation for dds proxy binding
// Declare the template MethodImpl without an implementation for the general case to force a compilation error if
// MethodImpl is used with anything else than a MethodDescriptor and a function signature
template <typename MethodDescriptor, typename T>
class MethodImpl;

// Template specialization for MethodImpl using a method descriptor and a function signature
template <typename MethodDescriptor, typename R, typename... Args>
class MethodImpl<MethodDescriptor, R(Args...)>
    : public internal::proxy::Method<R(Args...)>
    , public bits::MethodImplBase
{
public:
    using Base = internal::proxy::Method<R(Args...)>;
    using typename Base::result_type;

    /// \brief Ctor
    /// \param instance Instance used for creating the object
    explicit MethodImpl(types::InstanceId instance)
        : bits::MethodImplBase(instance)
    {}

    virtual ara::core::Future<result_type> operator()(Args&&... args)
    {
        ara::core::Promise<result_type> promise;
        return promise.get_future();
    }
};

}  // namespace proxy
}  // namespace dds
}  // namespace internal
}  // namespace com
}  // namespace ara

#endif  // ARA_DDS_BINDING_INCLUDES_LIBARA_INTERNAL_DDS_PROXY_METHOD_IMPL_H_
