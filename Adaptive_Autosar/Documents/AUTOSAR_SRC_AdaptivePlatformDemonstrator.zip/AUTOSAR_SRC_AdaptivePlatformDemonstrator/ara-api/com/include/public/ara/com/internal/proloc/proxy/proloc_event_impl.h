// --------------------------------------------------------------------------
// |              _    _ _______     .----.      _____         _____        |
// |         /\  | |  | |__   __|  .  ____ .    / ____|  /\   |  __ \       |
// |        /  \ | |  | |  | |    .  / __ \ .  | (___   /  \  | |__) |      |
// |       / /\ \| |  | |  | |   .  / / / / v   \___ \ / /\ \ |  _  /       |
// |      / /__\ \ |__| |  | |   . / /_/ /  .   ____) / /__\ \| | \ \       |
// |     /________\____/   |_|   ^ \____/  .   |_____/________\_|  \_\      |
// |                              . _ _  .                                  |
// --------------------------------------------------------------------------
//
// All Rights Reserved.
// Any use of this source code is subject to a license agreement with the
// AUTOSAR development cooperation.
// More information is available at www.autosar.org.
//
// Disclaimer
//
// This work (specification and/or software implementation) and the material
// contained in it, as released by AUTOSAR, is for the purpose of information
// only. AUTOSAR and the companies that have contributed to it shall not be
// liable for any use of the work.
//
// The material contained in this work is protected by copyright and other
// types of intellectual property rights. The commercial exploitation of the
// material contained in this work requires a license to such intellectual
// property rights.
//
// This work may be utilized or reproduced without any modification, in any
// form or by any means, for informational purposes only. For any other
// purpose, no part of the work may be utilized or reproduced, in any form
// or by any means, without permission in writing from the publisher.
//
// The work has been developed for automotive applications only. It has
// neither been developed, nor tested for non-automotive applications.
//
// The word AUTOSAR and the AUTOSAR logo are registered trademarks.
// --------------------------------------------------------------------------

#ifndef PROLOC_PROXY_EVENT_IMPL_H
#define PROLOC_PROXY_EVENT_IMPL_H

#include <mutex>
#include <deque>
#include <stdexcept>
#include <cstddef>
#include <algorithm>

#include "proloc_method_impl.h"
#include "../skeleton/proloc_service_impl_base.h"
#include "../skeleton/proloc_event_impl.h"
#include "proloc_event.h"

#include "ara/com/internal/proxy/field.h"
#include "ara/com/types.h"

namespace ara
{
namespace com
{
namespace internal
{
namespace proloc
{
namespace proxy
{

template <typename EventDescriptor, typename T>
class EventImpl : public virtual internal::proxy::Event<T>, public virtual Event<T>
{
public:
    using const_reference = typename internal::proxy::Event<T>::const_reference;
    using value_type = typename internal::proxy::Event<T>::value_type;
    using pointer_type = typename Event<T>::pointer_type;

    explicit EventImpl(std::weak_ptr<internal::proloc::skeleton::ServiceImplBase> service)
        : service_(service)
        , subscriptionState_(ara::com::SubscriptionState::kNotSubscribed)
    {
    }

    virtual ~EventImpl()
    {
        Unsubscribe();
    }

    /**
     * \uptrace{SWS_CM_00141}
     */
    void Subscribe(ara::com::EventCacheUpdatePolicy policy, std::size_t cache_size) override
    {
        DoSubscribe(policy, cache_size, false);
    }

    bool IsSubscribed() const override
    {
        return subscriptionState_ == ara::com::SubscriptionState::kSubscribed;
    }

    /**
     * \uptrace{SWS_CM_00151}
     */
    void Unsubscribe() override
    {
        std::shared_ptr<proloc::skeleton::ServiceImplBase> p = service_.lock();
        if (p != nullptr) {
            ((std::dynamic_pointer_cast<typename EventDescriptor::adapter>(p)).get()->*(EventDescriptor::element))
                .Unsubscribe(this);
        }
    }

    bool Update() override
    {
        // fast path
        if (policy_ == ara::com::EventCacheUpdatePolicy::kNewestN) {
            std::lock_guard<std::mutex> guard(lock_);
            std::shared_ptr<proloc::skeleton::ServiceImplBase> p = service_.lock();
            working_set_.swap(queue_);
            queue_.clear();
            return !working_set_.empty();
        } else {
            return Update({});
        }
    }

    /**
     * \brief Update the internal caches of this Event instance with new data from the event source, filtering the data.
     * \uptrace{SWS_CM_00172}
     */
    bool Update(ara::com::FilterFunction<T> filter) override
    {
        std::lock_guard<std::mutex> guard(lock_);

        working_set_.clear();
        if (policy_ == ara::com::EventCacheUpdatePolicy::kNewestN) {
            std::copy_if(std::make_move_iterator(queue_.begin()),
                std::make_move_iterator(queue_.end()),
                std::back_inserter(working_set_),
                [filter](const pointer_type& val) { return filter ? filter(*val) : true; });
            queue_.clear();
        } else {
            std::copy_if(
                queue_.begin(), queue_.end(), std::back_inserter(working_set_), [filter](const pointer_type& val) {
                    return filter ? filter(*val) : true;
                });
        }
        return !working_set_.empty();
    }

    /**
     * \uptrace{SWS_CM_00174}
     */
    void Cleanup() override
    {
        std::lock_guard<std::mutex> guard(lock_);
        queue_.clear();
        working_set_.clear();
    }

    /**
     * \uptrace{SWS_CM_00181}
     * \uptrace{SWS_CM_00309}
     */
    void SetReceiveHandler(ara::com::EventReceiveHandler handler) override
    {
        std::lock_guard<std::mutex> guard(handler_lock_);
        receive_handler_ = handler;
    }

    /**
     * \uptrace{SWS_CM_00183}
     */
    void UnsetReceiveHandler() override
    {
        std::lock_guard<std::mutex> guard(handler_lock_);
        receive_handler_ = nullptr;
    }

    void SetSubscriptionStateChangeHandler(ara::com::SubscriptionStateChangeHandler handler) override
    {
        std::lock_guard<std::mutex> guard(lock_);
        state_change_handler_ = handler;
    }

    void UnsetSubscriptionStateChangeHandler() override
    {
        std::lock_guard<std::mutex> guard(lock_);
        state_change_handler_ = nullptr;
    }

    std::size_t size() const override
    {
        return working_set_.size();
    }

    void SubscriptionLost() override
    {
        std::lock_guard<std::mutex> guard(lock_);
        setSubscriptionState(ara::com::SubscriptionState::kNotSubscribed);
    }

    void NewValue(SamplePtr<T> data) override
    {
        queue_.emplace_back(data);
        std::lock_guard<std::mutex> guard(handler_lock_);
        if (receive_handler_)
            receive_handler_();
    }

protected:
    const SamplePtr<value_type>& at(std::size_t index) const override
    {
        return working_set_.at(index);
    }

    void DoSubscribe(ara::com::EventCacheUpdatePolicy policy, std::size_t cache_size, bool is_field)
    {
        std::shared_ptr<proloc::skeleton::ServiceImplBase> p = service_.lock();
        if (p != nullptr) {
            ((std::dynamic_pointer_cast<typename EventDescriptor::adapter>(p)).get()->*(EventDescriptor::element))
                .Subscribe(this);
        }
    }

private:
    InstanceId instance_id_;
    std::weak_ptr<internal::proloc::skeleton::ServiceImplBase> service_;
    typename Event<T>::DataContainer queue_;
    typename Event<T>::DataContainer working_set_;
    std::mutex lock_;
    std::mutex handler_lock_;
    ara::com::EventReceiveHandler receive_handler_;
    ara::com::SubscriptionStateChangeHandler state_change_handler_;
    ara::com::SubscriptionState subscriptionState_;
    ara::com::EventCacheUpdatePolicy policy_{ara::com::EventCacheUpdatePolicy::kNewestN};
    std::size_t cache_size_{1};
#ifndef ARA_COM_LEAN
    std::size_t num_overflow_{0};
#endif

    void setSubscriptionState(ara::com::SubscriptionState state)
    {
        subscriptionState_ = state;
        std::unique_lock<std::mutex> lock(lock_);
        ara::com::SubscriptionStateChangeHandler state_change_handler = state_change_handler_;
        lock.unlock();
        if (state_change_handler) {
            state_change_handler(state);
        }
    }
};

}  // namespace proxy
}  // namespace proloc
}  // namespace internal
}  // namespace com
}  // namespace ara

#endif  // PROLOC_PROXY_EVENT_IMPL_H
