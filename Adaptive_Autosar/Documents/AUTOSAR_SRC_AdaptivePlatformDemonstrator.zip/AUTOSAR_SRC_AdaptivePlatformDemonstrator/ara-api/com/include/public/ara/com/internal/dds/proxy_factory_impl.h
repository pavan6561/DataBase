// --------------------------------------------------------------------------
// |              _    _ _______     .----.      _____         _____        |
// |         /\  | |  | |__   __|  .  ____ .    / ____|  /\   |  __ \       |
// |        /  \ | |  | |  | |    .  / __ \ .  | (___   /  \  | |__) |      |
// |       / /\ \| |  | |  | |   .  / / / / v   \___ \ / /\ \ |  _  /       |
// |      / /__\ \ |__| |  | |   . / /_/ /  .   ____) / /__\ \| | \ \       |
// |     /________\____/   |_|   ^ \____/  .   |_____/________\_|  \_\      |
// |                              . _ _  .                                  |
// --------------------------------------------------------------------------
//
// All Rights Reserved.
// Any use of this source code is subject to a license agreement with the
// AUTOSAR development cooperation.
// More information is available at www.autosar.org.
//
// Disclaimer
//
// This work (specification and/or software implementation) and the material
// contained in it, as released by AUTOSAR, is for the purpose of information
// only. AUTOSAR and the companies that have contributed to it shall not be
// liable for any use of the work.
//
// The material contained in this work is protected by copyright and other
// types of intellectual property rights. The commercial exploitation of the
// material contained in this work requires a license to such intellectual
// property rights.
//
// This work may be utilized or reproduced without any modification, in any
// form or by any means, for informational purposes only. For any other
// purpose, no part of the work may be utilized or reproduced, in any form
// or by any means, without permission in writing from the publisher.
//
// The work has been developed for automotive applications only. It has
// neither been developed, nor tested for non-automotive applications.
//
// The word AUTOSAR and the AUTOSAR logo are registered trademarks.
// --------------------------------------------------------------------------

#ifndef ARA_DDS_BINDING_INCLUDES_LIBARA_INTERNAL_DDS_PROXY_FACTORY_IMPL_H_
#define ARA_DDS_BINDING_INCLUDES_LIBARA_INTERNAL_DDS_PROXY_FACTORY_IMPL_H_

#include <mutex>
#include <set>
#include <map>

#include "ara/com/types.h"
#include "ara/com/instance_identifier.h"
#include "ara/com/internal/proxy_factory_builder.h"
#include "ara/com/internal/proxy/proxy_factory.h"
#include "ara/com/internal/proxy/proxy_binding_base.h"

#include "ara/com/internal/dds/common.h"

#include <dds/sub/ddssub.hpp>
#include <dds/domain/find.hpp>
#include <dds/core/BuiltinTopicTypes.hpp>
#include <dds/topic/BuiltinTopic.hpp>

#ifdef _UT_BUILD_
#    include "mocks.h"
#    define ns_dds ::mocks::dds
#else
#    define ns_dds ::dds
#endif  // _UT_BUILD_

namespace ara
{
namespace com
{
namespace internal
{
namespace dds
{
namespace runtime
{

template <typename ProxyImpl>
class ProxyFactoryImpl : public internal::proxy::ProxyFactory
{
public:
    /// \brief Creates a factory instance by binding it to the instance for which proxies shall be created.
    /// \param instance The instance the created proxies shall be bound to.
    ProxyFactoryImpl(InstanceId instance)
        : ProxyFactory(instance)
    {}

    std::unique_ptr<internal::proxy::ProxyBindingBase> Create() const override
    {
        return std::make_unique<ProxyImpl>(static_cast<InstanceId>(instance_));
    }
};

using ParticipantTopic = ns_dds::topic::ParticipantBuiltinTopicData;
using ParticipantReader = ns_dds::sub::DataReader<ParticipantTopic>;

class DdsProxyFactoryImpl
    : public internal::runtime::ProxyFactoryBuilder
    , private ns_dds::sub::DataReaderListener<ParticipantTopic>
{
public:
    DdsProxyFactoryImpl();
    virtual ~DdsProxyFactoryImpl();

    // For FindService
    /// \uptrace{SWS_CM_11006}
    virtual std::vector<std::shared_ptr<internal::proxy::ProxyFactory>> createInstance(ServiceId serviceId,
        InstanceId instanceId) override;

    // For StartFindService
    /// \uptrace{SWS_CM_11010}
    virtual void RegisterFindServiceHandle(FindServiceHandle handle, ProxyFactoryCallback callback) override;

    // For StopFindService
    virtual void UnregisterFindServiceHandle(FindServiceHandle handle) override;

    /// \uptrace{SWS_CM_11006}
    /// \uptrace{SWS_CM_11007}
    /// \uptrace{SWS_CM_11009}
    std::vector<InstanceId> FindService(const ServiceId& serviceId, const InstanceId& instanceId);

private:
#ifdef _UT_BUILD_
public:
#endif

    bool isSetup() const;
    void setup();

    struct ServiceRecord
    {
        ServiceId serviceId_;
        InstanceId instanceId_;
        friend bool operator<(const ServiceRecord& a, const ServiceRecord& b)
        {
            bool result = false;
            if (a.serviceId_ < b.serviceId_) {
                result = true;
            } else if (a.serviceId_ == b.serviceId_) {
                result = a.instanceId_ < b.instanceId_;
            }
            return result;
        }
    };
    using ServiceList = std::set<ServiceRecord>;
    static ServiceList parseServiceList(const std::string& string);

    const types::DomainId domainId_;
    ns_dds::domain::DomainParticipant participant_;
    ParticipantReader participantReader_;

    // We need a recursive mutex as the handlers aren't thread safe AND may call any method of ara::com during callback
    // processing.
    using Mutex = std::recursive_mutex;
    Mutex mutex_;

    struct FindServiceHandleComparator
    {
        bool operator()(const FindServiceHandle& lhs, const FindServiceHandle& rhs) const;
    };

    struct FindServiceInfo
    {
        ProxyFactoryCallback callback;
    };

    using FindServiceHandleList = std::multimap<FindServiceHandle, FindServiceInfo, FindServiceHandleComparator>;
    FindServiceHandleList findHandles_;  ///< List of running StartFindService requests.
    ServiceList availableServices_;  ///< List of available services.

    void handleServiceAvailabilityChange(const ServiceId& serviceId, const InstanceId& instanceId, bool available);

private:  // DataReaderListener
    void on_requested_deadline_missed(ns_dds::sub::DataReader<ParticipantTopic>&,
        const ns_dds::core::status::RequestedDeadlineMissedStatus&) override;

    void on_requested_incompatible_qos(ns_dds::sub::DataReader<ParticipantTopic>&,
        const ns_dds::core::status::RequestedIncompatibleQosStatus&) override;

    void on_sample_rejected(ns_dds::sub::DataReader<ParticipantTopic>&,
        const ns_dds::core::status::SampleRejectedStatus&) override;

    void on_liveliness_changed(ns_dds::sub::DataReader<ParticipantTopic>&,
        const ns_dds::core::status::LivelinessChangedStatus&) override;

    void on_data_available(ns_dds::sub::DataReader<ParticipantTopic>& reader) override;

    void on_subscription_matched(ns_dds::sub::DataReader<ParticipantTopic>&,
        const ns_dds::core::status::SubscriptionMatchedStatus&) override;

    void on_sample_lost(ns_dds::sub::DataReader<ParticipantTopic>&,
        const ns_dds::core::status::SampleLostStatus&) override;
};

}  // namespace runtime
}  // namespace dds
}  // namespace internal
}  // namespace com
}  // namespace ara

#endif  // ARA_DDS_BINDING_INCLUDES_LIBARA_INTERNAL_DDS_PROXY_FACTORY_IMPL_H_
