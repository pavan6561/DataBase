// --------------------------------------------------------------------------
// |              _    _ _______     .----.      _____         _____        |
// |         /\  | |  | |__   __|  .  ____ .    / ____|  /\   |  __ \       |
// |        /  \ | |  | |  | |    .  / __ \ .  | (___   /  \  | |__) |      |
// |       / /\ \| |  | |  | |   .  / / / / v   \___ \ / /\ \ |  _  /       |
// |      / /__\ \ |__| |  | |   . / /_/ /  .   ____) / /__\ \| | \ \       |
// |     /________\____/   |_|   ^ \____/  .   |_____/________\_|  \_\      |
// |                              . _ _  .                                  |
// --------------------------------------------------------------------------
//
// All Rights Reserved.
// Any use of this source code is subject to a license agreement with the
// AUTOSAR development cooperation.
// More information is available at www.autosar.org.
//
// Disclaimer
//
// This work (specification and/or software implementation) and the material
// contained in it, as released by AUTOSAR, is for the purpose of information
// only. AUTOSAR and the companies that have contributed to it shall not be
// liable for any use of the work.
//
// The material contained in this work is protected by copyright and other
// types of intellectual property rights. The commercial exploitation of the
// material contained in this work requires a license to such intellectual
// property rights.
//
// This work may be utilized or reproduced without any modification, in any
// form or by any means, for informational purposes only. For any other
// purpose, no part of the work may be utilized or reproduced, in any form
// or by any means, without permission in writing from the publisher.
//
// The work has been developed for automotive applications only. It has
// neither been developed, nor tested for non-automotive applications.
//
// The word AUTOSAR and the AUTOSAR logo are registered trademarks.
// --------------------------------------------------------------------------

#ifndef ARA_DDS_BINDING_INCLUDES_LIBARA_INTERNAL_DDS_PROXY_MUTABLE_FIELD_IMPL_H_
#define ARA_DDS_BINDING_INCLUDES_LIBARA_INTERNAL_DDS_PROXY_MUTABLE_FIELD_IMPL_H_

#include "ara/com/internal/proxy/mutable_field.h"
#include "field_impl.h"

namespace ara
{
namespace com
{
namespace internal
{
namespace dds
{
namespace proxy
{

/// \brief Implementation for mutable field interface for proxy side
template <typename FieldDescriptor, typename T>
class MutableFieldImpl
    : public FieldImpl<FieldDescriptor, T>
    , public internal::proxy::MutableField<T>
{
public:
    MutableFieldImpl(types::InstanceId instance_id)
        : internal::proxy::Field<T>(FieldImpl<FieldDescriptor, T>::get_method_)
        , FieldImpl<FieldDescriptor, T>(instance_id)
        , internal::proxy::MutableField<T>(FieldImpl<FieldDescriptor, T>::get_method_, set_method_)
        , set_method_(instance_id)
    {}

private:
    MethodImpl<MakeSetMethodDescriptorFrom<FieldDescriptor>,
        typename internal::proxy::MutableField<T>::MethodSet::signature_type>
        set_method_;
};

}  // namespace proxy
}  // namespace dds
}  // namespace internal
}  // namespace com
}  // namespace ara

#endif  // ARA_DDS_BINDING_INCLUDES_LIBARA_INTERNAL_DDS_PROXY_MUTABLE_FIELD_IMPL_H_
