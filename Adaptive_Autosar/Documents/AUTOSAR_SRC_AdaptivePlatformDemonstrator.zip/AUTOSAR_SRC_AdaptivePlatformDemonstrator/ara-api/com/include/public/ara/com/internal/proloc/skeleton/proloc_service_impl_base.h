// --------------------------------------------------------------------------
// |              _    _ _______     .----.      _____         _____        |
// |         /\  | |  | |__   __|  .  ____ .    / ____|  /\   |  __ \       |
// |        /  \ | |  | |  | |    .  / __ \ .  | (___   /  \  | |__) |      |
// |       / /\ \| |  | |  | |   .  / / / / v   \___ \ / /\ \ |  _  /       |
// |      / /__\ \ |__| |  | |   . / /_/ /  .   ____) / /__\ \| | \ \       |
// |     /________\____/   |_|   ^ \____/  .   |_____/________\_|  \_\      |
// |                              . _ _  .                                  |
// --------------------------------------------------------------------------
//
// All Rights Reserved.
// Any use of this source code is subject to a license agreement with the
// AUTOSAR development cooperation.
// More information is available at www.autosar.org.
//
// Disclaimer
//
// This work (specification and/or software implementation) and the material
// contained in it, as released by AUTOSAR, is for the purpose of information
// only. AUTOSAR and the companies that have contributed to it shall not be
// liable for any use of the work.
//
// The material contained in this work is protected by copyright and other
// types of intellectual property rights. The commercial exploitation of the
// material contained in this work requires a license to such intellectual
// property rights.
//
// This work may be utilized or reproduced without any modification, in any
// form or by any means, for informational purposes only. For any other
// purpose, no part of the work may be utilized or reproduced, in any form
// or by any means, without permission in writing from the publisher.
//
// The work has been developed for automotive applications only. It has
// neither been developed, nor tested for non-automotive applications.
//
// The word AUTOSAR and the AUTOSAR logo are registered trademarks.
// --------------------------------------------------------------------------

#ifndef COMMUNICATIONMIDDLEWARE_PROLOC_SERVICE_IMPL_BASE_H
#define COMMUNICATIONMIDDLEWARE_PROLOC_SERVICE_IMPL_BASE_H

#include "ara/core/future.h"
#include "ara/core/promise.h"
#include "ara/com/internal/skeleton/ara_skeleton_base.h"
#include "ara/com/illegal_state_exception.h"
#include <deque>
#include <memory>

namespace ara
{
namespace com
{
namespace internal
{
namespace proloc
{
namespace skeleton
{

class ServiceImplBase : public internal::skeleton::ServiceImplBase
{
public:
    ServiceImplBase(internal::skeleton::ServiceBase& service, ::ara::com::InstanceIdentifier instance)
        : internal::skeleton::ServiceImplBase(instance)
        , service_(service)
    {
    }
    virtual ~ServiceImplBase()
    {
    }

    virtual void SetMethodCallProcessingMode(ara::com::MethodCallProcessingMode mode) override
    {
        // execute remaining requests in case we're switching away from kPoll
        std::lock_guard<std::mutex> guard(requests_mutex_);
        if ((request_processing_mode_ == MethodCallProcessingMode::kPoll)
            && (mode != MethodCallProcessingMode::kPoll)) {
            for (PendingRequest& request : pending_requests_) {
                request();
            }
            pending_requests_.clear();
        }

        request_processing_mode_ = mode;
    }

    virtual ara::core::Future<bool> ProcessNextMethodCall() override
    {
        PendingRequest request;
        {
            std::lock_guard<std::mutex> guard(requests_mutex_);

            if (request_processing_mode_ != MethodCallProcessingMode::kPoll) {
                throw IllegalStateException("ProcessNextMethodCall() called in non-polling mode!");
            }

            if (!pending_requests_.empty()) {
                request = std::move(pending_requests_.front());
                pending_requests_.pop_front();
            }
        }

        ara::core::Promise<bool> promise;
        if (request) {
            // TODO: Make this truly async
            request();
            promise.set_value(true);
        } else {
            promise.set_value(false);
        }

        return promise.get_future();
    }

    InstanceId GetInstanceId() const
    {
        return static_cast<InstanceId>(internal::skeleton::ServiceImplBase::GetInstanceId());
    }

    /**
     * \brief HandleCall for non-void(...) functions
     */
    template <typename Class, typename R, typename... Args>
    ara::core::Future<R> HandleCall(ara::core::Future<R> (Class::*method)(Args...), Args&&... args)
    {
        ara::core::Promise<R> call_result;
        auto call_future = call_result.get_future();
        PendingRequest todo;
        Class* p = dynamic_cast<Class*>(&service_);
        todo = [p, method, &call_result, args...]() {
            ara::core::Future<R> result = (p->*method)(args...);
            try {
                call_result.set_value(result.get());
            } catch (ApplicationErrorException& e) {
                call_result.set_exception(std::current_exception());
            }
        };
        ExecuteCall(std::move(todo));
        return call_future;
    }

    /**
     * \brief HandleCall for void(...) functions
     */
    template <typename Class, typename... Args>
    ara::core::Future<void> HandleVoidCall(ara::core::Future<void> (Class::*method)(Args...), Args&&... args)
    {
        ara::core::Promise<void> call_result;
        auto call_future = call_result.get_future();
        PendingRequest todo;
        Class* p = dynamic_cast<Class*>(&service_);
        todo = [p, method, &call_result, args...]() {
            ara::core::Future<void> result = (p->*method)(args...);
            try {
                result.get();
                call_result.set_value();
            } catch (ApplicationErrorException& e) {
                call_result.set_exception(std::current_exception());
            }
        };
        ExecuteCall(std::move(todo));
        return call_future;
    }

    template <typename R, typename T, typename P>
    ara::core::Future<T> HandleGetter(P member)
    {
        ara::core::Promise<T> call_result;
        auto call_future = call_result.get_future();
        PendingRequest todo;
        todo = [this, member, &call_result]() {
            auto b = static_cast<R*>(this);
            auto c = (b->*member).Get();
            call_result.set_value(c);
        };
        ExecuteCall(std::move(todo));
        return call_future;
    }
    template <typename R, typename T, typename V, typename P>
    ara::core::Future<T> HandleSetter(P member, V value)
    {
        ara::core::Promise<T> call_result;
        auto call_future = call_result.get_future();
        PendingRequest todo;
        todo = [this, member, &call_result, value]() {
            auto b = static_cast<R*>(this);
            (b->*member).Set(value);
            call_result.set_value();
        };
        ExecuteCall(std::move(todo));
        return call_future;
    }

protected:
    internal::skeleton::ServiceBase& service_;

private:
    using PendingRequest = std::function<void(void)>;
    using PendingRequestList = std::deque<PendingRequest>;

    void ExecuteCall(PendingRequest&& request)
    {
        std::unique_lock<std::mutex> lock(requests_mutex_);
        if (request_processing_mode_ == MethodCallProcessingMode::kEvent) {
            lock.unlock();
            auto t = std::thread(request);
            t.detach();
        } else if (request_processing_mode_ == MethodCallProcessingMode::kPoll) {
            pending_requests_.push_back(std::move(request));
        } else {
            lock.unlock();
            request();
        }
    }

    PendingRequestList pending_requests_;
    MethodCallProcessingMode request_processing_mode_{MethodCallProcessingMode::kEventSingleThread};
    std::mutex requests_mutex_;
};
}
}
}
}
}

#endif  // COMMUNICATIONMIDDLEWARE_PROLOC_SERVICE_IMPL_BASE_H
