// --------------------------------------------------------------------------
// |              _    _ _______     .----.      _____         _____        |
// |         /\  | |  | |__   __|  .  ____ .    / ____|  /\   |  __ \       |
// |        /  \ | |  | |  | |    .  / __ \ .  | (___   /  \  | |__) |      |
// |       / /\ \| |  | |  | |   .  / / / / v   \___ \ / /\ \ |  _  /       |
// |      / /__\ \ |__| |  | |   . / /_/ /  .   ____) / /__\ \| | \ \       |
// |     /________\____/   |_|   ^ \____/  .   |_____/________\_|  \_\      |
// |                              . _ _  .                                  |
// --------------------------------------------------------------------------
//
// All Rights Reserved.
// Any use of this source code is subject to a license agreement with the
// AUTOSAR development cooperation.
// More information is available at www.autosar.org.
//
// Disclaimer
//
// This work (specification and/or software implementation) and the material
// contained in it, as released by AUTOSAR, is for the purpose of information
// only. AUTOSAR and the companies that have contributed to it shall not be
// liable for any use of the work.
//
// The material contained in this work is protected by copyright and other
// types of intellectual property rights. The commercial exploitation of the
// material contained in this work requires a license to such intellectual
// property rights.
//
// This work may be utilized or reproduced without any modification, in any
// form or by any means, for informational purposes only. For any other
// purpose, no part of the work may be utilized or reproduced, in any form
// or by any means, without permission in writing from the publisher.
//
// The work has been developed for automotive applications only. It has
// neither been developed, nor tested for non-automotive applications.
//
// The word AUTOSAR and the AUTOSAR logo are registered trademarks.
// --------------------------------------------------------------------------

#ifndef ARA_DDS_BINDING_INCLUDES_LIBARA_INTERNAL_DDS_SKELETON_SERVICE_IMPL_BASE_H_
#define ARA_DDS_BINDING_INCLUDES_LIBARA_INTERNAL_DDS_SKELETON_SERVICE_IMPL_BASE_H_

#include <deque>
#include <mutex>

#include "ara/com/types.h"
#include "ara/core/future.h"
#include "ara/core/promise.h"
#include "ara/com/illegal_state_exception.h"
#include "ara/com/internal/skeleton/service_impl_base.h"
#include "ara/com/internal/dds/common.h"

#include <dds/pub/ddspub.hpp>
#include <dds/domain/find.hpp>
#include <dds/topic/find.hpp>

#ifdef _UT_BUILD_
#    include "mocks.h"
#    define ns_dds ::mocks::dds
#else
#    define ns_dds ::dds
#endif  // _UT_BUILD_

#include "ara/com/internal/dds/skeleton/event_impl.h"

namespace ara
{
namespace com
{
namespace internal
{
namespace dds
{
namespace skeleton
{

/// \brief Service base implementation for Skeleton interface
class ServiceImplBase : public internal::skeleton::ServiceImplBase
{
public:
    using testtype = void;

    /// \brief Construct a service
    /// \param domainId Domain Id this service shall belong to
    /// \param service ???
    /// \param instance Instanceof the service
    /// \uptrace{SWS_CM_11001}
    /// \uptrace{SWS_CM_11002}
    ServiceImplBase(const types::DomainId& domainId,
        internal::skeleton::ServiceBase& service,
        const ara::com::internal::dds::types::ServiceId& serviceId,
        const ::ara::com::InstanceIdentifier& instance);

    virtual ~ServiceImplBase();

    /// \uptrace{SWS_CM_11001}
    /// \uptrace{SWS_CM_11002}
    void OfferService();

    /// \uptrace{SWS_CM_11005}
    void StopOfferService();

    /// \uptrace{SWS_CM_11003}
    /// \uptrace{SWS_CM_11015}
    template <typename EventImpl>
    void OfferEvent(EventImpl& event)
    {
        assert(IsOffered());

        if (!event.IsOffered()) {
            // Try to peek a topic 1st, it might be already here
            using TopicType = ns_dds::topic::Topic<SampleEventType>;
            ns_dds::topic::Topic<SampleEventType> topic
                = ns_dds::topic::find<TopicType>(participant_, EventImpl::descriptor_type::topicName_);

            // If topic is not here create a new one
            if (topic == ns_dds::core::null) {
                topic = ns_dds::topic::Topic<SampleEventType>(participant_, EventImpl::descriptor_type::topicName_);
            }
            assert(topic != ns_dds::core::null);

            // Create a DataWriter
            ns_dds::pub::DataWriter<SampleEventType> writer(publisher_, topic);

            event.Setup(topic, writer);
        }
    }

    template <typename EventImpl>
    void StopOfferEvent(EventImpl& event)
    {
        event.Setup(event.topic(), ns_dds::core::null);
    }

private:
#ifdef _UT_BUILD_
public:
#endif
    bool IsOffered() const;

    /// \brief Append service and instance to domain participant
    /// \uptrace{SWS_CM_11004}
    static void appendServiceAndInstance(ns_dds::domain::DomainParticipant& participant,
        const types::ServiceId& serviceId,
        const ara::com::internal::InstanceId& instanceId);

    /// \brief Remove  service and instance from domain participant
    /// \uptrace{SWS_CM_11005}
    static void removeServiceAndInstance(ns_dds::domain::DomainParticipant& participant,
        const types::ServiceId& serviceId,
        const ara::com::internal::InstanceId& instanceId);

    const types::DomainId domainId_;
    internal::skeleton::ServiceBase& service_;
    const types::ServiceId serviceId_;
    const ::ara::com::InstanceIdentifier instanceId_;
    const std::string stringId_;
    ns_dds::domain::DomainParticipant participant_;
    ns_dds::pub::Publisher publisher_;
};

}  // namespace skeleton
}  // namespace dds
}  // namespace internal
}  // namespace com
}  // namespace ara

#endif  // ARA_DDS_BINDING_INCLUDES_LIBARA_INTERNAL_DDS_SKELETON_SERVICE_IMPL_BASE_H_
