// --------------------------------------------------------------------------
// |              _    _ _______     .----.      _____         _____        |
// |         /\  | |  | |__   __|  .  ____ .    / ____|  /\   |  __ \       |
// |        /  \ | |  | |  | |    .  / __ \ .  | (___   /  \  | |__) |      |
// |       / /\ \| |  | |  | |   .  / / / / v   \___ \ / /\ \ |  _  /       |
// |      / /__\ \ |__| |  | |   . / /_/ /  .   ____) / /__\ \| | \ \       |
// |     /________\____/   |_|   ^ \____/  .   |_____/________\_|  \_\      |
// |                              . _ _  .                                  |
// --------------------------------------------------------------------------
//
// All Rights Reserved.
// Any use of this source code is subject to a license agreement with the
// AUTOSAR development cooperation.
// More information is available at www.autosar.org.
//
// Disclaimer
//
// This work (specification and/or software implementation) and the material
// contained in it, as released by AUTOSAR, is for the purpose of information
// only. AUTOSAR and the companies that have contributed to it shall not be
// liable for any use of the work.
//
// The material contained in this work is protected by copyright and other
// types of intellectual property rights. The commercial exploitation of the
// material contained in this work requires a license to such intellectual
// property rights.
//
// This work may be utilized or reproduced without any modification, in any
// form or by any means, for informational purposes only. For any other
// purpose, no part of the work may be utilized or reproduced, in any form
// or by any means, without permission in writing from the publisher.
//
// The work has been developed for automotive applications only. It has
// neither been developed, nor tested for non-automotive applications.
//
// The word AUTOSAR and the AUTOSAR logo are registered trademarks.
// --------------------------------------------------------------------------

#ifndef ARA_DDS_BINDING_INCLUDES_LIBARA_INTERNAL_DDS_PROXY_METHOD_IMPL_BASE_H_
#define ARA_DDS_BINDING_INCLUDES_LIBARA_INTERNAL_DDS_PROXY_METHOD_IMPL_BASE_H_

#include "ara/com/exception.h"
#include "ara/core/promise.h"

#include "ara/com/internal/proxy/method_base.h"
#include "ara/com/internal/dds/common.h"

namespace ara
{
namespace com
{
namespace internal
{
namespace dds
{
namespace proxy
{
namespace bits
{

/// \brief Implementation for method interface for dds proxy side
class MethodImplBase : public virtual internal::proxy::bits::MethodBase
{
public:
    explicit MethodImplBase(types::InstanceId instance)
        : instance_(instance)
    {}
    virtual ~MethodImplBase()
    {}

protected:
    std::mutex pending_requests_lock_;
    types::InstanceId instance_;

private:
    /// \brief Call the method when response is an excepton
    ///
    /// If the response status code is an exception rather a valid result
    /// then it deserialize the exception and set it.
    /// \param result Result set for ara::core::Promise
    /// \param response Response recieved from dds daemon
    template <typename R>
    void SetError(ara::core::Promise<R>&& result, const std::shared_ptr<::dds::message>& response)
    {}

    /// \brief Sets the promise to result
    /// \param result ara::core::Promise that hold the result
    /// \param response Message response for deserialization
    template <typename R>
    void SetResult(ara::core::Promise<R>&& result, const std::shared_ptr<::dds::message>& response)
    {}

    void SetResult(ara::core::Promise<void>&& result, const std::shared_ptr<::dds::message>& response)
    {
        (void)(result);
        (void)(response);
        result.set_value();
    }
};

}  // namespace bits
}  // namespace proxy
}  // namespace dds
}  // namespace internal
}  // namespace com
}  // namespace ara

#endif  // ARA_DDS_BINDING_INCLUDES_LIBARA_INTERNAL_DDS_PROXY_METHOD_IMPL_BASE_H_
