#  --------------------------------------------------------------------------
#  |              _    _ _______     .----.      _____         _____        |
#  |         /\  | |  | |__   __|  .  ____ .    / ____|  /\   |  __ \       |
#  |        /  \ | |  | |  | |    .  / __ \ .  | (___   /  \  | |__) |      |
#  |       / /\ \| |  | |  | |   .  / / / / v   \___ \ / /\ \ |  _  /       |
#  |      / /__\ \ |__| |  | |   . / /_/ /  .   ____) / /__\ \| | \ \       |
#  |     /________\____/   |_|   ^ \____/  .   |_____/________\_|  \_\      |
#  |                              . _ _  .                                  |
#  --------------------------------------------------------------------------
#
#  All Rights Reserved.
#  Any use of this source code is subject to a license agreement with the
#  AUTOSAR development cooperation.
#  More information is available at www.autosar.org.
#
#  Disclaimer
#
#  This work (specification and/or software implementation) and the material
#  contained in it, as released by AUTOSAR, is for the purpose of information
#  only. AUTOSAR and the companies that have contributed to it shall not be
#  liable for any use of the work.
#
#  The material contained in this work is protected by copyright and other
#  types of intellectual property rights. The commercial exploitation of the
#  material contained in this work requires a license to such intellectual
#  property rights.
#
#  This work may be utilized or reproduced without any modification, in any
#  form or by any means, for informational purposes only. For any other
#  purpose, no part of the work may be utilized or reproduced, in any form
#  or by any means, without permission in writing from the publisher.
#
#  The work has been developed for automotive applications only. It has
#  neither been developed, nor tested for non-automotive applications.
#
#  The word AUTOSAR and the AUTOSAR logo are registered trademarks.
#  --------------------------------------------------------------------------


# Define default settings for compiler options, build type, etc.
include(CMakeDependentOption)

macro(apd_defaults)

    # Set our preferred CMAKE_BUILD_TYPE.
    #
    # You can not simply use set(CMAKE_BUILD_TYPE ... CACHE ...) as CMake actually defaults
    # to a defined (but empty) value for CMAKE_BUILD_TYPE. Thus the override never takes
    # effect.
    #
    if(NOT CMAKE_BUILD_TYPE)
        set(CMAKE_BUILD_TYPE "Debug" CACHE STRING
            "Choose the type of build, one of: Debug, Release, RelWithDebInfo, MinSizeRel"
            FORCE)
    endif()

    # We always want these flags enabled.
    # If any project really needs to disable one of these, they can do so by adding
    # the -Wno-* equivalent of these to their target's attributes, which then overrides
    # the earlier given flag.
    list(APPEND _apd_common_warning_flags
        -Wall
        -Wdeprecated
        -Wextra
        -Wfloat-equal           # floating-point values are used in equality comparisons
        -Wpedantic
        -Wshadow                # a local variable or type declaration shadows another variable, parameter, type, class member, ...
        -Wuninitialized         # an automatic variable is used without first being initialized
        -Wunused                # an unused parameter, variable, function, label, local typedef, value is encountered
        )

    list(APPEND _apd_c_only_warning_flags
        -Wcast-align            # a pointer is cast such that the required alignment of the target is increased
        -Wcast-qual             # a pointer is cast so as to remove a type qualifier
        -Wconversion            # implicit conversions that may alter a value
        -Winit-self             # an uninitialized variable is initialized with itselves
        -Wmissing-include-dirs  # a user-supplied include directory does not exist
        -Wredundant-decls       # anything is declared more than once in the same scope
        -Wwrite-strings         # give string constants the type "const char[length]", and warn about loss of constness when copying
        -Wsign-conversion       # implicit conversions that may change the sign of an integer value
        -Wstrict-prototypes     # a function is declared or defined without specifying the argument types
        )

    list(APPEND _apd_cxx_only_warning_flags
        -Wctor-dtor-privacy     # a class seems unusable because all the constructors or destructors in that class are private
        -Wnon-virtual-dtor      # class has virtual functions and an accessible non-virtual destructor
        -Wold-style-cast        # an old-style (C-style) cast to a non-void type is used
        -Woverloaded-virtual    # a function declaration hides virtual functions from a base class
        -Wsign-promo            # overload resolution chooses a promotion from unsigned type to a signed type
        )

    add_compile_options("$<$<OR:$<C_COMPILER_ID:GNU>,$<CXX_COMPILER_ID:GNU>>:${_apd_common_warning_flags}>")
    if(CMAKE_C_COMPILER_LOADED)
        add_compile_options("$<$<AND:$<C_COMPILER_ID:GNU>,$<COMPILE_LANGUAGE:C>>:${_apd_c_only_warning_flags}>")
    endif()
    if(CMAKE_CXX_COMPILER_LOADED)
        add_compile_options("$<$<AND:$<CXX_COMPILER_ID:GNU>,$<COMPILE_LANGUAGE:CXX>>:${_apd_cxx_only_warning_flags}>")
    endif()

    unset(_apd_cxx_only_warning_flags)
    unset(_apd_c_only_warning_flags)
    unset(_apd_common_warning_flags)

    # Parts of our code base are known to violate the Strict Aliasing Rule.
    add_compile_options("$<$<OR:$<C_COMPILER_ID:GNU>,$<CXX_COMPILER_ID:GNU>>:-fno-strict-aliasing>")

    # This is needed for full standards-compliant handling of static destructors.
    if(CMAKE_CXX_COMPILER_LOADED)
        add_compile_options("$<$<AND:$<CXX_COMPILER_ID:GNU>,$<COMPILE_LANGUAGE:CXX>>:-fuse-cxa-atexit>")
    endif()

    # Let gcc emit extra code to check for buffer overflows, using a stack canary.
    add_compile_options("$<$<OR:$<C_COMPILER_ID:GNU>,$<CXX_COMPILER_ID:GNU>>:-fstack-protector-strong>")

    # Set full RELRO: make relocations section read-only, and avoid lazy binding.
    # CMake 3.13 added the function add_link_options(), but our 3.8 does not have that,
    # so we use the old-style function link_libraries() instead, but must prevent CMake
    # from automatically exporting it with targets, by restricting to BUILD_INTERFACE.
    link_libraries("$<BUILD_INTERFACE:$<$<OR:$<C_COMPILER_ID:GNU>,$<CXX_COMPILER_ID:GNU>>:-Wl,-z,relro,-z,now>>")

    # Standard settings
    #
    #   Disable GCC extensions (this is consistent with specifying -Wpedantic above)
    #   Define our preferred language variants
    #
    # We do not use the CACHE for these, as we do not want them overridden from the
    # command line.

    set(CMAKE_CXX_EXTENSIONS OFF)
    set(CMAKE_CXX_STANDARD 14)

    set(CMAKE_C_EXTENSIONS OFF)
    set(CMAKE_C_STANDARD 99)

    # Introduce option for building the unit test executable by default.
    #
    # However, running the unit tests using docker or building
    # the documentation make target shall be user-defined
    option(ARA_ENABLE_TESTS "Enable unit testing" ON)
    option(ARA_RUN_TESTS "Enable running unit testing" OFF)
    option(ARA_ENABLE_DOXYGEN "Enables the documentation target" OFF)

    # Testing / Debugging
    cmake_dependent_option(ARA_ENABLE_DEBUG "Enable debug for docker target" OFF
        "ARA_RUN_TESTS" OFF)
    message(STATUS "option ARA_RUN_TESTS=" ${ARA_RUN_TESTS})
    message(STATUS "option ARA_ENABLE_DEBUG=" ${ARA_ENABLE_DEBUG} " (depends on ARA_RUN_TESTS)")

    if(ARA_RUN_TESTS)
        # Enable running tests inside docker container
        # If ARA_ENABLE_DEBUG is ON and CMAKE_BUILD_TYPE is Debug or RelWithDebInfo
        # a gdbserver target will be created
        include(AUTOSAR/docker)
        docker_setup_container()
    endif()
endmacro()


# Everyone needs the default settings

apd_defaults()
