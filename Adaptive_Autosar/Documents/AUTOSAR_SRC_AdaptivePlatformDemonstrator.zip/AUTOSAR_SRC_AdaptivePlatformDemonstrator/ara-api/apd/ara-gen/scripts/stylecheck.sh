#!/usr/bin/env bash

#  --------------------------------------------------------------------------
#  |              _    _ _______     .----.      _____         _____        |
#  |         /\  | |  | |__   __|  .  ____ .    / ____|  /\   |  __ \       |
#  |        /  \ | |  | |  | |    .  / __ \ .  | (___   /  \  | |__) |      |
#  |       / /\ \| |  | |  | |   .  / / / / v   \___ \ / /\ \ |  _  /       |
#  |      / /__\ \ |__| |  | |   . / /_/ /  .   ____) / /__\ \| | \ \       |
#  |     /________\____/   |_|   ^ \____/  .   |_____/________\_|  \_\      |
#  |                              . _ _  .                                  |
#  --------------------------------------------------------------------------
#
#  All Rights Reserved.
#  Any use of this source code is subject to a license agreement with the
#  AUTOSAR development cooperation.
#  More information is available at www.autosar.org.
#
#  Disclaimer
#
#  This work (specification and/or software implementation) and the material
#  contained in it, as released by AUTOSAR, is for the purpose of information
#  only. AUTOSAR and the companies that have contributed to it shall not be
#  liable for any use of the work.
#
#  The material contained in this work is protected by copyright and other
#  types of intellectual property rights. The commercial exploitation of the
#  material contained in this work requires a license to such intellectual
#  property rights.
#
#  This work may be utilized or reproduced without any modification, in any
#  form or by any means, for informational purposes only. For any other
#  purpose, no part of the work may be utilized or reproduced, in any form
#  or by any means, without permission in writing from the publisher.
#
#  The work has been developed for automotive applications only. It has
#  neither been developed, nor tested for non-automotive applications.
#
#  The word AUTOSAR and the AUTOSAR logo are registered trademarks.
#  --------------------------------------------------------------------------

## Setup Bash unofficial strict mode
set -euo pipefail
IFS=$'\n\t'

## Logging framework
readonly SCRIPT_NAME=$(basename "$0")
readonly LOG_FILE="/tmp/${SCRIPT_NAME%.sh}.log"
log_debug()   { echo "$(tput setaf 4)[DEBUG  ]$(tput sgr0)	$*" | tee -a "${LOG_FILE}" >&2 ; }
log_info()    { echo "[INFO   ]	$*" | tee "${LOG_FILE}" >&2 ; }
log_warning() { echo "$(tput setaf 3)[WARNING]$(tput sgr0)	$*" | tee -a "${LOG_FILE}" >&2 ; }
log_error()   { echo "$(tput setaf 1)[ERROR  ]$(tput sgr0)	$*" | tee -a "${LOG_FILE}" >&2 ; }
log_fatal()   { echo "$(tput setaf 1)[FATAL  ]$(tput sgr0)	$*" | tee -a "${LOG_FILE}" >&2 ; exit 1 ; }

usage() { echo "Usage: $(basename "$1") [dir]" ; }

OPTIND=1 # in case getopts has been used previously in the shell
while getopts :h opt; do
	case ${opt} in
	h)
		usage "$0"
		exit 0
		;;
	\?)
		echo "$0: Invalid option '${OPTARG}'"
		usage "$0"
		exit 1
		;;
	esac
done
shift $((OPTIND - 1))

DIR=${1:-"generator"}

while IFS= read -d $'\0' -r file; do
	log_info "Performing PEP8 checks for ${file}"
	pycodestyle "${file}" || log_fatal "PEP8 checks failed"

	log_info "Performing linting on ${file}"
	pylint --disable=I0011,I0012 "${file}" || log_fatal "Lint checks failed"
done < <(find "${DIR}" -name "*.py" -print0)

# Mypy type checking
log_info "Performing type checking (mypy) on ${DIR}"
mypy --ignore-missing-imports "${DIR}" || log_fatal "Type checking failed"
