#!/usr/bin/env bash

#  --------------------------------------------------------------------------
#  |              _    _ _______     .----.      _____         _____        |
#  |         /\  | |  | |__   __|  .  ____ .    / ____|  /\   |  __ \       |
#  |        /  \ | |  | |  | |    .  / __ \ .  | (___   /  \  | |__) |      |
#  |       / /\ \| |  | |  | |   .  / / / / v   \___ \ / /\ \ |  _  /       |
#  |      / /__\ \ |__| |  | |   . / /_/ /  .   ____) / /__\ \| | \ \       |
#  |     /________\____/   |_|   ^ \____/  .   |_____/________\_|  \_\      |
#  |                              . _ _  .                                  |
#  --------------------------------------------------------------------------
#
#  All Rights Reserved.
#  Any use of this source code is subject to a license agreement with the
#  AUTOSAR development cooperation.
#  More information is available at www.autosar.org.
#
#  Disclaimer
#
#  This work (specification and/or software implementation) and the material
#  contained in it, as released by AUTOSAR, is for the purpose of information
#  only. AUTOSAR and the companies that have contributed to it shall not be
#  liable for any use of the work.
#
#  The material contained in this work is protected by copyright and other
#  types of intellectual property rights. The commercial exploitation of the
#  material contained in this work requires a license to such intellectual
#  property rights.
#
#  This work may be utilized or reproduced without any modification, in any
#  form or by any means, for informational purposes only. For any other
#  purpose, no part of the work may be utilized or reproduced, in any form
#  or by any means, without permission in writing from the publisher.
#
#  The work has been developed for automotive applications only. It has
#  neither been developed, nor tested for non-automotive applications.
#
#  The word AUTOSAR and the AUTOSAR logo are registered trademarks.
#  --------------------------------------------------------------------------

## Setup Bash unofficial strict mode
set -euo pipefail
IFS=$'\n\t'

## Logging framework
readonly SCRIPT_NAME=$(basename "$0")
readonly LOG_FILE="/tmp/${SCRIPT_NAME%.sh}.log"
log_debug()   { echo "$(tput setaf 4)[DEBUG  ]$(tput sgr0)	$*" | tee -a "${LOG_FILE}" >&2 ; }
log_info()    { echo "[INFO   ]	$*" | tee "${LOG_FILE}" >&2 ; }
log_warning() { echo "$(tput setaf 3)[WARNING]$(tput sgr0)	$*" | tee -a "${LOG_FILE}" >&2 ; }
log_error()   { echo "$(tput setaf 1)[ERROR  ]$(tput sgr0)	$*" | tee -a "${LOG_FILE}" >&2 ; }
log_fatal()   { echo "$(tput setaf 1)[FATAL  ]$(tput sgr0)	$*" | tee -a "${LOG_FILE}" >&2 ; exit 1 ; }

readonly VIRTUALENV_DIR=${1:-.venv}

if [[ ! -d "${VIRTUALENV_DIR}" ]]; then
	log_info "Creating virtualenv in ${VIRTUALENV_DIR}"
	virtualenv --python=/usr/bin/python3.5 --no-site-packages "${VIRTUALENV_DIR}"
	# $PS1 is not set to a default value which causes -u to emit an error
	# Temporarily disable it when activating the virtual env by running in a subshell
	(
		set +u
		source "${VIRTUALENV_DIR}"/bin/activate
		pip install -r requirements.txt
	)
else
	if [[ -z "$(ls -A "${VIRTUALENV_DIR}")" ]]; then
		log_fatal "Directory ${VIRTUALENV_DIR} already exists"
	else
		log_fatal "Directory ${VIRTUALENV_DIR} already exists and is not empty"
	fi
fi
