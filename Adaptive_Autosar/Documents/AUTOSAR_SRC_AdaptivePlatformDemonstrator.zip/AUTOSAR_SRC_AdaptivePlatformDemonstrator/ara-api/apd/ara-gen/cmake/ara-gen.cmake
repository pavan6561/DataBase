#  --------------------------------------------------------------------------
#  |              _    _ _______     .----.      _____         _____        |
#  |         /\  | |  | |__   __|  .  ____ .    / ____|  /\   |  __ \       |
#  |        /  \ | |  | |  | |    .  / __ \ .  | (___   /  \  | |__) |      |
#  |       / /\ \| |  | |  | |   .  / / / / v   \___ \ / /\ \ |  _  /       |
#  |      / /__\ \ |__| |  | |   . / /_/ /  .   ____) / /__\ \| | \ \       |
#  |     /________\____/   |_|   ^ \____/  .   |_____/________\_|  \_\      |
#  |                              . _ _  .                                  |
#  --------------------------------------------------------------------------
#
#  All Rights Reserved.
#  Any use of this source code is subject to a license agreement with the
#  AUTOSAR development cooperation.
#  More information is available at www.autosar.org.
#
#  Disclaimer
#
#  This work (specification and/or software implementation) and the material
#  contained in it, as released by AUTOSAR, is for the purpose of information
#  only. AUTOSAR and the companies that have contributed to it shall not be
#  liable for any use of the work.
#
#  The material contained in this work is protected by copyright and other
#  types of intellectual property rights. The commercial exploitation of the
#  material contained in this work requires a license to such intellectual
#  property rights.
#
#  This work may be utilized or reproduced without any modification, in any
#  form or by any means, for informational purposes only. For any other
#  purpose, no part of the work may be utilized or reproduced, in any form
#  or by any means, without permission in writing from the publisher.
#
#  The work has been developed for automotive applications only. It has
#  neither been developed, nor tested for non-automotive applications.
#
#  The word AUTOSAR and the AUTOSAR logo are registered trademarks.
#  --------------------------------------------------------------------------

include(CMakeParseArguments)

if(NOT PYTHON_EXECUTABLE)
	find_package(PythonInterp 3.5)
endif()

if(NOT ARAGEN_PATH)
	set(ARAGEN_PATH ${ARA_ARAGEN_SCRIPT})
endif()

function(add_aragen)
	set(options ALL PROLOC FORCE_PKGPATH_FALLBACK)
	set(oneValueArgs DESTINATION SWC SCHEMA TARGET)
	set(multiValueArgs ARXMLS)
	cmake_parse_arguments(add_aragen_ARGS "${options}" "${oneValueArgs}" "${multiValueArgs}" ${ARGN})
	if(add_aragen_ARGS_PROLOC)
		set(add_aragen_PROLOC_ARGUMENT "--proloc-binding")
	endif()
	if(add_aragen_ARGS_FORCE_PKGPATH_FALLBACK)
		set(add_aragen_PKGPATH_ARGUMENT "--force-pkg-path-fallback")
	endif()

	if(EXISTS ${add_aragen_ARGS_SCHEMA})
	# TODO add parametr to new generator
	#	set(add_aragen_VALIDATE_ARGUMENT "--validate ${add_aragen_ARGS_SCHEMA}")
	endif()
	# Arguments, which are common for all invocations of aragen below (for code generation)
	set(add_aragen_COMMON_ARGS
		-o ${add_aragen_ARGS_DESTINATION}
		-a ${add_aragen_ARGS_SWC}
		-g CODE
		${add_aragen_PROLOC_ARGUMENT}
		${add_aragen_PKGPATH_ARGUMENT}
	)

	execute_process(
		COMMAND
		${PYTHON_EXECUTABLE}
		${ARAGEN_PATH}
		--list-files
		${add_aragen_COMMON_ARGS}
		${add_aragen_ARGS_ARXMLS}
		OUTPUT_VARIABLE aragen_outputs
		RESULT_VARIABLE aragen_return
		WORKING_DIRECTORY "${CMAKE_CURRENT_SOURCE_DIR}"
	)
	if(NOT aragen_return EQUAL 0)
		message(FATAL_ERROR "aragen failed!")
	endif()
	# Add input .arxmls to the list of input files to the configuration process.
	# This is needed so that CMake is re-run, if any of this files are changed,
	# because it might affect which output files the generator produces.
	set_property(DIRECTORY APPEND PROPERTY CMAKE_CONFIGURE_DEPENDS ${add_aragen_ARGS_ARXMLS})
	# Export the list of files (sources and headers) to the caller
	set(aragen_hdrs)
	set(aragen_srcs)
	foreach(f IN LISTS aragen_outputs)
		if(f MATCHES ".*\\.h")
			list(APPEND aragen_hdrs ${f})
		elseif(f MATCHES ".*\\.cpp")
			list(APPEND aragen_srcs ${f})
		endif()
	endforeach()
	set(${add_aragen_ARGS_TARGET}_HEADERS ${aragen_hdrs} PARENT_SCOPE)
	set(${add_aragen_ARGS_TARGET}_SOURCES ${aragen_srcs} PARENT_SCOPE)

	# Finally setup custom command/target for invoking the generator
	# (this will happen during build, i.e. upon `make' invocation)
	add_custom_command(
		OUTPUT ${CMAKE_CURRENT_BINARY_DIR}/${add_aragen_ARGS_TARGET}.stamp
		COMMAND
		${PYTHON_EXECUTABLE}
		${ARAGEN_PATH}
		${add_aragen_COMMON_ARGS}
		${add_aragen_VALIDATE_ARGUMENT}
		${add_aragen_ARGS_ARXMLS}
		COMMAND
		${CMAKE_COMMAND} -E touch ${CMAKE_CURRENT_BINARY_DIR}/${add_aragen_ARGS_TARGET}.stamp
		DEPENDS ${add_aragen_ARGS_ARXMLS}
		BYPRODUCTS ${aragen_outputs}
		WORKING_DIRECTORY "${CMAKE_CURRENT_SOURCE_DIR}"
	)

	if(add_aragen_ARGS_ALL)
		set(add_aragen_ALL_VALUE "ALL")
	else()
		set(add_aragen_ALL_VALUE "")
	endif()
	add_custom_target(${add_aragen_ARGS_TARGET} ${add_aragen_ALL_VALUE} DEPENDS ${add_aragen_ARGS_TARGET}.stamp)
endfunction()

if(NOT JSONGEN_PATH)
	set(JSONGEN_PATH ${ARA_ARAGEN_SCRIPT})
endif()

function(add_jsongen)
	set(options LOG_DLT LOG_CONSOLE)
	set(oneValueArgs DESTINATION MACHINE TARGET LOG_FILE LOG_LEVEL ROUTING)
	set(multiValueArgs ARXMLS)
	cmake_parse_arguments(add_jsongen_ARGS "${options}" "${oneValueArgs}" "${multiValueArgs}" ${ARGN})

	set(LOG_DLT "")
	if(add_jsongen_ARGS_LOG_DLT)
		set(LOG_DLT "--log-dlt")
	endif()

	set(LOG_CONSOLE "")
	if(add_jsongen_ARGS_LOG_CONSOLE)
		set(LOG_CONSOLE "--log-console")
	endif()

	# Arguments, which are common for all invocations of aragen below (for config generation)
	set(add_jsongen_COMMON_ARGS
		-o ${add_jsongen_ARGS_DESTINATION}
		-m ${add_jsongen_ARGS_MACHINE}
		-g CONFIG
	)

	execute_process(
		COMMAND
		${PYTHON_EXECUTABLE}
		${JSONGEN_PATH}
		${add_jsongen_COMMON_ARGS}
		--list-files
		${add_jsongen_ARGS_ARXMLS}
		OUTPUT_VARIABLE jsongen_outputs
		WORKING_DIRECTORY "${CMAKE_CURRENT_SOURCE_DIR}"
	)

	set(jsongen_path)
	foreach(f IN LISTS jsongen_outputs)
		if(f MATCHES ".*\\.json")
			list(APPEND jsongen_path ${f})
		endif()
	endforeach()
	set(${add_jsongen_ARGS_TARGET}_OUTPUTS ${jsongen_path} PARENT_SCOPE)

	add_custom_command(
		OUTPUT ${CMAKE_CURRENT_BINARY_DIR}/${add_jsongen_ARGS_TARGET}.stamp
		COMMAND
		${PYTHON_EXECUTABLE}
		${JSONGEN_PATH}
		${add_jsongen_COMMON_ARGS}
#		--routing ${add_jsongen_ARGS_ROUTING}
		--log-level ${add_jsongen_ARGS_LOG_LEVEL}
		${LOG_DLT}
		${LOG_CONSOLE}
		${add_jsongen_ARGS_ARXMLS}
		COMMAND
		${CMAKE_COMMAND} -E touch ${CMAKE_CURRENT_BINARY_DIR}/${add_jsongen_ARGS_TARGET}.stamp
		DEPENDS ${add_jsongen_ARGS_ARXMLS}
		BYPRODUCTS ${jsongen_outputs}
		WORKING_DIRECTORY "${CMAKE_CURRENT_SOURCE_DIR}"
	)

	add_custom_target(${add_jsongen_ARGS_TARGET} DEPENDS ${add_jsongen_ARGS_TARGET}.stamp)
endfunction()

function(add_em_gen)
	set(options ALL)
	set(oneValueArgs DESTINATION TARGET MACHINE)
	set(multiValueArgs ARXMLS)
	cmake_parse_arguments(em_gen_ARGS "${options}" "${oneValueArgs}" "${multiValueArgs}" ${ARGN})

	set(em_gen_COMMON_ARGS
		-o ${em_gen_ARGS_DESTINATION}
		-m ${em_gen_ARGS_MACHINE}
		-g EM_CONFIG
	)

	execute_process(
		COMMAND
		${PYTHON_EXECUTABLE}
		${ARAGEN_PATH}
		--list-files
		${em_gen_COMMON_ARGS}
		${em_gen_ARGS_ARXMLS}
		OUTPUT_VARIABLE aragen_outputs
		RESULT_VARIABLE aragen_return
		WORKING_DIRECTORY "${CMAKE_CURRENT_SOURCE_DIR}"
	)
	if(NOT aragen_return EQUAL 0)
		message(FATAL_ERROR "EM manifests generation failed!")
	endif()
	# Add input .arxmls to the list of input files to the configuration process.
	# This is needed so that CMake is re-run, if any of this files are changed,
	# because it might affect which output files the generator produces.
	set_property(DIRECTORY APPEND PROPERTY CMAKE_CONFIGURE_DEPENDS ${em_gen_ARGS_ARXMLS})
	# Export the list of files to the caller
	set(${em_gen_ARGS_TARGET}_OUTPUTS ${aragen_outputs} PARENT_SCOPE)

	# Finally setup custom command/target for invoking the generator
	# (this will happen during build, i.e. upon `make' invocation)
	add_custom_command(
		OUTPUT ${CMAKE_CURRENT_BINARY_DIR}/${em_gen_ARGS_TARGET}.stamp
		COMMAND
		${PYTHON_EXECUTABLE}
		${ARAGEN_PATH}
		${em_gen_COMMON_ARGS}
		${em_gen_ARGS_ARXMLS}
		COMMAND
		${CMAKE_COMMAND} -E touch ${CMAKE_CURRENT_BINARY_DIR}/${em_gen_ARGS_TARGET}.stamp
		DEPENDS ${em_gen_ARGS_ARXMLS}
		BYPRODUCTS ${aragen_outputs}
		WORKING_DIRECTORY "${CMAKE_CURRENT_SOURCE_DIR}"
	)

	if(em_gen_ARGS_ALL)
		set(em_gen_ALL_VALUE "ALL")
	else()
		set(em_gen_ALL_VALUE "")
	endif()
	add_custom_target(${em_gen_ARGS_TARGET} ${em_gen_ALL_VALUE} DEPENDS ${em_gen_ARGS_TARGET}.stamp)
endfunction()
