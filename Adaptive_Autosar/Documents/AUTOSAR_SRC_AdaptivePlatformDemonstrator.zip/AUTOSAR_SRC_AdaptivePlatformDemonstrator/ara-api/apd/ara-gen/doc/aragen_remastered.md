ARAGen ReMastered
=================

Estimate
--------
Time: ~1.5 months (basic parsing and generation of C++ code)
Number of developers: 1.5

Included in estimate is the time to restructure, unit test, and integrate.

Overview
--------
Essentially, the generator shall be separated in to two distinct halves:

1.  Parser
2.  Generator
    * Code generator (mainly C++)
    * Configuration generator (mainly JSON)

There shall exist some classes that aid in the generation by acting as an
in-memory representation of the model. These classes shall be stored as a
collection such that generation is as simple as looping through the generators
and writing their output to an output stream (file or console, for example).

By splitting in to parse and generate segments, it should be possible to change
the parser without affecting the generator and vice-versa. As long as the API
and the intermediate data format remain unchanged.

Using a Generator base class allows exstensibility for new types, should they
be required at a later stage. Each Generator is aware of the template file to
use, and these template files may be shared.

Jinja 2 shall be used as a templating language as it allows sufficiently
complex ideas to be expressed without becoming incomprehensible by enabling
templates to inherit from other templates, or to write macros for inclusion
in other templates, facilitating a natural structure.

ARAGen is designed to allow registering of additional parsers and generators
in order to easily support new use cases. How to register a new parser/generator
is described in the section "Register a new Parser/Generator".

1 ARXML parser design
---------------------
`lxml.objectify` is recommended as ARXML parser/deserializer because of
performance and flexibility/convenience. `lxml.etree` can be used to provide
ARXML validation against an XML Schema.

### Splitable support ###

AUTOSAR annotates certain features of model elements as being `atpSplitable`, meaning that
fragments of those features can be distributed in multiple ARXML files.

The fragments of the same Splitable feature of an element are identified by specific rules.
Some example Splitable elements can be found in the Annex E of the [Specification
of Manifest](https://svn.autosar.org/repos/work/26_Standards/30_AP_R1/01_Sources/TPS_ManifestSpecification_713/AUTOSAR_TPS_ManifestSpecification.pdf)
together with a further pointer to the [Generic Structure Template](https://svn.autosar.org/repos/work/26_Standards/10_CP_R4/01_Sources/TPS_GenericStructureTemplate_202/AUTOSAR_TPS_GenericStructureTemplate.pdf), section 2.3.2, "Splitable Elements (atpSplitable) distributed on Multiple Physical
Files)" which explains how they should be processed.

This should be considered in combination with the [resolving references](#resolving-references) point.

### Input model validation ###

The merged input model from all the input ARXML files, taking into account [Splitable](#splitable-support) elements,
should be computed and validated prior to actual generation.

An implementation of validation against the Adaptive AUTOSAR XML Schema is part of the [old generator](https://code.autosar.org/tf-apd/ara-api/blob/226e941b7a4c2ed8b0a5e87a20358e9f02b4642b/tools/generator/ArxmlModel/validation.py). Please see this [explanation](https://code.autosar.org/tf-apd/ara-api/blob/226e941b7a4c2ed8b0a5e87a20358e9f02b4642b/tools/generator/validate_models_readme.txt) for details.

Further domain-specific validation rules can be developed, ideally selecting an existing rule-based systems development framework. 

### Resolving references ###

In projects with many references, for which resolution can be requested multiple
times, it makes sense to use a global registry to speed-up target resolution. For example, 
using a hash/dictionary (either with a language-supported implementation or with custom 
hashing functions) can greatly speed-up this operation.

### Convenient accessors for model elements ###

Due to the fact that many AUTOSAR elements contain dashes inside their names,
`lxml.objectify` cannot be used to directly access sub-elements, since dashes
lead to invalid Python syntax. E.g. to access the `shortName` of an
`Identifiable` element `e`, represented as a `SHORT-NAME` sub-element, cannot
be done as `e.SHORT-NAME`, but only as `e.__getattribute__('SHORT-NAME')`.

To work around this issue, we can use custom classes for the deserialization
of XML elements, that perform this conversion from dashes to underscores
internally, making it possible to use `e.SHORT_NAME`.

These classes are exposed to the user as subclasses of the default element
class:
```Python
class AUTOSARMapping(objectify.ObjectifiedElement):

    def __getattr__(self, item):
        return super().__getattribute__(item.replace('_', '-'))
```

Taking this approach, parser creation can be done like this:
```Python
with open(schema_file, "r") as f:
    schema = etree.XMLSchema(file=f)
    lookup = objectify.ObjectifyElementClassLookup(
        tree_class=AUTOSARMapping, empty_data_class=str)
    xml_parser = etree.XMLParser(remove_blank_text=True, schema=schema)
    xml_parser.setElementClassLookup(lookup)
```
Besides providing an `AUTOSARMapping` class instead of the
`objectify.ObjectifiedElement` class, we also ask for a Python string instead
of the `StringElement` class.

For more context, please see this [test program](https://code.autosar.org/tf-apd/generator/blob/17701d3c3c127dddfdbfff78b9125dbb40bdbb19/experimental/test_jinja2_lxml_objectify.py#L67).

2 Generator design
------------------

### Code generator ###

The generator relies on an *Intermediate Model*, that contains all relevant information belonging to various objects representing instances of Adaptive AUTOSAR concepts, such as Service, Event, Method, Field, etc. The role of the Intermediate Model is to make the generation independent of the input format (typically ARXML), and to ensure that all information that is relevant for generation is easily available, with references and all types of mappings already being resolved to then allow the creation of the Intermediate Model objects.

Based on the Intermediate Model, *Views* are created that compute additional information (presentation logic) that is needed within the various *Generators*, each of which leverages a set of Views and an underlying template. The underlying templates are free of any logic, and should be easily mappable to a number of similarly expressive template languages.

The interaction between an Intermediate Model object, its (potentially multiple) Views and related Generator objects is illustrated by the following diagram:
![Intermediate Model, Views and Generators](images/model_views_generators.png)

Below is a more detailed diagram for the `ara::com` part of the Intermediate Model, together with the related Views and a sample Generator that leverages the Views to produce a `skeleton_<interface>.h` file.
![ara::com with Views and Generators (draft)](images/ara_com_views_generators.png)

A richer Intermediate Model is illustrated below:
![Intermediate model (draft)](images/intermediate_model.png)

A still richer, but non-exhaustive, class diagram with Model, Views and Generators is available below:
![Generator class diagram (draft)](images/generator_class_diagram.png)

As an example of how Jinja might be used we can consider BaseType, ImplType,
and SeriablizableObject:

BaseType:
```
#ifndef {{include_guard}}
#define {{include_guard}}

#include <cstdint>
#include <string>
#include <vector>
#include <array>
#include <map>

namespace ara {
namespace stdtypes {

typedef {{cpp_type}} {{ara_basetype}};

}
}

#endif // namespace {{include_guard}}
```

ImplType
```
#ifndef {{include_guard}}
#define {{include_guard}}

#include "ara/stdtypes/base_type_{{base_type}}"

namespace ara {
namespace stdtypes {

typedef ara::stdtypes::{{ara_basetype}} {{ara_impltype}};

}
}

#endif // namespace {{include_guard}}
```

SerializableObject
```
{% macro serializable(struct) -%}
struct {{struct.name}} {
  {%- for field in struct.fields %}
  {{field.type}} {{field.name}};
  {%- endfor %}

  using isEnumerableTag = {{struct.tag}};
  template&lt;typename F>
  void enumerate(F& fun) {
    {%- for field in struct.fields %}
    fun({{field.name}});
    {%- endfor %}
  }
};
{%- endmacro -%}
```

which may be used by importing it when generating Events, for example:
```
{% from 'SerializableObject' import serializable }
#ifndef {{include_guard}}
#define {{include_guard}}

{% for include in includes -%}
#include "{{include}}"
{% endfor -%}

{% for namespace in namespaces %}
namespace {{namespace}} {
{%- endfor %}

{{ serializable(struct=struct) }}

{% for namespace in namespaces %}
} // namespace {{namespace}}
{%- endfor %}

#endif // namespace {{include_guard}}
```

### Configuration generator ###

The usual target-format of the configuration files
is JSON (e.g. the `vsomeip` configuration, ARA DIAG
configuration, ARA PER configuration).
The use-case of generating JSON is therefore important
and some guidelines are given below.

* Consider creating and using a [JSON Schema](http://json-schema.org/) to validate the output upon generation. The `jsonschema` module can be used for performing validation. Sample code available in [experimental/test_json_schema.py](../experimental/test_json_schema.py).

### Pretty-printing of output ###

Both generated code and configuration should be pretty-printed (e.g. for C++, using `clang-format` with the agreed [.clang-format](https://code.autosar.org/tf-apd/ara-api/blob/master/.clang-format) and for JSON using `json.dumps(content, indent=4, sort_keys=True)` if possible). Please see also the [wiki](https://bugzilla.autosar.org/wiki/doku.php?id=ap_dev_guide:guidelines:formatting&s[]=clang&s[]=format) for more details regarding formatting.

### Register a new Parser/Generator ###

All parsers and generators are registered in ARAGen as a (name, filepath) combination which dynamically loads
the module in the filepath into ARAGen. A registered parser module must contain a `class Parser` which then has to
have a method `parse(self, files)` where `files` is a python list of the input files. The output of the `parse(files)`
command will then be saved in a dictionary as the value of the name which the Parser was registered with. This
can then serve as input to a registered generator. A registered generator is, much like a parser, a `class Generator`
which have a function `generate(self, model)` where model is the value stored in the name the generator was
registered with.

A parser or generator is registered via the config option in JSON format like the following:
```JSON
{
    "parsers": [
        {
            "name": "my_model",
            "import": "parser.parser",
            "path": "/home/axgo/tmp/my_parser/parser.py"
        },
        {
            "name": "my_model2",
            "import": "parser.parser",
            "path": "/home/axgo/tmp/my_parser2/parser2.py"
        }
    ],
    "generators": [
        {
            "name": "my_model",
            "import": "generator.parser",
            "path": "/home/axgo/tmp/my_generator/generator.py"
        }
    ]
}
```

In the example above the module parser.py would be loaded, then that module would be checked for a `class Parser` which
would be instantiated and the function `parse(files)` would be called. The result of the `parse(files)` function would then
be passed to the generator.py as they have the same name. In simplified code it looks something like:

```python
import sys
import importlib.util

#Dummy config, this is read from a JSON file in the real ARAGen
config = dict()
parsers = dict()
parsers["my_model"] = "/home/axgo/tmp/my_parser/parser.py"
parsers["my_model2"] = "/home/axgo/tmp/my_parser2/parser2.py"
generators = dict()
generators["my_model"] = "/home/axgo/tmp/my_generator/generator.py"
config["parsers"] = parsers
config["generators"] = generators

models = dict()

for parser_entry in config["parsers"]:
    sys.path.insert(0, parser_entry["path"])

    parser_module = importlib.import_module(parser_entry["import"])
    parser = parser_module.Parser()
    models[parser_entry["name"]] = parser.parse(args.files)

    sys.path = sys.path[1:]

for generator_entry in config["generators"]:
    sys.path.insert(0, generator_entry["path"])

    generator_module = importlib.import_module(generator_entry["import"])
    generator = generator_module.Generator()
    generator.generate(models[generator_entry["name"]])

    sys.path = sys.path[1:]
```

The standard arxml parser is registered with the keyword "arxml_tree" and is passed into an additional step where an
intermediate model is created. The intermediate model is registered with the name "intermediate_model" and the standard
generator uses the "intermediate_model" as input. This means that to replace the standard parser the "arxml_tree" name
should be used and to replace the standard generator the "intermediate_model" name shall be used.
