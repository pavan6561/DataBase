ARAGen ReMastered
=================

This is the proposed command-line interface; not all of these options have been implemented yet.

Usage
--------
```
aragen [FLAGS] [-a ARGUMENT] -o OUTPUT FILES
-------------------FLAGS--------------------------
Any number of the following flags, the one letter flags can be combined
    ex. -vn
    ex. --verbose --dryrun

-d  --debug                 Runs the generator in debug mode 

-h  --help                  Prints this help list and exit

    --list-files            Lists the files that would be modified by the generator with the 
                            current arguments/configurations

    --list-applications     Lists the current ADAPTIVE-APPLICATION-SW-COMPONENTS that can be
                            generated

-n  --dry-run               Runs the generator in dry-run mode, IE runs all the way through
                            without actually generating anything

-v  --verbose               Verbose output

-q  --quiet                 No output

    --Version               List versions of the generator components and exit.
-------------------ARGUMENT-----------------------
Any number of the following arguments followed by a space and then the argument itself
    ex. -b SOMEIP,ROS
    ex, -c /path/to/config -m machine1,machine2

-a  --applications          Generate only for the adaptive applications mentioned in the comma separated
                            list.

-b  --bindings              The bindings to generate output for is a comma separated list with one or
                            several of SOMEIP,PROLOC,ROS,USERDEF,ALL,NONE. If no argument is given ALL is
                            the default.
 
-c  --config                Path to a config JSON file which denotes further arguments or custom
                            arguments to the generator. The file should be key-value JSON format
                            like:
                                {
                                    “key”: “value”,
                                    “key2”: “value2”
                                }
                            And the values of this will be stored in a map called config_args and be
                            accessible from inside the module.

                            The config JSON can also be defined inlined like this:
                                aragen.py -c {"key":"value", "key2": "value2"}

    --dump-config           Dump the configuration of key-value pairs used by the generator and 
                            exit. Can be used to create an extendable/overwriteable config file for -c.

-g  --generate              What to generate. Options are ALL,CONFIG,CODE; default is ALL

-l  --log                   Specify a log output file to print all output/log messages/errors to 
                            in addition to the output on the terminal

    --list-machines         List the names of all machines possible for generation

-m  --machine               Generate output only for applications on machine which name matches the
                            comma separated list.

-------------------REQUIRED-----------------------
-o  --output                Output directory for the generator

FILES                       A list of files that will be input for the generator, can be either globs,
                            individual files or a directory. In the case that there is a path to a
                            directory all .arxml files under the directory will be used as input
```

Example Use cases
-----------------

Here follows a set off possible use cases and the arguments to achieve them.

1.
```
    aragen          \
        -o output   \
        /home/repo/ara-project/sample-applications/cm_provider_subscriber_scenario/
```

This command would generate the radar/fusion example in a folder /output under the current directory.
    It would generate PROLOC,SOMEIP,ROS and User defined bindings if they are all present in the system.
 
2.
```
    aragen          \
        -b SOMEIP   \
        -o output   \
        /home/repo/ara-project/sample-applications/cm_provider_subscriber_scenario/
```

This command does the same as 1. with the difference that only SOMEIP bindings would be generated.
 
3.
```
    aragen                      \
        -o /home/repo/shells/   \
        -b NONE                 \
        /home/repo/ara-project/sample-applications/cm_provider_subscriber_scenario/
```

This command would generate only the generic code, IE no bindings for the radar/fusion example. The output would be placed in the /home/repo/shells/ directory. The generation of only generic parts allows the handover of "contracts" 3rd party developers, even when the full model is not ready.

4.
```
    aragen                      \
        -o /home/repo/shells/   \
        -c /home/repo/ara-project/cm_provider_subscriber_scenario/ps_scenario_generator_config.json     \
        /home/repo/ara-project/sample-applications/cm_provider_subscriber_scenario/
```

This command would generate based on a configuration defined in the JSON file given by -c. This is a good way to create a "standard" generation configuration for a project. The config file can be checked in with the code guaranteeing a consistent generation.
