# ARA Generator

This is the generator component for AUTOSAR Adaptive Platform.

## TOC
1. Folder structure
2. Implemented features
3. Known limitations

## 1. Folder structure

The folder structure is the following:

```
ara-gen
├── cmake
├── doc
│   └── images
├── generator
│   ├── cli
│   │   └── test
│   ├── generator
│   │   └── lib_binding
│   ├── intermediate_model
│   │   ├── communication_management
│   │   │   └── ara_com_deployment
│   │   │       ├── someip
│   │   │       └── user_defined
│   │   ├── execution_management
│   │   ├── test
│   │   │   └── data
│   │   ├── types
│   │   └── utils
│   ├── parser
│   │   ├── arxml_wrappers
│   │   │   └── execution_management
│   │   ├── schema
│   │   ├── test
│   │   │   └── data
│   │   └── v47
│   ├── templates
│   │   ├── opendds_binding
│   │   ├── proloc_binding
│   │   ├── utils
│   │   └── vsomeip_binding
│   ├── test
│   └── views
│       ├── someip
│       └── user_defined
└── scripts
```

*  `cmake` contains required cmake files for including the generator in demonstrator builds.
*  `doc` contains further documentation of the generator.
*  `generator` contains the generator sources.
*  `generator/test` contains test input files and the corresponding expected output.
*  `scripts` contains additional scripts.

## 2. Implemented features

The generator currently supports the generation of the following:
*  CommunicationManagement (data types, interfaces and protocol configurations)
*  ExecutionManagement (execution manifests)

The generator supports schema versions 45 (R18-03) and 47 (R19-03) specified through schemaLocation.

## 3. Known limitations

*  ApplicationRecordDataTypes with optional elements
*  Method arguments of type "InOut"
*  Field setters use wrong return type (but are compatible with CommunicationManagement)
*  CPP-TEMPLATE-ARGUMENTs with equal TYPE-REFs require unique S-attributes as a workaorund to not overwrite each other
   (see ./generator/test/input_data/map_sample/metainfo.arxml)
