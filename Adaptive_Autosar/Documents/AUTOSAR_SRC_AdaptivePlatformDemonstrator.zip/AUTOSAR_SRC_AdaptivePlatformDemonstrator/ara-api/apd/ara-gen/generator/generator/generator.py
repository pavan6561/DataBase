#  --------------------------------------------------------------------------
#  |              _    _ _______     .----.      _____         _____        |
#  |         /\  | |  | |__   __|  .  ____ .    / ____|  /\   |  __ \       |
#  |        /  \ | |  | |  | |    .  / __ \ .  | (___   /  \  | |__) |      |
#  |       / /\ \| |  | |  | |   .  / / / / v   \___ \ / /\ \ |  _  /       |
#  |      / /__\ \ |__| |  | |   . / /_/ /  .   ____) / /__\ \| | \ \       |
#  |     /________\____/   |_|   ^ \____/  .   |_____/________\_|  \_\      |
#  |                              . _ _  .                                  |
#  --------------------------------------------------------------------------
#
#  All Rights Reserved.
#  Any use of this source code is subject to a license agreement with the
#  AUTOSAR development cooperation.
#  More information is available at www.autosar.org.
#
#  Disclaimer
#
#  This work (specification and/or software implementation) and the material
#  contained in it, as released by AUTOSAR, is for the purpose of information
#  only. AUTOSAR and the companies that have contributed to it shall not be
#  liable for any use of the work.
#
#  The material contained in this work is protected by copyright and other
#  types of intellectual property rights. The commercial exploitation of the
#  material contained in this work requires a license to such intellectual
#  property rights.
#
#  This work may be utilized or reproduced without any modification, in any
#  form or by any means, for informational purposes only. For any other
#  purpose, no part of the work may be utilized or reproduced, in any form
#  or by any means, without permission in writing from the publisher.
#
#  The work has been developed for automotive applications only. It has
#  neither been developed, nor tested for non-automotive applications.
#
#  The word AUTOSAR and the AUTOSAR logo are registered trademarks.
#  --------------------------------------------------------------------------

"""
Generator
"""
import importlib
import logging
import pathlib
import os
import sys

import inspect

import jinja2

from generator.generator.generator_settings import GeneratorSettings
from generator.generator.datatype_container import DataTypeContainer
from generator.generator.proloc_binding import ProlocBinding
from generator.views.service_view import ServiceView
from generator.views.someip.someip_service_view import SomeIpServiceView
from generator.views.user_defined.user_defined_service_view import UserDefinedServiceView
from generator.views.component_view import ComponentView
from generator.views.model_to_view import ViewManipulations

from generator.parser.exception_handling import handle_method_exceptions

class Generator(object):
    """
    Generator for intermediate model.
    """

    _LIB_BINDING_PACKAGE = 'generator.generator.lib_binding'
    _LIB_BINDING = {
        'someip' : {
            'vsomeip' : {
                'module' : _LIB_BINDING_PACKAGE + '.vsomeip_binding',
                'class' : 'VsomeipBinding',
            }
        },
        'user_defined' : {
            'vsomeip' : {
                'module' : _LIB_BINDING_PACKAGE + '.vsomeip_binding',
                'class' : 'VsomeipBinding',
            }
        },
        'dds' : {
            'opendds' : {
                'module' : _LIB_BINDING_PACKAGE + '.opendds_binding',
                'class' : 'OpenDdsBinding',
            }
        }
    }

    def __init__(self, args):

        self._settings = GeneratorSettings(args)
        self._log = logging.getLogger(__name__)

        self._skeleton_interface_header = None
        self._first_file = True
        self._printed_files = []
        self._base_types = set()
        self._impl_types = set()
        self._proloc_binding = ProlocBinding(self._load_template, self.write_output, self._settings.output_dir)

        self._someip_bindings = list()
        for name in self._settings.someip_libs:
            module = importlib.import_module(Generator._LIB_BINDING['someip'][name]['module'])
            Binding = getattr(module, Generator._LIB_BINDING['someip'][name]['class'])
            binding = Binding(self._load_template, self.write_output, self._settings.output_dir)
            self._someip_bindings.append(binding)

        self._userdef_bindings = list()
        for name in self._settings.user_defined_libs:
            module = importlib.import_module(Generator._LIB_BINDING['user_defined'][name]['module'])
            Binding = getattr(module, Generator._LIB_BINDING['user_defined'][name]['class'])
            binding = Binding(self._load_template, self.write_output, self._settings.output_dir)
            self._userdef_bindings.append(binding)

        self._dds_bindings = []
        for name in self._settings.dds_libs:
            module = importlib.import_module(Generator._LIB_BINDING['dds'][name]['module'])
            Binding = getattr(module, Generator._LIB_BINDING['dds'][name]['class'])
            binding = Binding(self._load_template, self.write_output, self._settings.output_dir)
            self._dds_bindings.append(binding)

    @staticmethod
    def _is_generate_apps(model):
        return True if "components" in model and model["components"] else False

    @staticmethod
    def _is_generate_machines(model):
        return True if "machines" in model and model["machines"] else False

    def _generate_interface(self, component):
        self.generate_type_headers(component.services_list)
        for service in component.services_list:
            self.generate_si_definition(service)
            if component.service_is_required(service):
                self.generate_proxy_h_cpp(service)
            if component.service_is_provided(service):
                self.generate_skeleton_h_cpp(service)

    def _generate_network_binding(self, component):
        for service in component.services_list:
            if type(service) is SomeIpServiceView:
                for binding in self._someip_bindings:
                    binding.generate_service_desc(service)
                    if (component.service_is_required(service)):
                        binding.generate_proxy(service)
                    if (component.service_is_provided(service)):
                        binding.generate_si_adapter(service)
            elif type(service) is UserDefinedServiceView:
                for binding in self._userdef_bindings:
                    binding.generate_service_desc(service)
                    if component.service_is_required(service):
                        binding.generate_proxy(service)
                    if component.service_is_provided(service):
                        binding.generate_si_adapter(service)

    def _generate_network_binding_sm(self, component):
        someip_services = list()
        userdef_services = list()
        for service in component.services_list:
            if type(service) is SomeIpServiceView:
                someip_services.append(service)
            elif type(service) is UserDefinedServiceView:
                userdef_services.append(service)

        if someip_services:
            for binding in self._someip_bindings:
                binding.generate_sm_definition(component, someip_services)
        if userdef_services:
            for binding in self._userdef_bindings:
                binding.generate_sm_definition(component, userdef_services)

    def _generate_network_binding_config(self, machine, settings):
        for binding in self._someip_bindings:
            binding.generate_machine_config(machine, settings)
        for binding in self._userdef_bindings:
            binding.generate_machine_config(machine, settings)

    def _generate_library_interfaces(self, component):
        # no need for library-specific interfaces for someip and userdef yet
        for binding in self._dds_bindings:
            binding.generate_idls(component.services_list)

    def _generate_proloc_binding(self, component):
        for service in component.services_list:
            self._proloc_binding.generate_proloc_si_adapter(service)
            self._proloc_binding.generate_proloc_proxy(service)
            self._proloc_binding.generate_proloc_service_desc(service)

    def _generate_apps(self, components, error_domains):
        error_sources = []
        if "ALL" in self._settings.generate or "CODE" in self._settings.generate:
            for component in components:
                self._log.info("Generating Code for application \"%s\"", component.name)
                self._generate_interface(component)
                self._generate_library_interfaces(component)
                self._generate_network_binding(component)
                self._generate_network_binding_sm(component)

                if self._settings.proloc_binding_needed:
                    self._generate_proloc_binding(component)
                    self._proloc_binding.generate_proloc_sm_definition(component)

                for service in component.services_list:
                    if service not in error_sources:
                        error_sources.append(service)

            # we collect error_sources in above loop and apply them below
            for component in components:
                self.generate_sm_definition(component, sorted(error_sources), error_domains)


    def _generate_em_manifests(self, process):
        output_filename = "{}_MANIFEST.json".format(process.name)
        em_template = self._load_template("execution_manager_manifest.j2", trim_blocks=True)
        self.write_output(em_template, os.path.join(self._settings.output_dir, 'processes'), output_filename, em_info=process.em_info)

    def _generate_machine_manifest(self, machine):
        output_filename = "{}_machine_manifest.json".format(machine.name)
        em_template = self._load_template("machine_manifest.j2", trim_blocks=True)
        self.write_output(em_template, self._settings.output_dir, output_filename, em_info=machine.em_info)

    def _generate_machines(self, machines, error_domains):
        error_sources = []
        for machine in machines:
            if "ALL" in self._settings.generate or "CONFIG" in self._settings.generate:
                self._log.info("Generating Configuration for machine \"%s\"", machine.name)
                self._generate_network_binding_config(machine, self._settings.logging_settings)

            if "ALL" in self._settings.generate or "CODE" in self._settings.generate:
                self._log.info("Generating Code for machine \"%s\"", machine.name)
                self._generate_interface(machine)
                self._generate_library_interfaces(machine)
                self._generate_network_binding(machine)
                if self._settings.proloc_binding_needed:
                    self._generate_proloc_binding(machine)

                for service in machine.services_list:
                    if service not in error_sources:
                        error_sources.append(service)

        for machine in machines:
            if "ALL" in self._settings.generate or "CODE" in self._settings.generate:
                for component in machine.get_components():
                    self.generate_sm_definition(component, error_sources, error_domains)
                    self._generate_network_binding_sm(component)
                    if self._settings.proloc_binding_needed:
                        self._proloc_binding.generate_proloc_sm_definition(component)

        if "ALL" in self._settings.generate or "EM_CONFIG" in self._settings.generate:
            for machine in machines:
                self._generate_machine_manifest(machine)
                for process in machine.process_views:
                    self._generate_em_manifests(process)


    @property
    def includes_root_dir(self):
        return os.path.join(self._settings.output_dir, 'includes')

    def includes_dir_for(self, namespaces_list):
        lowered_ns_list = [ x.lower() for x in namespaces_list]
        return os.path.join(self.includes_root_dir, *lowered_ns_list)

    def generate(self, model):
        """
        Generates proxy/skeleton files from the intermediate model,
        the generator expects the model to be a list of MachineViews.
        """
        self._log_invocation_details()
        error_domains = sorted(model["errors"])

        # TODO: The intermediate Model is assuming the EM is the start point for the generation as
        # TODO: Machine => Process => Executable => Component. There are cases when the EM is not needed and the user
        # TODO: is interested in generating the Component's (Application) Service Interfaces (i.e. Testing,
        # TODO: having manual Configuration, etc...). Thus, a new mode is needed where the start point is the
        # TODO: Application only. This mode is used when the user specifies the cmd line arg --applications.
        # TODO: This part is not optimum and the code is duplicated twice in the Applications generation
        # TODO: and the Machines generation. For now, it's safer to have them as two independent generation modes
        # TODO: and the flags --applications and --machines could not be used in conjunction but this part
        # TODO: might be optimized later.
        if self._is_generate_apps(model):
            # Generate for the apps specified in the model.
            components = model["components"]
            self._generate_apps(components, error_domains)
        elif self._is_generate_machines(model):
            # Generate for the machines specified in the model.
            machines = model["machines"]
            self._generate_machines(machines, error_domains)
        else:
            self._log.error("No machines were found in input model or no applications were selected for generation!")
            sys.exit("No machines were found in input model or no applications were selected for generation!")

        self._generate_error_domain_headers(error_domains)

    def _generate_error_domain_headers(self, error_domains):
        if "ALL" in self._settings.generate or "CODE" in self._settings.generate:
            error_domain_template = self._load_template("error_domain_xxx_h.j2")
            for error_domain in error_domains:
                output_filename = "error_domain_{0}.h".format(error_domain.standard_name)
                output_dir = self.includes_root_dir
                self.write_output(error_domain_template, output_dir, output_filename, error_domain=error_domain)

    def write_output(self, template, output_dir, filename, **kwargs):
        """
        Writes the content of a template render to a file unless
        the command line options to only list files is set. Then it
        registers what file would have been written.
        """

        def include_guard(relative_file_path):
            result = relative_file_path.replace(os.sep, "_")
            result = result.replace(".", "_")
            result = result.replace(":", "_")
            result = result.replace("-", "_")
            return result

        relative_file_path = os.path.join(output_dir, filename)
        output_dir_absolute = os.path.abspath(output_dir)
        full_path = pathlib.Path(os.path.abspath(relative_file_path))
        if self._settings.list_files:
            # No generation, just print filename (if requested)
            if str(full_path) not in self._printed_files:
                self._printed_files.append(str(full_path))
                if self._first_file:
                    self._first_file = False
                    sys.stdout.write(str(full_path))
                else:
                    sys.stdout.write(';' + str(full_path))
        elif not full_path.is_file():
            if self._should_generate():
                # Actual generation enabled
                self._log.info("Generating %s", str(full_path))
                pathlib.Path(output_dir_absolute).mkdir(parents=True, exist_ok=True)
                include_guard_str = include_guard(relative_file_path)
                output = template.render(header_base=include_guard_str, **kwargs)
                with full_path.open('w') as file:
                    file.write(output)
        else:
            self._log.info("Not re-generating, because it already exists: %s", str(full_path))


    @handle_method_exceptions(error_string_template="type headers generation ERROR: {exception_text}")
    def generate_type_headers(self, services):
        """Generate header files for the whole types tree"""
        struct_impltype_template = self._load_template("struct_impl_type_h.j2")
        enum_impltype_template = self._load_template("enum_impl_type_h.j2")
        map_impltype_template = self._load_template("map_impl_type_h.j2")
        vector_impltype_template = self._load_template("vector_impl_type_h.j2")
        array_impltype_template = self._load_template("array_impl_type_h.j2")
        aliased_impltype_template = self._load_template("aliased_impl_type_h.j2")
        aliased_basetype_template = self._load_template("aliased_base_type_h.j2")
        string_impltype_template = self._load_template("string_impl_type_h.j2")
        basetype_template = self._load_template("base_type_h.j2")

        type_views = set()
        for service in services:
            data_types = DataTypeContainer(service)
            t = set(data_types.types)
            type_views = type_views.union(t)

        for tv in list(type_views):
            kind = ViewManipulations.get_view_kind(tv)
            typename = tv.type_name.lower()
            output_filename = "impl_type_{0}.h".format(typename)
            output_dir = self.includes_dir_for(tv.namespace)
            if kind == 'structure':
                template = struct_impltype_template
            elif kind == 'enum':
                template = enum_impltype_template
            elif kind == 'map':
                template = map_impltype_template
            elif kind == 'vector':
                template = vector_impltype_template
            elif kind == 'array':
                template = array_impltype_template
            elif kind == 'aliased_impltype':
                template = aliased_impltype_template
            elif kind == 'aliased_basetype':
                template = aliased_basetype_template
            elif kind == 'string':
                template = string_impltype_template
            elif kind == 'basetype':
                template = basetype_template
                output_filename = "base_type_{0}.h".format(typename)
            else:
                assert False, "unknown view type {0}({1})".format(kind, tv)

            self.write_output(template, output_dir, output_filename, type_view=tv)

    def generate_si_definition(self, service_interface: ServiceView):
        """
        Generate the <name>.cpp and <name>.h files for the service interface
        """
        si_def_template_h = self._load_template(
            "service_interface_definition_h.j2", True)
        '''
        si_def_template_cpp = self._load_template(
            "service_interface_definition_cpp.j2", True)
        '''

        file_output_dir = self.includes_dir_for(service_interface.namespaces)

        self.write_output(si_def_template_h, file_output_dir,
                          service_interface.standard_name + "_common.h",
                          service=service_interface)
        '''
        self.write_output(si_def_template_cpp, file_output_dir,
                          service_interface.standard_name + "_common.cpp",
                          service=service_interface)
        '''

    def generate_proxy_h_cpp(self, service: ServiceView):
        """Generate the proxy h file required by application"""
        proxy_template = self._load_template("proxy_service_h.j2", True)

        file_output_dir = self.includes_dir_for(service.namespaces)

        self._log.debug("Writing content to file %s",
                        service.standard_name + "_proxy.h")
        self.write_output(proxy_template, file_output_dir,
                          service.standard_name + "_proxy.h",
                          service=service)


    def generate_skeleton_h_cpp(self, service: ServiceView, machine=None):
        """Generate the skeleton h file required by application"""
        skeleton_template = self._load_template("skeleton_service_h.j2", True)

        file_output_dir = self.includes_dir_for(service.namespaces)

        self._log.debug("Writing content of %s_skeleton.h to file",
                        service.standard_name)
        self.write_output(skeleton_template, file_output_dir,
                          service.standard_name + "_skeleton.h",
                          machine=machine,
                          service=service)

    def generate_sm_definition(self, component: ComponentView, error_sources, error_domains):
        """
        Generate the ara_com_main-<name>.cpp for the service mapping
        """
        cm_def_template_cpp = self._load_template(
            "ara_com_main_definition_cpp.j2")

        file_output_dir = os.path.join(self._settings.output_dir)

        self.write_output(cm_def_template_cpp, file_output_dir,
                          "ara_com_main-" + component.name + ".cpp",
                          component=component,
                          error_sources=error_sources,
                          error_domains=error_domains)

    @staticmethod
    def get_name():
        """Get the name of the generator"""
        return "ARAGen Standard Generator"

    def _should_generate(self):
        return not self._settings.dry_run and not self._settings.list_files

    @staticmethod
    def _load_template(name, trim_blocks=False):
        generator_path = os.path.dirname(inspect.getfile(Generator))
        template_folder = os.path.join(generator_path, "../templates")

        template_env = jinja2.Environment(
            loader=jinja2.FileSystemLoader(template_folder),
            trim_blocks=trim_blocks)

        return template_env.get_template(name)

    def _log_invocation_details(self):
        config_message = Generator.get_name() + " started with:\n\t"
        config_message += "\n\t".join(self._settings.configuration_dump)
        config_message = config_message.rstrip()

        self._log.debug(config_message)
