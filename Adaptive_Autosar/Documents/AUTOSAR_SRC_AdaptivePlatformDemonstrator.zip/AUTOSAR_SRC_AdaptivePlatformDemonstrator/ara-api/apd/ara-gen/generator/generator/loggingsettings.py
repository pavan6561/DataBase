#  --------------------------------------------------------------------------
#  |              _    _ _______     .----.      _____         _____        |
#  |         /\  | |  | |__   __|  .  ____ .    / ____|  /\   |  __ \       |
#  |        /  \ | |  | |  | |    .  / __ \ .  | (___   /  \  | |__) |      |
#  |       / /\ \| |  | |  | |   .  / / / / v   \___ \ / /\ \ |  _  /       |
#  |      / /__\ \ |__| |  | |   . / /_/ /  .   ____) / /__\ \| | \ \       |
#  |     /________\____/   |_|   ^ \____/  .   |_____/________\_|  \_\      |
#  |                              . _ _  .                                  |
#  --------------------------------------------------------------------------
#
#  All Rights Reserved.
#  Any use of this source code is subject to a license agreement with the
#  AUTOSAR development cooperation.
#  More information is available at www.autosar.org.
#
#  Disclaimer
#
#  This work (specification and/or software implementation) and the material
#  contained in it, as released by AUTOSAR, is for the purpose of information
#  only. AUTOSAR and the companies that have contributed to it shall not be
#  liable for any use of the work.
#
#  The material contained in this work is protected by copyright and other
#  types of intellectual property rights. The commercial exploitation of the
#  material contained in this work requires a license to such intellectual
#  property rights.
#
#  This work may be utilized or reproduced without any modification, in any
#  form or by any means, for informational purposes only. For any other
#  purpose, no part of the work may be utilized or reproduced, in any form
#  or by any means, without permission in writing from the publisher.
#
#  The work has been developed for automotive applications only. It has
#  neither been developed, nor tested for non-automotive applications.
#
#  The word AUTOSAR and the AUTOSAR logo are registered trademarks.
#  --------------------------------------------------------------------------

"""
LoggingSettings class.
"""

class LoggingSettings(object):
    """LoggingSettings"""
    def __init__(self, log_level: str, use_dlt_for_logging: bool, use_console_for_logging: bool, use_file_for_logging: bool, log_file_path: str):
        self._log_level = log_level
        self._use_dlt_for_logging = use_dlt_for_logging
        self._use_console_for_logging = use_console_for_logging
        self._use_file_for_logging = use_file_for_logging
        self._log_file_path = log_file_path

    @property
    def log_level(self):
        """Get the log level state for vsomeipd"""
        return self._log_level

    @property
    def use_dlt_for_logging(self):
        """Get the log dlt state for vsomeipd"""
        return self._use_dlt_for_logging

    @property
    def use_console_for_logging(self):
        """Get the log console state for vsomeipd"""
        return self._use_console_for_logging

    @property
    def use_file_for_logging(self):
        """Get the log file enable state for vsomeipd"""
        return self._use_file_for_logging

    @property
    def log_file_path(self):
        """Get the log file path for vsomeipd"""
        return self._log_file_path

    @property
    def configuration_dump(self):
        result = []
        result += ["log_level: {}".format(self.log_level)]
        result += ["use_dlt_for_logging: {}".format(self.use_dlt_for_logging)]
        result += ["use_console_for_logging: {}".format(self.use_console_for_logging)]
        result += ["use_file_for_logging: {}".format(self.use_file_for_logging)]
        result += ["log_file_path: {}".format(self.log_file_path)]
        return result
