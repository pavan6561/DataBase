// --------------------------------------------------------------------------
// |              _    _ _______     .----.      _____         _____        |
// |         /\  | |  | |__   __|  .  ____ .    / ____|  /\   |  __ \       |
// |        /  \ | |  | |  | |    .  / __ \ .  | (___   /  \  | |__) |      |
// |       / /\ \| |  | |  | |   .  / / / / v   \___ \ / /\ \ |  _  /       |
// |      / /__\ \ |__| |  | |   . / /_/ /  .   ____) / /__\ \| | \ \       |
// |     /________\____/   |_|   ^ \____/  .   |_____/________\_|  \_\      |
// |                              . _ _  .                                  |
// --------------------------------------------------------------------------
//
// All Rights Reserved.
// Any use of this source code is subject to a license agreement with the
// AUTOSAR development cooperation.
// More information is available at www.autosar.org.
//
// Disclaimer
//
// This work (specification and/or software implementation) and the material
// contained in it, as released by AUTOSAR, is for the purpose of information
// only. AUTOSAR and the companies that have contributed to it shall not be
// liable for any use of the work.
//
// The material contained in this work is protected by copyright and other
// types of intellectual property rights. The commercial exploitation of the
// material contained in this work requires a license to such intellectual
// property rights.
//
// This work may be utilized or reproduced without any modification, in any
// form or by any means, for informational purposes only. For any other
// purpose, no part of the work may be utilized or reproduced, in any form
// or by any means, without permission in writing from the publisher.
//
// The work has been developed for automotive applications only. It has
// neither been developed, nor tested for non-automotive applications.
//
// The word AUTOSAR and the AUTOSAR logo are registered trademarks.
// --------------------------------------------------------------------------

#ifndef diagnostics_vsomeip_ara_diag_example_proxy_vsomeip_addinterface_h
#define diagnostics_vsomeip_ara_diag_example_proxy_vsomeip_addinterface_h

#include "service_desc_addinterface.h"
#include "ara/diag/example/addinterface_proxy.h"

namespace ara {
namespace diag {
namespace example {
namespace addinterface_binding {
namespace vsomeip {

class AddInterfaceImpl : public proxy::AddInterfaceProxyBase, public ::ara::com::internal::vsomeip::proxy::ProxyImplBase {
 public:
  using ProxyInterface = proxy::AddInterfaceProxy;
  using ServiceDescriptor = descriptors::internal::Service;

  explicit AddInterfaceImpl(ara::com::internal::InstanceId instance) :
      ::ara::com::internal::vsomeip::proxy::ProxyImplBase(ServiceDescriptor::service_id, instance, ServiceDescriptor::service_version),
      AddMethod(instance) {}

  virtual ~AddInterfaceImpl() {}

  virtual ara::diag::example::proxy::methods::AddMethod& GetAddMethod() override { return AddMethod; }

 private:
  ara::com::internal::vsomeip::proxy::MethodImpl<descriptors::AddMethod, ara::diag::example::proxy::methods::AddMethod::signature_type> AddMethod;
};

} // namespace vsomeip
} // namespace addinterface_binding
} // namespace example
} // namespace diag
} // namespace ara

#endif // diagnostics_vsomeip_ara_diag_example_proxy_vsomeip_addinterface_h

