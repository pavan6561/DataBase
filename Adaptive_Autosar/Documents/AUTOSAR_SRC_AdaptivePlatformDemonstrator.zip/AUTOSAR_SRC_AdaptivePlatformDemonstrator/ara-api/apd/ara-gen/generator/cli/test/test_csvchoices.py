#  --------------------------------------------------------------------------
#  |              _    _ _______     .----.      _____         _____        |
#  |         /\  | |  | |__   __|  .  ____ .    / ____|  /\   |  __ \       |
#  |        /  \ | |  | |  | |    .  / __ \ .  | (___   /  \  | |__) |      |
#  |       / /\ \| |  | |  | |   .  / / / / v   \___ \ / /\ \ |  _  /       |
#  |      / /__\ \ |__| |  | |   . / /_/ /  .   ____) / /__\ \| | \ \       |
#  |     /________\____/   |_|   ^ \____/  .   |_____/________\_|  \_\      |
#  |                              . _ _  .                                  |
#  --------------------------------------------------------------------------
#
#  All Rights Reserved.
#  Any use of this source code is subject to a license agreement with the
#  AUTOSAR development cooperation.
#  More information is available at www.autosar.org.
#
#  Disclaimer
#
#  This work (specification and/or software implementation) and the material
#  contained in it, as released by AUTOSAR, is for the purpose of information
#  only. AUTOSAR and the companies that have contributed to it shall not be
#  liable for any use of the work.
#
#  The material contained in this work is protected by copyright and other
#  types of intellectual property rights. The commercial exploitation of the
#  material contained in this work requires a license to such intellectual
#  property rights.
#
#  This work may be utilized or reproduced without any modification, in any
#  form or by any means, for informational purposes only. For any other
#  purpose, no part of the work may be utilized or reproduced, in any form
#  or by any means, without permission in writing from the publisher.
#
#  The work has been developed for automotive applications only. It has
#  neither been developed, nor tested for non-automotive applications.
#
#  The word AUTOSAR and the AUTOSAR logo are registered trademarks.
#  --------------------------------------------------------------------------

"""
Unit testing for aragen_args module
"""

import unittest
import argparse

from generator.cli.aragen_args import CsvChoices


class TestCsvChoices(unittest.TestCase):
    """
    Ensure the behaviour of CsvChoices is correct
    """

    def test_no_choice_means_default(self):
        """Return default choice when no choice made."""
        default_choice = "foo"
        instance = CsvChoices(name="test", choices=["foo", "bar", "baz"])
        result = instance(default_choice)
        self.assertEqual(result[0], default_choice)

    def test_all_valid_choices(self):
        """Return list of choices when valid choices."""
        instance = CsvChoices(name="test", choices=["foo", "bar", "baz"])
        result = instance("foo,baz")
        self.assertCountEqual(result, ["foo", "baz"])

    def test_exception_invalid_choice(self):
        """Raise exception on invalid choice."""
        instance = CsvChoices(name="test", choices=["foo", "bar", "baz"])
        self.assertRaises(argparse.ArgumentError, instance, "alice")

    def test_idempotent_choice(self):
        """Same choice multiple times has same effect (idempotence)."""
        instance = CsvChoices(name="test", choices=["foo", "bar", "baz"])
        result = instance("foo,foo")
        self.assertEqual(result, ["foo"])
