#  --------------------------------------------------------------------------
#  |              _    _ _______     .----.      _____         _____        |
#  |         /\  | |  | |__   __|  .  ____ .    / ____|  /\   |  __ \       |
#  |        /  \ | |  | |  | |    .  / __ \ .  | (___   /  \  | |__) |      |
#  |       / /\ \| |  | |  | |   .  / / / / v   \___ \ / /\ \ |  _  /       |
#  |      / /__\ \ |__| |  | |   . / /_/ /  .   ____) / /__\ \| | \ \       |
#  |     /________\____/   |_|   ^ \____/  .   |_____/________\_|  \_\      |
#  |                              . _ _  .                                  |
#  --------------------------------------------------------------------------
#
#  All Rights Reserved.
#  Any use of this source code is subject to a license agreement with the
#  AUTOSAR development cooperation.
#  More information is available at www.autosar.org.
#
#  Disclaimer
#
#  This work (specification and/or software implementation) and the material
#  contained in it, as released by AUTOSAR, is for the purpose of information
#  only. AUTOSAR and the companies that have contributed to it shall not be
#  liable for any use of the work.
#
#  The material contained in this work is protected by copyright and other
#  types of intellectual property rights. The commercial exploitation of the
#  material contained in this work requires a license to such intellectual
#  property rights.
#
#  This work may be utilized or reproduced without any modification, in any
#  form or by any means, for informational purposes only. For any other
#  purpose, no part of the work may be utilized or reproduced, in any form
#  or by any means, without permission in writing from the publisher.
#
#  The work has been developed for automotive applications only. It has
#  neither been developed, nor tested for non-automotive applications.
#
#  The word AUTOSAR and the AUTOSAR logo are registered trademarks.
#  --------------------------------------------------------------------------

import os
from generator.views.service_view import ServiceView
from generator.views.component_view import ComponentView
from generator.parser.exception_handling import handle_method_exceptions

class ProlocBinding(object):
    def __init__(self, template_loader, template_renderer, output_dir) -> None:
        self._render_template = template_renderer
        self._load_template = template_loader
        self._output_dir = output_dir

    @property
    def proloc_root_dir(self):
        return os.path.join(self._output_dir, 'proloc')

    def proloc_service_dir(self, service: ServiceView):
        if service.namespaces is not None:
            return os.path.join(self.proloc_root_dir, *service.namespaces)
        else:
            return self.proloc_root_dir


    @handle_method_exceptions(error_string_template="PROLOC service description generation ERROR: {exception_text}")
    def generate_proloc_service_desc(self, service_interface):
        si_desc_template_h = self._load_template(
            "proloc_binding/proloc_service_desc_xxx_h.j2", True)
        file_output_dir = self.proloc_service_dir(service_interface)
        self._render_template(si_desc_template_h, file_output_dir,
                              "proloc_service_desc_" + service_interface.standard_name + ".h",
                              service=service_interface)

    def generate_proloc_proxy(self, service: ServiceView):
        proxy_template = self._load_template(
            "proloc_binding/proloc_proxy_xxx_h.j2", True)
        file_output_dir = self.proloc_service_dir(service)
        self._render_template(proxy_template, file_output_dir,
                              "proloc_proxy_" + service.standard_name + ".h",
                              service=service)

    def generate_proloc_si_adapter(self, service: ServiceView):
        si_adapter_template = self._load_template(
            "proloc_binding/proloc_adapter_xxx_h.j2", True)
        file_output_dir = self.proloc_service_dir(service)
        self._render_template(si_adapter_template, file_output_dir,
                              "proloc_adapter_" + service.standard_name + ".h",
                              service=service)

    def generate_proloc_sm_definition(self, component: ComponentView):
        sm_def_template_cpp = self._load_template(
            "proloc_binding/proloc_service_mapping-xxx_cpp.j2")
        file_output_dir = self.proloc_root_dir
        self._render_template(
            sm_def_template_cpp, file_output_dir,
            "proloc_service_mapping-" + component.name + ".cpp",
            component=component)
