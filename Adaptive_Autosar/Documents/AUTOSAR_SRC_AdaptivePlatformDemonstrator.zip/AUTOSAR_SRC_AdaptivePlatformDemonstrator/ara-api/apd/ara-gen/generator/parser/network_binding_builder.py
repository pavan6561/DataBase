#  --------------------------------------------------------------------------
#  |              _    _ _______     .----.      _____         _____        |
#  |         /\  | |  | |__   __|  .  ____ .    / ____|  /\   |  __ \       |
#  |        /  \ | |  | |  | |    .  / __ \ .  | (___   /  \  | |__) |      |
#  |       / /\ \| |  | |  | |   .  / / / / v   \___ \ / /\ \ |  _  /       |
#  |      / /__\ \ |__| |  | |   . / /_/ /  .   ____) / /__\ \| | \ \       |
#  |     /________\____/   |_|   ^ \____/  .   |_____/________\_|  \_\      |
#  |                              . _ _  .                                  |
#  --------------------------------------------------------------------------
#
#  All Rights Reserved.
#  Any use of this source code is subject to a license agreement with the
#  AUTOSAR development cooperation.
#  More information is available at www.autosar.org.
#
#  Disclaimer
#
#  This work (specification and/or software implementation) and the material
#  contained in it, as released by AUTOSAR, is for the purpose of information
#  only. AUTOSAR and the companies that have contributed to it shall not be
#  liable for any use of the work.
#
#  The material contained in this work is protected by copyright and other
#  types of intellectual property rights. The commercial exploitation of the
#  material contained in this work requires a license to such intellectual
#  property rights.
#
#  This work may be utilized or reproduced without any modification, in any
#  form or by any means, for informational purposes only. For any other
#  purpose, no part of the work may be utilized or reproduced, in any form
#  or by any means, without permission in writing from the publisher.
#
#  The work has been developed for automotive applications only. It has
#  neither been developed, nor tested for non-automotive applications.
#
#  The word AUTOSAR and the AUTOSAR logo are registered trademarks.
#  --------------------------------------------------------------------------

"""
Network binding class.
"""

# pylint: disable=too-many-lines,too-many-public-methods
import logging

from generator.intermediate_model.communication_management.ara_com_deployment.\
    someip.someip_service_deployment import SomeIpServiceDeployment  # noqa
from generator.intermediate_model.communication_management.ara_com_deployment.\
    user_defined.user_defined_service_deployment import UserDefinedServiceDeployment  # noqa
from generator.parser.someip_svc_deployment_builder import SomeIpServiceDeploymentBuilder
from generator.parser.user_defined_svc_deployment_builder import UserDefinedServiceDeploymentBuilder


class NetworkBindingBuilder():
    """
    Handles parsing the ARXML part, related to network binding, and provides service deployment objects.
    """

    def __init__(self, model):
        self._log = logging.getLogger(__name__)
        self.model = model

        self.someip_svc_deployment = SomeIpServiceDeploymentBuilder(self.model)
        self.user_defined_svc_deployment = UserDefinedServiceDeploymentBuilder()

    def _get_provided_ar_si_from_ar_port(self, ar_port_fqn):
        ar_si_to_app_endpoint_mappings = self.model.find_elements_of_type(
            'SERVICE-INSTANCE-TO-PORT-PROTOTYPE-MAPPING',
            accept=lambda e: str(
                e.PORT_PROTOTYPE_IREF.TARGET_PORT_PROTOTYPE_REF) == ar_port_fqn)

        if ar_si_to_app_endpoint_mappings:
            endpoint_mapping = ar_si_to_app_endpoint_mappings[0]
            ar_process_refs = endpoint_mapping.find_elements_of_type(
                'PROCESS-REF', DEST='PROCESS')
            assert len(
                ar_process_refs) == 1, "Need exactly one PROCESS-REF " + \
                                       "for SI to app endpoint mapping: " + \
                                       endpoint_mapping.SHORT_NAME
            ar_si_someip_refs = endpoint_mapping.find_elements_of_type(
                'SERVICE-INSTANCE-REF',
                DEST='PROVIDED-SOMEIP-SERVICE-INSTANCE')
            ar_si_dds_refs = endpoint_mapping.find_elements_of_type(
                'SERVICE-INSTANCE-REF',
                DEST='DDS-PROVIDED-SERVICE-INSTANCE')
            ar_si_user_defined_refs = endpoint_mapping.find_elements_of_type(
                'SERVICE-INSTANCE-REF',
                DEST='PROVIDED-USER-DEFINED-SERVICE-INSTANCE')

            assert (len(ar_si_someip_refs) + len(ar_si_dds_refs) + len(ar_si_user_defined_refs)) == 1, \
                "Need exactly one SERVICE-INSTANCE-REF for " + \
                "SERVICE-INSTANCE-TO-PORT-PROTOTYPE-MAPPING: " + \
                endpoint_mapping.SHORT_NAME

            ar_si_refs = list()
            if ar_si_someip_refs:
                ar_si_refs = ar_si_someip_refs
            if ar_si_user_defined_refs:
                ar_si_refs = ar_si_user_defined_refs
            if ar_si_dds_refs:
                ar_si_refs = ar_si_dds_refs
            return self.model.find_referable(str(ar_si_refs[0]))

    def _get_required_ar_si_from_ar_port(self, ar_port_fqn):
        ar_si_to_app_endpoint_mappings = self.model.find_elements_of_type(
            'SERVICE-INSTANCE-TO-PORT-PROTOTYPE-MAPPING',
            accept=lambda e: str(
                e.PORT_PROTOTYPE_IREF.TARGET_PORT_PROTOTYPE_REF) == ar_port_fqn)

        if ar_si_to_app_endpoint_mappings:
            endpoint_mapping = ar_si_to_app_endpoint_mappings[0]
            ar_process_refs = endpoint_mapping.find_elements_of_type(
                'PROCESS-REF', DEST='PROCESS')
            assert len(
                ar_process_refs) == 1, "Need exactly one PROCESS-REF " + \
                                       "for SI to app endpoint mapping: " + \
                                       endpoint_mapping.SHORT_NAME
            ar_si_someip_refs = endpoint_mapping.find_elements_of_type(
                'SERVICE-INSTANCE-REF',
                DEST='REQUIRED-SOMEIP-SERVICE-INSTANCE')
            ar_si_dds_refs = endpoint_mapping.find_elements_of_type(
                'SERVICE-INSTANCE-REF',
                DEST='DDS-REQUIRED-SERVICE-INSTANCE')
            ar_si_user_defined_refs = endpoint_mapping.find_elements_of_type(
                'SERVICE-INSTANCE-REF',
                DEST='REQUIRED-USER-DEFINED-SERVICE-INSTANCE')

            assert (len(ar_si_someip_refs) + len(ar_si_dds_refs) + len(ar_si_user_defined_refs)) == 1, \
                "Need exactly one SERVICE-INSTANCE-REF for " + \
                "SERVICE-INSTANCE-TO-PORT-PROTOTYPE-MAPPING: " + \
                endpoint_mapping.SHORT_NAME

            ar_si_refs = list()
            if ar_si_someip_refs:
                ar_si_refs = ar_si_someip_refs
            if ar_si_user_defined_refs:
                ar_si_refs = ar_si_user_defined_refs
            if ar_si_dds_refs:
                ar_si_refs = ar_si_dds_refs
            return self.model.find_referable(str(ar_si_refs[0]))

    def _get_si_to_machine_mappings(self, ar_si_fqn):
        si_to_machine_mappings = self.model.find_elements_of_type(
            'SOMEIP-SERVICE-INSTANCE-TO-MACHINE-MAPPING',
            accept=lambda e: str(
                e.SERVICE_INSTANCE_REF) == ar_si_fqn)

        if not si_to_machine_mappings:
            si_to_machine_mappings = self.model.find_elements_of_type(
                'DDS-SERVICE-INSTANCE-TO-MACHINE-MAPPING',
                accept=lambda e: str(
                    e.SERVICE_INSTANCE_REF) == ar_si_fqn)
        if not si_to_machine_mappings:
            si_to_machine_mappings = self.model.find_elements_of_type(
                'USER-DEFINED-SERVICE-INSTANCE-TO-MACHINE-MAPPING',
                accept=lambda e: str(
                    e.SERVICE_INSTANCE_REF) == ar_si_fqn)
        assert len(si_to_machine_mappings) == 1, \
            "Need exactly one " + \
            "SERVICE-INSTANCE-TO-MACHINE-MAPPING " + \
            "for SERVICE-INSTANCE: " + \
            ar_si_fqn()
        return si_to_machine_mappings[0]

    def get_provided_svc_deployments(self, ar_port):
        """Extract provided service deployment information"""
        service_deployments = []

        provided_ref = ar_port.PROVIDED_INTERFACE_TREF
        someip_deployments = \
            self.model.find_elements_of_type('SOMEIP-SERVICE-INTERFACE-DEPLOYMENT',
                                             accept=lambda e: str(e.SERVICE_INTERFACE_REF) == provided_ref)
        dds_deployments = \
            self.model.find_elements_of_type('DDS-SERVICE-INTERFACE-DEPLOYMENT',
                                             accept=lambda e: str(e.SERVICE_INTERFACE_REF) == provided_ref)
        user_defined_deployments = \
            self.model.find_elements_of_type('USER-DEFINED-SERVICE-INTERFACE-DEPLOYMENT',
                                             accept=lambda e: str(e.SERVICE_INTERFACE_REF) == provided_ref)

        # Get the AUTOSAR Service Interface for AR Port
        ar_si = self._get_provided_ar_si_from_ar_port(ar_port.get_fqn())

        for ar_deployment in someip_deployments:
            ports_config = []
            if ar_si is not None:
                if ar_si.short_tag() == "PROVIDED-SOMEIP-SERVICE-INSTANCE":
                    ports_config = self.someip_svc_deployment.get_net_ports_config(
                        self._get_si_to_machine_mappings(ar_si.get_fqn()))
            si_deployment = self.someip_svc_deployment.get_provided_si_deployment(ar_si)
            deployment = self.someip_svc_deployment.get_instance_deployment(ar_deployment)
            psi_deployment = {**si_deployment, **deployment}

            service_deployment = SomeIpServiceDeployment()
            service_deployment.ports = ports_config
            service_deployment.deployment_id = psi_deployment["service_id"]
            service_deployment.instance_id = psi_deployment["instance_id"]
            service_deployment.sd_config = psi_deployment["sd_config"]
            service_deployment.provided = psi_deployment
            service_deployments.append(service_deployment)

        for ar_deployment in dds_deployments:
            pass

        for ar_deployment in user_defined_deployments:
            # As someip is used for userdef network binding,
            # deployment instance information getter functions from someip deployment builder are used.
            ports_config = []
            if ar_si is not None:
                if ar_si.short_tag() == "PROVIDED-USER-DEFINED-SERVICE-INSTANCE":
                    ports_config = self.someip_svc_deployment.get_net_ports_config(
                        self._get_si_to_machine_mappings(ar_si.get_fqn()))
            si_deployment = self.someip_svc_deployment.get_provided_si_deployment(ar_si)

            deployment = self.user_defined_svc_deployment.get_instance_deployment(ar_deployment)
            psi_deployment = {**si_deployment, **deployment}

            service_deployment = UserDefinedServiceDeployment()
            service_deployment.ports = ports_config
            service_deployment.deployment_id = psi_deployment["service_id"]
            service_deployment.instance_id = psi_deployment["instance_id"]
            service_deployment.sd_config = psi_deployment["sd_config"]
            service_deployment.provided = psi_deployment
            service_deployments.append(service_deployment)

        return service_deployments

    def get_required_svc_deployments(self, ar_port):
        """Extract provided service deployment information"""
        service_deployments = []

        required_ref = ar_port.REQUIRED_INTERFACE_TREF
        someip_deployments = \
            self.model.find_elements_of_type('SOMEIP-SERVICE-INTERFACE-DEPLOYMENT',
                                             accept=lambda e: str(e.SERVICE_INTERFACE_REF) == required_ref)
        dds_deployments = \
            self.model.find_elements_of_type('DDS-SERVICE-INTERFACE-DEPLOYMENT',
                                             accept=lambda e: str(e.SERVICE_INTERFACE_REF) == required_ref)
        user_defined_deployments = \
            self.model.find_elements_of_type('USER-DEFINED-SERVICE-INTERFACE-DEPLOYMENT',
                                             accept=lambda e: str(e.SERVICE_INTERFACE_REF) == required_ref)

        # Get the AUTOSAR Service Interface for AR Port
        ar_si = self._get_required_ar_si_from_ar_port(ar_port.get_fqn())

        for ar_deployment in someip_deployments:
            ports_config = []
            if ar_si is not None:
                if ar_si.short_tag() == "REQUIRED-SOMEIP-SERVICE-INSTANCE":
                    ports_config = self.someip_svc_deployment.get_net_ports_config(
                        self._get_si_to_machine_mappings(ar_si.get_fqn()))
            si_deployment = self.someip_svc_deployment.get_required_si_deployment(ar_si)
            deployment = self.someip_svc_deployment.get_instance_deployment(ar_deployment)
            rsi_deployment = {**si_deployment, **deployment}

            service_deployment = SomeIpServiceDeployment()
            service_deployment.ports = ports_config
            service_deployment.deployment_id = rsi_deployment["service_id"]
            service_deployment.instance_id = rsi_deployment["instance_id"]
            service_deployment.sd_config = rsi_deployment["sd_config"]
            service_deployment.required = rsi_deployment
            service_deployments.append(service_deployment)

        for ar_deployment in dds_deployments:
            pass

        for ar_deployment in user_defined_deployments:
            # As someip is used for userdef network binding,
            # deployment instance information getter functions from someip deployment builder are used.
            ports_config = []
            if ar_si is not None:
                if ar_si.short_tag() == "REQUIRED-USER-DEFINED-SERVICE-INSTANCE":
                    ports_config = self.someip_svc_deployment.get_net_ports_config(
                        self._get_si_to_machine_mappings(ar_si.get_fqn()))
            si_deployment = self.someip_svc_deployment.get_required_si_deployment(ar_si)

            deployment = self.user_defined_svc_deployment.get_instance_deployment(ar_deployment)
            rsi_deployment = {**si_deployment, **deployment}

            service_deployment = UserDefinedServiceDeployment()
            service_deployment.ports = ports_config
            service_deployment.deployment_id = rsi_deployment["service_id"]
            service_deployment.instance_id = rsi_deployment["instance_id"]
            service_deployment.sd_config = rsi_deployment["sd_config"]
            service_deployment.required = rsi_deployment
            service_deployments.append(service_deployment)

        return service_deployments

    def populate_deployment(self, service, deployment):
        """Populate service with deployment information"""
        if type(deployment) is SomeIpServiceDeployment:
            self.someip_svc_deployment.populate_deployment(service, deployment)
        elif type(deployment) is UserDefinedServiceDeployment:
            # As someip is used for userdef network binding,
            # deployment population function from someip deployment builder is used.
            # When populate_deployment() function for userdef binding should differ from someip implementation,
            # will be better to call it from UserDefinedServiceDeploymentBuilder
            self.someip_svc_deployment.populate_deployment(service, deployment)
