#  --------------------------------------------------------------------------
#  |              _    _ _______     .----.      _____         _____        |
#  |         /\  | |  | |__   __|  .  ____ .    / ____|  /\   |  __ \       |
#  |        /  \ | |  | |  | |    .  / __ \ .  | (___   /  \  | |__) |      |
#  |       / /\ \| |  | |  | |   .  / / / / v   \___ \ / /\ \ |  _  /       |
#  |      / /__\ \ |__| |  | |   . / /_/ /  .   ____) / /__\ \| | \ \       |
#  |     /________\____/   |_|   ^ \____/  .   |_____/________\_|  \_\      |
#  |                              . _ _  .                                  |
#  --------------------------------------------------------------------------
#
#  All Rights Reserved.
#  Any use of this source code is subject to a license agreement with the
#  AUTOSAR development cooperation.
#  More information is available at www.autosar.org.
#
#  Disclaimer
#
#  This work (specification and/or software implementation) and the material
#  contained in it, as released by AUTOSAR, is for the purpose of information
#  only. AUTOSAR and the companies that have contributed to it shall not be
#  liable for any use of the work.
#
#  The material contained in this work is protected by copyright and other
#  types of intellectual property rights. The commercial exploitation of the
#  material contained in this work requires a license to such intellectual
#  property rights.
#
#  This work may be utilized or reproduced without any modification, in any
#  form or by any means, for informational purposes only. For any other
#  purpose, no part of the work may be utilized or reproduced, in any form
#  or by any means, without permission in writing from the publisher.
#
#  The work has been developed for automotive applications only. It has
#  neither been developed, nor tested for non-automotive applications.
#
#  The word AUTOSAR and the AUTOSAR logo are registered trademarks.
#  --------------------------------------------------------------------------

"""
Service deployment class.
"""

from generator.intermediate_model.utils.container import Container
from ..service_deployment import ServiceDeployment
from ...ara_com_deployment.someip.event_group_deployment import EventGroupDeployment


class SomeIpServiceDeployment(ServiceDeployment):
    """Describes deployment information necessary for a Service"""

    def __init__(self):
        super().__init__()
        self._id = ""
        self._instance_id = ""
        self._ports = None
        self._sd_config = None
        self._event_group_deployments = Container()
        self._required = None
        self._provided = None

    @property
    def deployment_id(self) -> str:
        """Get the service deployment id"""
        return self._id

    @deployment_id.setter
    def deployment_id(self, deployment_id: str):
        """Set the service deployment id"""
        self._id = deployment_id

    @property
    def instance_id(self) -> str:
        """Get the service deployment instance id"""
        return self._instance_id

    @instance_id.setter
    def instance_id(self, instance_id: str):
        """Set the service deployment instance id"""
        self._instance_id = instance_id

    @property
    def ports(self):
        """Get the service deployment ports"""
        return self._ports

    @ports.setter
    def ports(self, ports):
        """Set the service deployment ports"""
        self._ports = ports

    @property
    def event_groups(self) -> Container:
        """Get the event groups in the service"""
        return self._event_group_deployments

    def add_event_group_deployment(self, event_group: EventGroupDeployment):
        """Add an event group to the service"""
        self._event_group_deployments.append(event_group)

    @property
    def sd_config(self) -> dict:
        """Get the sd config information for this service deployment"""
        return self._sd_config

    @sd_config.setter
    def sd_config(self, sd_config):
        """Set the sd config information for this service deployment"""
        self._sd_config = sd_config

    @property
    def required(self):
        """Get the required deployment information for this service deployment"""
        return self._required

    @required.setter
    def required(self, required_deployment):
        """Set the required deployment information for this service deployment"""
        self._required = required_deployment

    @property
    def provided(self):
        """Get the provided deployment information for this service deployment"""
        return self._provided

    @provided.setter
    def provided(self, provided_deployment):
        """Set the provided deployment information for this service deployment"""
        self._provided = provided_deployment
