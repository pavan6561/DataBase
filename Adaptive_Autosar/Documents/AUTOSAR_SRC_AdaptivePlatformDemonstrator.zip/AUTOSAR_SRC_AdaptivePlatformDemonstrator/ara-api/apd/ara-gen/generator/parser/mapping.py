#  --------------------------------------------------------------------------
#  |              _    _ _______     .----.      _____         _____        |
#  |         /\  | |  | |__   __|  .  ____ .    / ____|  /\   |  __ \       |
#  |        /  \ | |  | |  | |    .  / __ \ .  | (___   /  \  | |__) |      |
#  |       / /\ \| |  | |  | |   .  / / / / v   \___ \ / /\ \ |  _  /       |
#  |      / /__\ \ |__| |  | |   . / /_/ /  .   ____) / /__\ \| | \ \       |
#  |     /________\____/   |_|   ^ \____/  .   |_____/________\_|  \_\      |
#  |                              . _ _  .                                  |
#  --------------------------------------------------------------------------
#
#  All Rights Reserved.
#  Any use of this source code is subject to a license agreement with the
#  AUTOSAR development cooperation.
#  More information is available at www.autosar.org.
#
#  Disclaimer
#
#  This work (specification and/or software implementation) and the material
#  contained in it, as released by AUTOSAR, is for the purpose of information
#  only. AUTOSAR and the companies that have contributed to it shall not be
#  liable for any use of the work.
#
#  The material contained in this work is protected by copyright and other
#  types of intellectual property rights. The commercial exploitation of the
#  material contained in this work requires a license to such intellectual
#  property rights.
#
#  This work may be utilized or reproduced without any modification, in any
#  form or by any means, for informational purposes only. For any other
#  purpose, no part of the work may be utilized or reproduced, in any form
#  or by any means, without permission in writing from the publisher.
#
#  The work has been developed for automotive applications only. It has
#  neither been developed, nor tested for non-automotive applications.
#
#  The word AUTOSAR and the AUTOSAR logo are registered trademarks.
#  --------------------------------------------------------------------------

"""
Sample mapping from ARXML to user-defined class.
"""

from lxml import etree

from generator.parser.arxml_wrappers.execution_management.application \
    import Application


class AUTOSARLookup(etree.CustomElementClassLookup):
    """
    This class handles the mapping between the classes in the
    intermediate model and the tag names in the ARXML.
    For example we can specify that all tags called
    ADAPTIVE-APPLICATION-SW-COMPONENT-TYPE should be objects of the
    class Application.
    If we do not specify any specific class the fallback will be taken.
    In our case this will be the normal objectify objects.
    """
    def lookup(self, node_type, document, namespace, name):
        """
        See http://lxml.de/element_classes.html#custom-element-class-lookup for
        documentation.
        :param node_type: one of 'element', 'comment', 'PI', 'entity'
        :param document: document that the node is in
        :param namespace: namespace URI of the node
                          (or None for comments/PIs/entities)
        :param name: name of the element/entity, None for comments,
                     target for PIs
        :return: The custom object or None to fallback to standard objectify
                 objects
        """
        _document = document  # just implemented to remove linter errors
        _namespace = namespace
        if node_type == 'element':
            switch = {
                "ADAPTIVE-APPLICATION-SW-COMPONENT-TYPE": Application,
            }
            return switch.get(name, None)

        # pass on to  fallback, in our case Objectify
        return None
