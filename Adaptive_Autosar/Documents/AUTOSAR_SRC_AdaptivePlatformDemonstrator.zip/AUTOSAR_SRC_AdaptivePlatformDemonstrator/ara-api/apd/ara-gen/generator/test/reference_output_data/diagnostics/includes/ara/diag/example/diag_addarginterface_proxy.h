// --------------------------------------------------------------------------
// |              _    _ _______     .----.      _____         _____        |
// |         /\  | |  | |__   __|  .  ____ .    / ____|  /\   |  __ \       |
// |        /  \ | |  | |  | |    .  / __ \ .  | (___   /  \  | |__) |      |
// |       / /\ \| |  | |  | |   .  / / / / v   \___ \ / /\ \ |  _  /       |
// |      / /__\ \ |__| |  | |   . / /_/ /  .   ____) / /__\ \| | \ \       |
// |     /________\____/   |_|   ^ \____/  .   |_____/________\_|  \_\      |
// |                              . _ _  .                                  |
// --------------------------------------------------------------------------
//
// All Rights Reserved.
// Any use of this source code is subject to a license agreement with the
// AUTOSAR development cooperation.
// More information is available at www.autosar.org.
//
// Disclaimer
//
// This work (specification and/or software implementation) and the material
// contained in it, as released by AUTOSAR, is for the purpose of information
// only. AUTOSAR and the companies that have contributed to it shall not be
// liable for any use of the work.
//
// The material contained in this work is protected by copyright and other
// types of intellectual property rights. The commercial exploitation of the
// material contained in this work requires a license to such intellectual
// property rights.
//
// This work may be utilized or reproduced without any modification, in any
// form or by any means, for informational purposes only. For any other
// purpose, no part of the work may be utilized or reproduced, in any form
// or by any means, without permission in writing from the publisher.
//
// The work has been developed for automotive applications only. It has
// neither been developed, nor tested for non-automotive applications.
//
// The word AUTOSAR and the AUTOSAR logo are registered trademarks.
// --------------------------------------------------------------------------

#ifndef diagnostics_includes_ara_diag_example_diag_addarginterface_proxy_h
#define diagnostics_includes_ara_diag_example_diag_addarginterface_proxy_h

#include "ara/com/internal/proxy/ara_proxy_base.h"
#include "diag_addarginterface_common.h"

namespace ara {
namespace diag {
namespace example {
namespace proxy {

namespace methods {
  /// @uptrace{SWS_CM_00006}
  using AddArgMethod_Start = ara::com::internal::proxy::Method<ara::diag::example::Diag_AddArgInterface::AddArgMethod_StartOutput(const std::int32_t&)>;
  using AddArgMethod_Stop = ara::com::internal::proxy::Method<ara::diag::example::Diag_AddArgInterface::AddArgMethod_StopOutput()>;
} // namespace methods



class Diag_AddArgInterfaceProxyBase : public ara::com::internal::proxy::ProxyBindingBase, public ara::diag::example::Diag_AddArgInterface {
public:
  virtual methods::AddArgMethod_Start& GetAddArgMethod_Start() = 0;
  virtual methods::AddArgMethod_Stop& GetAddArgMethod_Stop() = 0;
};

/// @uptrace{SWS_CM_00004}
class Diag_AddArgInterfaceProxy : public ara::com::internal::proxy::ProxyBase<Diag_AddArgInterfaceProxyBase>, public ara::diag::example::Diag_AddArgInterface {
private:

public:
  /// @brief Proxy constructor.
  ///
  /// @uptrace{SWS_CM_00131}
  explicit Diag_AddArgInterfaceProxy(const HandleType& proxy_base_factory)
      : ara::com::internal::proxy::ProxyBase<Diag_AddArgInterfaceProxyBase>(proxy_base_factory)
      , AddArgMethod_Start(proxy_base_->GetAddArgMethod_Start())
      , AddArgMethod_Stop(proxy_base_->GetAddArgMethod_Stop())
  {}

  /// @brief Proxy shall be move constructable.
  ///
  /// @uptrace{SWS_CM_00137}
  explicit Diag_AddArgInterfaceProxy(Diag_AddArgInterfaceProxy&&) = default;

  /// @brief Proxy shall be move assignable.
  ///
  /// @uptrace{SWS_CM_00137}
  Diag_AddArgInterfaceProxy& operator=(Diag_AddArgInterfaceProxy&&) = default;

  /// @brief Proxy shall not be copy constructable.
  ///
  /// @uptrace{SWS_CM_00136}
  explicit Diag_AddArgInterfaceProxy(const Diag_AddArgInterfaceProxy&) = delete;

  /// @brief Proxy shall not be copy assignable.
  ///
  /// @uptrace{SWS_CM_00136}
  Diag_AddArgInterfaceProxy& operator=(const Diag_AddArgInterfaceProxy&) = delete;

  /// @uptrace{SWS_CM_00196}
  methods::AddArgMethod_Start& AddArgMethod_Start;
  methods::AddArgMethod_Stop& AddArgMethod_Stop;
};

} // namespace proxy
} // namespace example
} // namespace diag
} // namespace ara

#endif // diagnostics_includes_ara_diag_example_diag_addarginterface_proxy_h

