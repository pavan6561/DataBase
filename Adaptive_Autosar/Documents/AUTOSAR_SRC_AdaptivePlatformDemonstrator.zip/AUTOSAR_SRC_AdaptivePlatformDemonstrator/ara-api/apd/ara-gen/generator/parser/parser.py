#  --------------------------------------------------------------------------
#  |              _    _ _______     .----.      _____         _____        |
#  |         /\  | |  | |__   __|  .  ____ .    / ____|  /\   |  __ \       |
#  |        /  \ | |  | |  | |    .  / __ \ .  | (___   /  \  | |__) |      |
#  |       / /\ \| |  | |  | |   .  / / / / v   \___ \ / /\ \ |  _  /       |
#  |      / /__\ \ |__| |  | |   . / /_/ /  .   ____) / /__\ \| | \ \       |
#  |     /________\____/   |_|   ^ \____/  .   |_____/________\_|  \_\      |
#  |                              . _ _  .                                  |
#  --------------------------------------------------------------------------
#
#  All Rights Reserved.
#  Any use of this source code is subject to a license agreement with the
#  AUTOSAR development cooperation.
#  More information is available at www.autosar.org.
#
#  Disclaimer
#
#  This work (specification and/or software implementation) and the material
#  contained in it, as released by AUTOSAR, is for the purpose of information
#  only. AUTOSAR and the companies that have contributed to it shall not be
#  liable for any use of the work.
#
#  The material contained in this work is protected by copyright and other
#  types of intellectual property rights. The commercial exploitation of the
#  material contained in this work requires a license to such intellectual
#  property rights.
#
#  This work may be utilized or reproduced without any modification, in any
#  form or by any means, for informational purposes only. For any other
#  purpose, no part of the work may be utilized or reproduced, in any form
#  or by any means, without permission in writing from the publisher.
#
#  The work has been developed for automotive applications only. It has
#  neither been developed, nor tested for non-automotive applications.
#
#  The word AUTOSAR and the AUTOSAR logo are registered trademarks.
#  --------------------------------------------------------------------------

"""
ARXML parser.
"""

import logging
import sys
import os
import glob
from lxml import etree, objectify

from generator.parser.autosar_mapping import AUTOSARMapping
from generator.parser.mapping import AUTOSARLookup
import generator.parser
from generator.parser.merge import merge_files, to_string
from generator.parser.tree_helper import get_schema_file_from_tree


class Parser:
    """
    Creates lxml parsers and checks input ARXMLs against a given schema
    """

    def __init__(self):
        """
        :param schema_version: Specifies which schema version should be used to
                               validate the ARXML files
        """
        self._log = logging.getLogger(__name__)

    def get_parser(self):
        """
        Convenience function to get the XMLParser from etree
        :return: etree.XMLParser
        """
        xml_parser = etree.XMLParser(remove_comments=True, remove_blank_text=True)

        xml_parser.setElementClassLookup(AUTOSARLookup(
            objectify.ObjectifyElementClassLookup(tree_class=AUTOSARMapping)))

        return xml_parser

    def _validate(self, tree, source):
        """
        Validates an ARXML-Tree
        :param tree etree.ElementTree
        :param source: Description of ARXML-Tree source
        """
        schema_file = get_schema_file_from_tree(tree)
        schema = etree.XMLSchema(file = open(schema_file))
        self._log.debug("Started ARXML validation. Schema %s will be used", schema_file)

        if schema.validate(tree):
            self._log.info("ARXML validation successfully finished. SOURCE=%s", source)
        else:
            self._log.error("ARXML validation failed! SCHEMA=%s SOURCE=%s", schema_file, source)
            for error in schema.error_log:
                self._log.error("line:%d %s", error.line, error.message)
            sys.exit("XML validation failed!")

    def _parse_path(self, arxml_path):
        """
        Parses an ARXML-File
        :param arxml_path: Path where to find the ARXML to use
        :return: objectify.ObjectifiedElement
        """
        with open(arxml_path, 'r') as arxml_file:
            return self._parse_file(arxml_file)

    def _parse_file(self, arxml_file):
        """
        Parses an ARXML-File
        :param arxml_file: Path where to find the ARXML to use
        :return: objectify.ObjectifiedElement
        """
        arxml_contents = arxml_file.read().encode(generator.parser.TEXT_ENCODING)
        return self._parse_string(arxml_contents)

    def _parse_string(self, arxml_contents):
        """
        Parses an ARXML from string.
        :param arxml_contents: ARXML string in utf-8
        :return: objectify.ObjectifiedElement
        """
        return objectify.fromstring(arxml_contents, self.get_parser())

    def _parse_file_list(self, content):
        merged = merge_files(self._create_file_list(content), parser=self.get_parser())
        return self._parse_string(to_string(merged))

    def _create_file_list(self, content):
        filelist = list()
        for file_arg in content:
            if os.path.isdir(file_arg):
                # Directory parameter. Create list of all arxml files in the directory
                files = [arg for arg in glob.glob(file_arg + "/*.arxml*")]
            elif '*' in file_arg:
                # Handle wildcard to create list
                files = [arg for arg in glob.glob(file_arg)]
            else:
                # File name
                files = [file_arg]

            for file in files:
                if os.path.isfile(file):
                    filelist.append(file)
        return filelist

    def parse(self, content, validate=True) -> objectify.ObjectifiedElement:
        """
        Parses ARXML (string, path, file)
        :param content: ARXML to use
        :return: objectify.ObjectifiedElement
        """
        if isinstance(content, list):
            tree = self._parse_file_list(content)
            if validate is True:
                for filename in self._create_file_list(content):
                    self._validate(self._parse_path(filename), filename)
        elif isinstance(content, str):
            if content.lstrip().startswith('<'):
                # ARXML
                tree = self._parse_string(content)
            else:
                tree = self._parse_path(content)

            if validate is True:
                self._validate(tree, content)
        else:
            tree = self._parse_file(content)
            if validate is True:
                self._validate(tree, content.name)

        return tree
