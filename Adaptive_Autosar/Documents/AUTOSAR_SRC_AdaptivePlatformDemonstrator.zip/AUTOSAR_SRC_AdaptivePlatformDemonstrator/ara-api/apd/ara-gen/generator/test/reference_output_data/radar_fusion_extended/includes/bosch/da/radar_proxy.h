// --------------------------------------------------------------------------
// |              _    _ _______     .----.      _____         _____        |
// |         /\  | |  | |__   __|  .  ____ .    / ____|  /\   |  __ \       |
// |        /  \ | |  | |  | |    .  / __ \ .  | (___   /  \  | |__) |      |
// |       / /\ \| |  | |  | |   .  / / / / v   \___ \ / /\ \ |  _  /       |
// |      / /__\ \ |__| |  | |   . / /_/ /  .   ____) / /__\ \| | \ \       |
// |     /________\____/   |_|   ^ \____/  .   |_____/________\_|  \_\      |
// |                              . _ _  .                                  |
// --------------------------------------------------------------------------
//
// All Rights Reserved.
// Any use of this source code is subject to a license agreement with the
// AUTOSAR development cooperation.
// More information is available at www.autosar.org.
//
// Disclaimer
//
// This work (specification and/or software implementation) and the material
// contained in it, as released by AUTOSAR, is for the purpose of information
// only. AUTOSAR and the companies that have contributed to it shall not be
// liable for any use of the work.
//
// The material contained in this work is protected by copyright and other
// types of intellectual property rights. The commercial exploitation of the
// material contained in this work requires a license to such intellectual
// property rights.
//
// This work may be utilized or reproduced without any modification, in any
// form or by any means, for informational purposes only. For any other
// purpose, no part of the work may be utilized or reproduced, in any form
// or by any means, without permission in writing from the publisher.
//
// The work has been developed for automotive applications only. It has
// neither been developed, nor tested for non-automotive applications.
//
// The word AUTOSAR and the AUTOSAR logo are registered trademarks.
// --------------------------------------------------------------------------

#ifndef radar_fusion_extended_includes_bosch_da_radar_proxy_h
#define radar_fusion_extended_includes_bosch_da_radar_proxy_h

#include "ara/com/internal/proxy/ara_proxy_base.h"
#include "radar_common.h"

namespace bosch {
namespace da {
namespace proxy {

namespace methods {
  /// @uptrace{SWS_CM_00006}
  using Adjust = ara::com::internal::proxy::Method<bosch::da::radar::AdjustOutput(const ::Position&)>;
  using Calibrate = ara::com::internal::proxy::Method<bosch::da::radar::CalibrateOutput(const ::String&,const ::FusionVariant&)>;
} // namespace methods

namespace fields {
using UpdateRateField = ara::com::internal::proxy::MutableField<::UInt32>;
template <typename T, bool E2E = ara::com::internal::e2e::is_e2e_enabled<T>::value>
class UpdateRateProxy {
private:
  UpdateRateField& field;

public:
  explicit UpdateRateProxy(UpdateRateField& field_base)
      : field(field_base)
      /// @uptrace{SWS_CM_00133}
      , Set(field_base.Set)
  { }

  // Event Base.
  void Subscribe(ara::com::EventCacheUpdatePolicy policy, std::size_t cacheSize) {
    field.Subscribe(policy, cacheSize);
  }
  
  bool IsSubscribed() const {
    return field.IsSubscribed();
  }

  void Unsubscribe() {
    return field.Unsubscribe();
  }

  void Cleanup() {
    field.Cleanup();
  }

  void SetReceiveHandler(ara::com::EventReceiveHandler handler) {
    field.SetReceiveHandler(handler);
  }

  void UnsetReceiveHandler() {
    field.UnsetReceiveHandler();
  }

  void SetSubscriptionStateChangeHandler(ara::com::SubscriptionStateChangeHandler handler) {
    field.SetSubscriptionStateChangeHandler(handler);
  }

  void UnsetSubscriptionStateChangeHandler() {
    field.UnsetSubscriptionStateChangeHandler();
  }

  using container_type = UpdateRateField::container_type;

  // Event.
  bool Update() {
    return field.Update();
  }

  bool Update(ara::com::FilterFunction<T> filter) {
    return field.Update(filter);
  }

  const container_type &GetCachedSamples() const {
    return field.GetCachedSamples();
  }

  template <typename U=T, typename = std::enable_if_t<E2E, U>>
  ara::com::e2exf::E2EResult GetE2EResult() const noexcept {
    return field.GetE2EResult();
  }

  /// @brief Field.
  /// @uptrace{SWS_CM_00132}
  ara::core::Future<::UInt32> Get() {
    return field.Get();
  }

  /// @brief Mutable Field.
  /// @uptrace{SWS_CM_00133}
  using const_reference = UpdateRateField::const_reference;
  using MethodSet = ara::com::internal::proxy::Method<void(const_reference)>;
  MethodSet &Set;

};
/// @uptrace{SWS_CM_00008}
using UpdateRate = UpdateRateProxy<::UInt32>;
using FrontObjectDistanceField = ara::com::internal::proxy::Field<::UInt16>;
template <typename T, bool E2E = ara::com::internal::e2e::is_e2e_enabled<T>::value>
class FrontObjectDistanceProxy {
private:
  FrontObjectDistanceField& field;

public:
  explicit FrontObjectDistanceProxy(FrontObjectDistanceField& field_base)
      : field(field_base)
  { }

  // Event Base.
  void Subscribe(ara::com::EventCacheUpdatePolicy policy, std::size_t cacheSize) {
    field.Subscribe(policy, cacheSize);
  }
  
  bool IsSubscribed() const {
    return field.IsSubscribed();
  }

  void Unsubscribe() {
    return field.Unsubscribe();
  }

  void Cleanup() {
    field.Cleanup();
  }

  void SetReceiveHandler(ara::com::EventReceiveHandler handler) {
    field.SetReceiveHandler(handler);
  }

  void UnsetReceiveHandler() {
    field.UnsetReceiveHandler();
  }

  void SetSubscriptionStateChangeHandler(ara::com::SubscriptionStateChangeHandler handler) {
    field.SetSubscriptionStateChangeHandler(handler);
  }

  void UnsetSubscriptionStateChangeHandler() {
    field.UnsetSubscriptionStateChangeHandler();
  }

  using container_type = FrontObjectDistanceField::container_type;

  // Event.
  bool Update() {
    return field.Update();
  }

  bool Update(ara::com::FilterFunction<T> filter) {
    return field.Update(filter);
  }

  const container_type &GetCachedSamples() const {
    return field.GetCachedSamples();
  }

  template <typename U=T, typename = std::enable_if_t<E2E, U>>
  ara::com::e2exf::E2EResult GetE2EResult() const noexcept {
    return field.GetE2EResult();
  }

};
/// @uptrace{SWS_CM_00008}
using FrontObjectDistance = FrontObjectDistanceProxy<::UInt16>;
using RearObjectDistanceField = ara::com::internal::proxy::Field<::UInt16>;
template <typename T, bool E2E = ara::com::internal::e2e::is_e2e_enabled<T>::value>
class RearObjectDistanceProxy {
private:
  RearObjectDistanceField& field;

public:
  explicit RearObjectDistanceProxy(RearObjectDistanceField& field_base)
      : field(field_base)
  { }
  /// @brief Field.
  /// @uptrace{SWS_CM_00132}
  ara::core::Future<::UInt16> Get() {
    return field.Get();
  }

};
/// @uptrace{SWS_CM_00008}
using RearObjectDistance = RearObjectDistanceProxy<::UInt16>;
using ObjectDetectionLimitField = ara::com::internal::proxy::MutableField<::UInt16>;
template <typename T, bool E2E = ara::com::internal::e2e::is_e2e_enabled<T>::value>
class ObjectDetectionLimitProxy {
private:
  ObjectDetectionLimitField& field;

public:
  explicit ObjectDetectionLimitProxy(ObjectDetectionLimitField& field_base)
      : field(field_base)
      /// @uptrace{SWS_CM_00133}
      , Set(field_base.Set)
  { }
  /// @brief Mutable Field.
  /// @uptrace{SWS_CM_00133}
  using const_reference = ObjectDetectionLimitField::const_reference;
  using MethodSet = ara::com::internal::proxy::Method<void(const_reference)>;
  MethodSet &Set;

};
/// @uptrace{SWS_CM_00008}
using ObjectDetectionLimit = ObjectDetectionLimitProxy<::UInt16>;
} // namespace fields

namespace events {
  /// @uptrace{SWS_CM_00005}
  using brakeEvent = ara::com::internal::proxy::Event<::RadarObjects>;
  using parkingBrakeEvent = ara::com::internal::proxy::Event<::RadarObjects>;
  using driveEvent = ara::com::internal::proxy::Event<::RadarObjects>;
} // namespace events

class radarProxyBase : public ara::com::internal::proxy::ProxyBindingBase, public bosch::da::radar {
public:
  virtual methods::Adjust& GetAdjust() = 0;
  virtual methods::Calibrate& GetCalibrate() = 0;
  virtual fields::UpdateRateField& GetUpdateRate() = 0;
  virtual fields::FrontObjectDistanceField& GetFrontObjectDistance() = 0;
  virtual fields::RearObjectDistanceField& GetRearObjectDistance() = 0;
  virtual fields::ObjectDetectionLimitField& GetObjectDetectionLimit() = 0;
  virtual events::brakeEvent& GetbrakeEvent() = 0;
  virtual events::parkingBrakeEvent& GetparkingBrakeEvent() = 0;
  virtual events::driveEvent& GetdriveEvent() = 0;
};

/// @uptrace{SWS_CM_00004}
class radarProxy : public ara::com::internal::proxy::ProxyBase<radarProxyBase>, public bosch::da::radar {
private:
  fields::UpdateRateField& UpdateRateField;
  fields::FrontObjectDistanceField& FrontObjectDistanceField;
  fields::RearObjectDistanceField& RearObjectDistanceField;
  fields::ObjectDetectionLimitField& ObjectDetectionLimitField;

public:
  /// @brief Proxy constructor.
  ///
  /// @uptrace{SWS_CM_00131}
  explicit radarProxy(const HandleType& proxy_base_factory)
      : ara::com::internal::proxy::ProxyBase<radarProxyBase>(proxy_base_factory)
      , UpdateRateField(proxy_base_->GetUpdateRate())
      , FrontObjectDistanceField(proxy_base_->GetFrontObjectDistance())
      , RearObjectDistanceField(proxy_base_->GetRearObjectDistance())
      , ObjectDetectionLimitField(proxy_base_->GetObjectDetectionLimit())
      , Adjust(proxy_base_->GetAdjust())
      , Calibrate(proxy_base_->GetCalibrate())
      , UpdateRate(UpdateRateField)
      , FrontObjectDistance(FrontObjectDistanceField)
      , RearObjectDistance(RearObjectDistanceField)
      , ObjectDetectionLimit(ObjectDetectionLimitField)
      , brakeEvent(proxy_base_->GetbrakeEvent())
      , parkingBrakeEvent(proxy_base_->GetparkingBrakeEvent())
      , driveEvent(proxy_base_->GetdriveEvent())
  {}

  /// @brief Proxy shall be move constructable.
  ///
  /// @uptrace{SWS_CM_00137}
  explicit radarProxy(radarProxy&&) = default;

  /// @brief Proxy shall be move assignable.
  ///
  /// @uptrace{SWS_CM_00137}
  radarProxy& operator=(radarProxy&&) = default;

  /// @brief Proxy shall not be copy constructable.
  ///
  /// @uptrace{SWS_CM_00136}
  explicit radarProxy(const radarProxy&) = delete;

  /// @brief Proxy shall not be copy assignable.
  ///
  /// @uptrace{SWS_CM_00136}
  radarProxy& operator=(const radarProxy&) = delete;

  /// @uptrace{SWS_CM_00196}
  methods::Adjust& Adjust;
  methods::Calibrate& Calibrate;
  fields::UpdateRate UpdateRate;
  fields::FrontObjectDistance FrontObjectDistance;
  fields::RearObjectDistance RearObjectDistance;
  fields::ObjectDetectionLimit ObjectDetectionLimit;
  events::brakeEvent& brakeEvent;
  events::parkingBrakeEvent& parkingBrakeEvent;
  events::driveEvent& driveEvent;
};

} // namespace proxy
} // namespace da
} // namespace bosch

#endif // radar_fusion_extended_includes_bosch_da_radar_proxy_h

