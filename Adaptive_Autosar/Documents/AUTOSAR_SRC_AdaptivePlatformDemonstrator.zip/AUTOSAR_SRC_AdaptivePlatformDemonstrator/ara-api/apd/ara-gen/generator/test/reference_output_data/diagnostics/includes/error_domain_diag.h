// --------------------------------------------------------------------------
// |              _    _ _______     .----.      _____         _____        |
// |         /\  | |  | |__   __|  .  ____ .    / ____|  /\   |  __ \       |
// |        /  \ | |  | |  | |    .  / __ \ .  | (___   /  \  | |__) |      |
// |       / /\ \| |  | |  | |   .  / / / / v   \___ \ / /\ \ |  _  /       |
// |      / /__\ \ |__| |  | |   . / /_/ /  .   ____) / /__\ \| | \ \       |
// |     /________\____/   |_|   ^ \____/  .   |_____/________\_|  \_\      |
// |                              . _ _  .                                  |
// --------------------------------------------------------------------------
//
// All Rights Reserved.
// Any use of this source code is subject to a license agreement with the
// AUTOSAR development cooperation.
// More information is available at www.autosar.org.
//
// Disclaimer
//
// This work (specification and/or software implementation) and the material
// contained in it, as released by AUTOSAR, is for the purpose of information
// only. AUTOSAR and the companies that have contributed to it shall not be
// liable for any use of the work.
//
// The material contained in this work is protected by copyright and other
// types of intellectual property rights. The commercial exploitation of the
// material contained in this work requires a license to such intellectual
// property rights.
//
// This work may be utilized or reproduced without any modification, in any
// form or by any means, for informational purposes only. For any other
// purpose, no part of the work may be utilized or reproduced, in any form
// or by any means, without permission in writing from the publisher.
//
// The work has been developed for automotive applications only. It has
// neither been developed, nor tested for non-automotive applications.
//
// The word AUTOSAR and the AUTOSAR logo are registered trademarks.
// --------------------------------------------------------------------------

#ifndef diagnostics_includes_error_domain_diag_h
#define diagnostics_includes_error_domain_diag_h

#include "ara/core/error_code.h"
#include "ara/core/error_domain.h"
#include "ara/core/exception.h"

namespace ara {
namespace diag {


enum class DiagErrc : ara::core::ErrorDomain::CodeType
{
  kFailed = 3,
  kBusy = 5,
  kMemoryError = 6,
  kWrongDTC = 8,
  kWrongDTCOrigin = 9,
  kGeneralReject = 16,
  kServiceNotSupported = 17,
  kSubfunctionNotSupported = 18,
  kIncorrectMessageLengthOrInvalidFormat = 19,
  kResponseTooLong = 20,
  kBusyRepeatRequest = 33,
  kConditionsNotCorrect = 34,
  kRequestSequenceError = 36,
  kNoResponseFromSubnetComponent = 37,
  kFailurePreventsExecutionOfRequestedAction = 38,
  kRequestOutOfRange = 49,
  kSecurityAccessDenied = 51,
  kExceedNumberOfAttempts = 52,
  kRequiredTimeDelayNotExpired = 53,
  kUploadDownloadNotAccepted = 112,
  kTransferDataSuspended = 113,
  kGeneralProgrammingFailure = 114,
  kWrongBlockSequenceCounter = 115,
  kRequestCorrectlyReceivedResponsePending = 120,
  kSubfunctionNotSupportedInActiveSession = 126,
  kServiceNotSupportedInActiveSession = 127,
};

class DiagException : public ara::core::Exception
{
public:
    explicit DiagException(ara::core::ErrorCode err) noexcept
        : ara::core::Exception(err)
    {}
};

class DiagErrorDomain final : public ara::core::ErrorDomain
{
    constexpr static ara::core::ErrorDomain::IdType kId = 46;

public:
    using Errc = DiagErrc;

    using Exception = DiagException;

    /// @brief Default constructor
    ///
    /// @uptrace{SWS_CORE_00241}
    /// @uptrace{SWS_CORE_00012}
    constexpr DiagErrorDomain() noexcept
        : ara::core::ErrorDomain(kId)
    {}

    /// @brief Return the "shortname" ApApplicationErrorDomain.SN of this error domain.
    char const* Name() const noexcept override
    {
        return "Diag";
    }

    char const* Message(ara::core::ErrorDomain::CodeType errorCode) const noexcept override
    {
        Errc const code = static_cast<Errc>(errorCode);
        switch (code) {
        case Errc::kFailed:
            return "Message text for Failed is not defined";
        case Errc::kBusy:
            return "Message text for Busy is not defined";
        case Errc::kMemoryError:
            return "Message text for MemoryError is not defined";
        case Errc::kWrongDTC:
            return "Message text for WrongDTC is not defined";
        case Errc::kWrongDTCOrigin:
            return "Message text for WrongDTCOrigin is not defined";
        case Errc::kGeneralReject:
            return "Message text for GeneralReject is not defined";
        case Errc::kServiceNotSupported:
            return "Message text for ServiceNotSupported is not defined";
        case Errc::kSubfunctionNotSupported:
            return "Message text for SubfunctionNotSupported is not defined";
        case Errc::kIncorrectMessageLengthOrInvalidFormat:
            return "Message text for IncorrectMessageLengthOrInvalidFormat is not defined";
        case Errc::kResponseTooLong:
            return "Message text for ResponseTooLong is not defined";
        case Errc::kBusyRepeatRequest:
            return "Message text for BusyRepeatRequest is not defined";
        case Errc::kConditionsNotCorrect:
            return "Message text for ConditionsNotCorrect is not defined";
        case Errc::kRequestSequenceError:
            return "Message text for RequestSequenceError is not defined";
        case Errc::kNoResponseFromSubnetComponent:
            return "Message text for NoResponseFromSubnetComponent is not defined";
        case Errc::kFailurePreventsExecutionOfRequestedAction:
            return "Message text for FailurePreventsExecutionOfRequestedAction is not defined";
        case Errc::kRequestOutOfRange:
            return "Message text for RequestOutOfRange is not defined";
        case Errc::kSecurityAccessDenied:
            return "Message text for SecurityAccessDenied is not defined";
        case Errc::kExceedNumberOfAttempts:
            return "Message text for ExceedNumberOfAttempts is not defined";
        case Errc::kRequiredTimeDelayNotExpired:
            return "Message text for RequiredTimeDelayNotExpired is not defined";
        case Errc::kUploadDownloadNotAccepted:
            return "Message text for UploadDownloadNotAccepted is not defined";
        case Errc::kTransferDataSuspended:
            return "Message text for TransferDataSuspended is not defined";
        case Errc::kGeneralProgrammingFailure:
            return "Message text for GeneralProgrammingFailure is not defined";
        case Errc::kWrongBlockSequenceCounter:
            return "Message text for WrongBlockSequenceCounter is not defined";
        case Errc::kRequestCorrectlyReceivedResponsePending:
            return "Message text for RequestCorrectlyReceivedResponsePending is not defined";
        case Errc::kSubfunctionNotSupportedInActiveSession:
            return "Message text for SubfunctionNotSupportedInActiveSession is not defined";
        case Errc::kServiceNotSupportedInActiveSession:
            return "Message text for ServiceNotSupportedInActiveSession is not defined";
        default:
            return "Unknown error";
        }
    }

    void ThrowAsException(ara::core::ErrorCode const& errorCode) const noexcept(false) override
    {
        ara::core::ThrowOrTerminate<Exception>(errorCode);
    }
};

namespace internal
{
constexpr DiagErrorDomain g_DiagErrorDomain;
}

inline constexpr ara::core::ErrorDomain const& GetDiagErrorDomain() noexcept
{
    return internal::g_DiagErrorDomain;
}

inline constexpr ara::core::ErrorCode MakeErrorCode(DiagErrc code,
    ara::core::ErrorDomain::SupportDataType data) noexcept
{
    return ara::core::ErrorCode(static_cast<ara::core::ErrorDomain::CodeType>(code), GetDiagErrorDomain(), data);
}

} // namespace diag
} // namespace ara

#endif // diagnostics_includes_error_domain_diag_h

