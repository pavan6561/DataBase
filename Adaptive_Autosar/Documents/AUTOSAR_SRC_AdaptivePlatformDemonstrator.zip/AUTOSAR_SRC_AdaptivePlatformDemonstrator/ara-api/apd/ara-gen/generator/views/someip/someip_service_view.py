#  --------------------------------------------------------------------------
#  |              _    _ _______     .----.      _____         _____        |
#  |         /\  | |  | |__   __|  .  ____ .    / ____|  /\   |  __ \       |
#  |        /  \ | |  | |  | |    .  / __ \ .  | (___   /  \  | |__) |      |
#  |       / /\ \| |  | |  | |   .  / / / / v   \___ \ / /\ \ |  _  /       |
#  |      / /__\ \ |__| |  | |   . / /_/ /  .   ____) / /__\ \| | \ \       |
#  |     /________\____/   |_|   ^ \____/  .   |_____/________\_|  \_\      |
#  |                              . _ _  .                                  |
#  --------------------------------------------------------------------------
#
#  All Rights Reserved.
#  Any use of this source code is subject to a license agreement with the
#  AUTOSAR development cooperation.
#  More information is available at www.autosar.org.
#
#  Disclaimer
#
#  This work (specification and/or software implementation) and the material
#  contained in it, as released by AUTOSAR, is for the purpose of information
#  only. AUTOSAR and the companies that have contributed to it shall not be
#  liable for any use of the work.
#
#  The material contained in this work is protected by copyright and other
#  types of intellectual property rights. The commercial exploitation of the
#  material contained in this work requires a license to such intellectual
#  property rights.
#
#  This work may be utilized or reproduced without any modification, in any
#  form or by any means, for informational purposes only. For any other
#  purpose, no part of the work may be utilized or reproduced, in any form
#  or by any means, without permission in writing from the publisher.
#
#  The work has been developed for automotive applications only. It has
#  neither been developed, nor tested for non-automotive applications.
#
#  The word AUTOSAR and the AUTOSAR logo are registered trademarks.
#  --------------------------------------------------------------------------

"""
ServiceView corresponding to a Service IM object.
"""
import os
import hashlib

from generator.intermediate_model.communication_management.service \
    import Service
from generator.views.service_view import ServiceView
from generator.views.someip.event_group_view import EventGroupView
from generator.views.someip.event_view import EventView
from generator.views.someip.field_view import FieldView
from generator.views.someip.method_view import MethodView


class SomeIpServiceView(ServiceView):
    """Specialized View of a Service."""

    # To be able to generate all templates we need >20 public methods in ServiceView.
    # pylint: disable=R0904
    # - Too many public methods

    def __init__(self, service: Service) -> None:
        super().__init__(service)

    def __eq__(self, other):
        if type(other) is SomeIpServiceView:
            return self.fqn == other.fqn
        return False

    def __lt__(self, other):
        return self.qualified_cpp_name.lower() < other.qualified_cpp_name.lower()

    def __hash__(self):
        return hash(self.fqn)

    @property
    def service_id(self):
        fqn = self.fqn
        hash_algo = hashlib.new('sha1')
        hash_algo.update(fqn.encode('UTF-8'))
        result = 0
        digest = bytearray(hash_algo.digest())
        for i in digest[0:2]:
            result = result * 256 + int(i)
        return hex(result)

    @property
    def ports(self):
        """Get the service port"""
        return self._service.service_deployment.ports

    @property
    def events(self):
        """Get the events as EventViews for this service"""
        event_views = list()
        for event in self._service.events:
            event_views.append(EventView(event))
        return event_views

    def get_events_from_group(self, event_group: EventGroupView):
        """Get all the events in this event group"""
        event_ids = event_group.events
        event_views = self.events
        filtered = list()
        for event in event_views:
            if event.deployment_id in event_ids:
                filtered.append(event)

        return filtered

    @property
    def methods(self):
        """Get the methods as MethodViews for this service"""
        method_views = list()
        for method in self._service.methods:
            method_views.append(MethodView(method))
        return method_views

    @property
    def all_fields(self):
        """Get the fields as FieldViews for this service"""
        field_views = list()
        for field in self._service.fields:
            field_views.append(FieldView(field))

        return field_views

    @property
    def fields_with_notifier(self):
        """Get the fields with notifying events as FieldViews for this service"""
        field_views = list()
        for field in self._service.fields:
            if field.has_notifier:
                field_views.append(FieldView(field))

        field_views.sort(key=lambda field: field.name)
        return field_views

    def get_field_event_group(self, field: FieldView):
        """Get the field's event group if available"""
        if field.has_notifier:
            for event_group in self._service.service_deployment.event_groups:
                if int(field.event_id, 16) in event_group.events:
                    return hex(event_group.event_group_id)
            raise ValueError("Event '{}' ({}) does not belong to any EVENT-GROUP".format(field.name, field.event_id))
        else:
            return None

    @property
    def event_groups(self):
        """Get the eventgroups for the service"""
        event_group_views = list()
        for event_group in self._service.service_deployment.event_groups:
            event_group_views.append(EventGroupView(event_group))
        return event_group_views
