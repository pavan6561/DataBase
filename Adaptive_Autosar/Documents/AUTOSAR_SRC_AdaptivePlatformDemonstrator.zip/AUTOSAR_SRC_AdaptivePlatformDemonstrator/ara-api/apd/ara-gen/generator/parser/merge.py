#  --------------------------------------------------------------------------
#  |              _    _ _______     .----.      _____         _____        |
#  |         /\  | |  | |__   __|  .  ____ .    / ____|  /\   |  __ \       |
#  |        /  \ | |  | |  | |    .  / __ \ .  | (___   /  \  | |__) |      |
#  |       / /\ \| |  | |  | |   .  / / / / v   \___ \ / /\ \ |  _  /       |
#  |      / /__\ \ |__| |  | |   . / /_/ /  .   ____) / /__\ \| | \ \       |
#  |     /________\____/   |_|   ^ \____/  .   |_____/________\_|  \_\      |
#  |                              . _ _  .                                  |
#  --------------------------------------------------------------------------
#
#  All Rights Reserved.
#  Any use of this source code is subject to a license agreement with the
#  AUTOSAR development cooperation.
#  More information is available at www.autosar.org.
#
#  Disclaimer
#
#  This work (specification and/or software implementation) and the material
#  contained in it, as released by AUTOSAR, is for the purpose of information
#  only. AUTOSAR and the companies that have contributed to it shall not be
#  liable for any use of the work.
#
#  The material contained in this work is protected by copyright and other
#  types of intellectual property rights. The commercial exploitation of the
#  material contained in this work requires a license to such intellectual
#  property rights.
#
#  This work may be utilized or reproduced without any modification, in any
#  form or by any means, for informational purposes only. For any other
#  purpose, no part of the work may be utilized or reproduced, in any form
#  or by any means, without permission in writing from the publisher.
#
#  The work has been developed for automotive applications only. It has
#  neither been developed, nor tested for non-automotive applications.
#
#  The word AUTOSAR and the AUTOSAR logo are registered trademarks.
#  --------------------------------------------------------------------------



"""
Splitable merger module.
"""

import sys
import logging

from collections import OrderedDict as odict

import lxml.etree as et

import generator.parser
from generator.parser.tree_helper import get_schema_file_from_tree

NSMAP = {None: generator.parser.AR_NAMESPACE_URI}
IS_SPLITTABLE_SET = set()


def indent(elem, level=0):
    """Create indent according to the level."""
    i = "\n" + level * "  "
    if elem.getchildren():
        if not elem.text or not elem.text.strip():
            elem.text = i + "  "
        if not elem.tail or not elem.tail.strip():
            elem.tail = i
        for elt in elem:
            indent(elt, level + 1)
        if not elem.tail or not elem.tail.strip():
            elem.tail = i
    else:
        if level and (not elem.tail or not elem.tail.strip()):
            elem.tail = i


def short_tag(elt):
    """Extract the tag name ignoring namespace"""
    if elt.tag.startswith('{'):
        return elt.tag[elt.tag.rfind('}')+1:]
    return elt.tag


def merge(*trees):
    """Merge multiple XML trees."""
    first_root = trees[0].getroot()
    merged_root = et.Element(first_root.tag, nsmap=NSMAP)
    add_attributes(merged_root, first_root)
    tree = et.ElementTree(merged_root)
    features = [feature for a in trees for feature in
                a.getroot().getchildren()]
    feature_merge(tree.getroot(), features)
    indent(tree.getroot())
    return tree


def feature_key(feature):
    """
    Features are merged based on their tag.
    E.g. AR-PACKAGE/ELEMENTS is merged with a corresponding AR-PACKAGE/ELEMENTS.
    """
    return feature.tag


def merged_values(split_features):
    """
    Compute merged feature values.
    :param split_features: the split features of the same element.
    :return: merged feature values.
    """
    result = []
    for fragment in split_features:
        result += fragment.getchildren()
    return result


def merge_feature(parent, to_merge):
    """Merge the to_merge feature values of parent."""
    merged = et.SubElement(parent, to_merge[0].tag)
    values = merged_values(to_merge)
    if values:
        value_merge(merged, values)
    else:
        merged.text = to_merge[0].text
        add_attributes(merged, to_merge[0])


def feature_merge(parent, features):
    """Merge the features of parent."""
    if not features:
        return
    features.sort(key=feature_key)
    key = feature_key(features[0])
    to_merge = [features[0]]
    for feature in features[1:]:
        if key not in IS_SPLITTABLE_SET:
            merge_feature(parent, to_merge)
            to_merge = [feature]
            key = feature_key(feature)

        elif key == feature_key(feature):
            to_merge.append(feature)
        else:
            merge_feature(parent, to_merge)
            to_merge = [feature]
            key = feature_key(feature)
    merge_feature(parent, to_merge)


def split_key(element):
    """Get the atp.SplitKey of value"""
    sk_child = split_key_child(element)
    if sk_child is None:
        return []
    return sk_child.text


def split_key_child(element):
    """Return the atp.SplitKey-holding child of element."""
    # Assumes the atp.SplitKey is just one of the features (e.g. SHORT-NAME).
    # To be extended in the future for the multi-feature atp.SplitKey case.
    for child in element.getchildren():
        if generator.parser.SPLIT_KEY == short_tag(child):
            return child
    return None


def value_key(value):
    """Value-key pair."""
    skey = split_key(value)
    if skey:
        return tuple([value.tag, skey])
    return tuple([to_string(value)])


def merged_features(split_values):
    """Merge features from split fragments."""
    result = []
    for fragment in split_values:
        result += filter(lambda x: short_tag(x) != generator.parser.SPLIT_KEY, fragment.getchildren())
    return result


def add_attributes(dest, src):
    """Add attributes from src to dest"""
    for key, value in src.attrib.items():
        dest.set(key, value)


def merge_node(parent, to_merge):
    """Merge to_merge child of parent feature."""
    merged = et.SubElement(parent, to_merge[0].tag)
    merged.text = ''
    add_attributes(merged, to_merge[0])
    if not to_merge[0].getchildren():
        if to_merge[0].text:
            merged.text += to_merge[0].text
    short_name_to_set = split_key_child(to_merge[0])
    if short_name_to_set is not None:
        merged.append(short_name_to_set)
    feature_merge(merged, merged_features(to_merge))


def value_merge(parent, values):
    """Merge fragments of parent feature."""
    if not values:
        return
    value_bins = odict()
    for value in values:
        key = value_key(value)
        if key not in value_bins:
            value_bins[key] = [value]
        else:
            value_bins[key].append(value)
    for key, value_bin in value_bins.items():
        merge_node(parent, value_bin)


def merge_files(file_names, parser=None, as_string=False):
    """
    Merge multiple files, if schema_loc is not given a default
    choice of splitables is used."""
    log = logging.getLogger(__name__)

    if not parser:
        log.debug("No parser was given to merge input files! Default parser will be created")
        parser = et.XMLParser(remove_blank_text=True, remove_comments=True)

    trees = [et.parse(arg, parser) for arg in file_names]
    if len(trees) == 1:
        tree = trees[0]
        return tree

    schema_loc = None
    for tree in trees:
        schema = get_schema_file_from_tree(tree)
        if schema_loc is None:
            schema_loc = schema
        elif schema_loc != schema:
            sys.exit("XML validation failed! Files use different schemas.")

    if schema_loc:
        log.debug("Schema %s will be used to populate splittable map", schema_loc)
        populate_splitables_map(schema_loc)

    tree = merge(*trees)
    return to_string(tree) if as_string else tree


def populate_splitables_map(schema_loc):
    """
    Populate the map of what features are splittable, all features are
    considered splittable without it.
    """

    data = et.parse(open(schema_loc))
    root = data.getroot()

    features = root.findall("{http://www.w3.org/2001/XMLSchema}group")

    for feature in features:
        seq = feature.find(".//{http://www.w3.org/2001/XMLSchema}sequence")
        if seq is not None:
            for elem in seq.getchildren():
                app_infos = elem.findall(".//{http://www.w3.org/2001/XMLSchema}appinfo")

                name = elem.get("name")

                if name and _is_splittable(app_infos):
                    IS_SPLITTABLE_SET.add(generator.parser.AR_NAMESPACE + name)


def _is_splittable(app_infos):
    for app_info in app_infos:
        if app_info.text == "atpSplitable":
            return True
    return False


def to_string(element_or_elementtree):
    """Return an actual string."""
    # et.tostring returns bytes, because reasons :)
    return et.tostring(element_or_elementtree, encoding=generator.parser.TEXT_ENCODING)\
        .decode(generator.parser.TEXT_ENCODING)


def usage():
    """Return string with usage help."""
    return "{} <arxml_files>".format(sys.argv[0])


def main():
    """Entry point."""
    if len(sys.argv) < 2:
        print(usage())
        exit(42)
    tree = merge_files(sys.argv[1:])
    print(to_string(tree), end='')


if __name__ == "__main__":
    main()
