// --------------------------------------------------------------------------
// |              _    _ _______     .----.      _____         _____        |
// |         /\  | |  | |__   __|  .  ____ .    / ____|  /\   |  __ \       |
// |        /  \ | |  | |  | |    .  / __ \ .  | (___   /  \  | |__) |      |
// |       / /\ \| |  | |  | |   .  / / / / v   \___ \ / /\ \ |  _  /       |
// |      / /__\ \ |__| |  | |   . / /_/ /  .   ____) / /__\ \| | \ \       |
// |     /________\____/   |_|   ^ \____/  .   |_____/________\_|  \_\      |
// |                              . _ _  .                                  |
// --------------------------------------------------------------------------
//
// All Rights Reserved.
// Any use of this source code is subject to a license agreement with the
// AUTOSAR development cooperation.
// More information is available at www.autosar.org.
//
// Disclaimer
//
// This work (specification and/or software implementation) and the material
// contained in it, as released by AUTOSAR, is for the purpose of information
// only. AUTOSAR and the companies that have contributed to it shall not be
// liable for any use of the work.
//
// The material contained in this work is protected by copyright and other
// types of intellectual property rights. The commercial exploitation of the
// material contained in this work requires a license to such intellectual
// property rights.
//
// This work may be utilized or reproduced without any modification, in any
// form or by any means, for informational purposes only. For any other
// purpose, no part of the work may be utilized or reproduced, in any form
// or by any means, without permission in writing from the publisher.
//
// The work has been developed for automotive applications only. It has
// neither been developed, nor tested for non-automotive applications.
//
// The word AUTOSAR and the AUTOSAR logo are registered trademarks.
// --------------------------------------------------------------------------

#ifndef radar_fusion_execution_manifest_includes_error_domain_specificerrors_h
#define radar_fusion_execution_manifest_includes_error_domain_specificerrors_h

#include "ara/core/error_code.h"
#include "ara/core/error_domain.h"
#include "ara/core/exception.h"

namespace ara {
namespace com {
namespace sample {


enum class SpecificErrorsErrc : ara::core::ErrorDomain::CodeType
{
  kInvalidConfigString = 5, ///< Configuration string is invalid.
  kInvalidParameter = 6, ///< Parameter is invalid.
};

class SpecificErrorsException : public ara::core::Exception
{
public:
    explicit SpecificErrorsException(ara::core::ErrorCode err) noexcept
        : ara::core::Exception(err)
    {}
};

class SpecificErrorsErrorDomain final : public ara::core::ErrorDomain
{
    constexpr static ara::core::ErrorDomain::IdType kId = 44;

public:
    using Errc = SpecificErrorsErrc;

    using Exception = SpecificErrorsException;

    /// @brief Default constructor
    ///
    /// @uptrace{SWS_CORE_00241}
    /// @uptrace{SWS_CORE_00012}
    constexpr SpecificErrorsErrorDomain() noexcept
        : ara::core::ErrorDomain(kId)
    {}

    /// @brief Return the "shortname" ApApplicationErrorDomain.SN of this error domain.
    char const* Name() const noexcept override
    {
        return "SpecificErrors";
    }

    char const* Message(ara::core::ErrorDomain::CodeType errorCode) const noexcept override
    {
        Errc const code = static_cast<Errc>(errorCode);
        switch (code) {
        case Errc::kInvalidConfigString:
            return "Configuration string is invalid.";
        case Errc::kInvalidParameter:
            return "Parameter is invalid.";
        default:
            return "Unknown error";
        }
    }

    void ThrowAsException(ara::core::ErrorCode const& errorCode) const noexcept(false) override
    {
        ara::core::ThrowOrTerminate<Exception>(errorCode);
    }
};

namespace internal
{
constexpr SpecificErrorsErrorDomain g_SpecificErrorsErrorDomain;
}

inline constexpr ara::core::ErrorDomain const& GetSpecificErrorsErrorDomain() noexcept
{
    return internal::g_SpecificErrorsErrorDomain;
}

inline constexpr ara::core::ErrorCode MakeErrorCode(SpecificErrorsErrc code,
    ara::core::ErrorDomain::SupportDataType data) noexcept
{
    return ara::core::ErrorCode(static_cast<ara::core::ErrorDomain::CodeType>(code), GetSpecificErrorsErrorDomain(), data);
}

} // namespace sample
} // namespace com
} // namespace ara

#endif // radar_fusion_execution_manifest_includes_error_domain_specificerrors_h

