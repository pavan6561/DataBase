// --------------------------------------------------------------------------
// |              _    _ _______     .----.      _____         _____        |
// |         /\  | |  | |__   __|  .  ____ .    / ____|  /\   |  __ \       |
// |        /  \ | |  | |  | |    .  / __ \ .  | (___   /  \  | |__) |      |
// |       / /\ \| |  | |  | |   .  / / / / v   \___ \ / /\ \ |  _  /       |
// |      / /__\ \ |__| |  | |   . / /_/ /  .   ____) / /__\ \| | \ \       |
// |     /________\____/   |_|   ^ \____/  .   |_____/________\_|  \_\      |
// |                              . _ _  .                                  |
// --------------------------------------------------------------------------
//
// All Rights Reserved.
// Any use of this source code is subject to a license agreement with the
// AUTOSAR development cooperation.
// More information is available at www.autosar.org.
//
// Disclaimer
//
// This work (specification and/or software implementation) and the material
// contained in it, as released by AUTOSAR, is for the purpose of information
// only. AUTOSAR and the companies that have contributed to it shall not be
// liable for any use of the work.
//
// The material contained in this work is protected by copyright and other
// types of intellectual property rights. The commercial exploitation of the
// material contained in this work requires a license to such intellectual
// property rights.
//
// This work may be utilized or reproduced without any modification, in any
// form or by any means, for informational purposes only. For any other
// purpose, no part of the work may be utilized or reproduced, in any form
// or by any means, without permission in writing from the publisher.
//
// The work has been developed for automotive applications only. It has
// neither been developed, nor tested for non-automotive applications.
//
// The word AUTOSAR and the AUTOSAR logo are registered trademarks.
// --------------------------------------------------------------------------

#ifndef map_sample_includes_ara_gen_map_skeleton_h
#define map_sample_includes_ara_gen_map_skeleton_h

#include "ara/com/internal/skeleton/ara_skeleton_base.h"

#include "ara/com/illegal_state_exception.h"
#include "map_common.h"

namespace ara {
namespace gen {
namespace skeleton {

namespace fields {
  /// @uptrace{SWS_CM_00007}
  using SimpleMap = ara::com::internal::skeleton::FieldDispatcher<::ara::diag::datatypes::MetaInfoTypeInt>;
  using FullMap = ara::com::internal::skeleton::FieldDispatcher<::ara::diag::datatypes::MetaInfoType>;
} // namespace fields


/// @uptrace{SWS_CM_00002}
class mapSkeleton : public ara::gen::map, public ara::com::internal::skeleton::TypedServiceImplBase<mapSkeleton> {
public:
  /// @uptrace{SWS_CM_00130}
  mapSkeleton(ara::com::InstanceIdentifier instance_id, ara::com::MethodCallProcessingMode mode = ara::com::MethodCallProcessingMode::kEvent) : ara::com::internal::skeleton::TypedServiceImplBase<mapSkeleton>(instance_id, mode) {}
  virtual ~mapSkeleton() {
    StopOfferService();
  }

  /// @brief Skeleton shall be move constructable.
  ///
  /// @uptrace{SWS_CM_00135}
  explicit mapSkeleton(mapSkeleton&&) = default;

  /// @brief Skeleton shall be move assignable.
  ///
  /// @uptrace{SWS_CM_00135}
  mapSkeleton& operator=(mapSkeleton&&) = default;

  /// @brief Skeleton shall not be copy constructable.
  ///
  /// @uptrace{SWS_CM_00134}
  explicit mapSkeleton(const mapSkeleton&) = delete;

  /// @brief Skeleton shall not be copy assignable.
  ///
  /// @uptrace{SWS_CM_00134}
  mapSkeleton& operator=(const mapSkeleton&) = delete;

  void OfferService() {
    if(!SimpleMap.IsInitialized()) {
      throw ara::com::IllegalStateException("Attempt to offer service \"/ara/gen/map\" with uninitialized field \"SimpleMap\"");
    }
    if(!FullMap.IsInitialized()) {
      throw ara::com::IllegalStateException("Attempt to offer service \"/ara/gen/map\" with uninitialized field \"FullMap\"");
    }

    ara::com::internal::skeleton::TypedServiceImplBase<mapSkeleton>::OfferService();
  }

  fields::SimpleMap SimpleMap;
  fields::FullMap FullMap;
};

} // namespace skeleton
} // namespace gen
} // namespace ara

#endif // map_sample_includes_ara_gen_map_skeleton_h

