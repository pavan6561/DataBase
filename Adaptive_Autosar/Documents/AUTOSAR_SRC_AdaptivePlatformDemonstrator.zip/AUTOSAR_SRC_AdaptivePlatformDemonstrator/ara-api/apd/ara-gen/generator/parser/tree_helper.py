#  --------------------------------------------------------------------------
#  |              _    _ _______     .----.      _____         _____        |
#  |         /\  | |  | |__   __|  .  ____ .    / ____|  /\   |  __ \       |
#  |        /  \ | |  | |  | |    .  / __ \ .  | (___   /  \  | |__) |      |
#  |       / /\ \| |  | |  | |   .  / / / / v   \___ \ / /\ \ |  _  /       |
#  |      / /__\ \ |__| |  | |   . / /_/ /  .   ____) / /__\ \| | \ \       |
#  |     /________\____/   |_|   ^ \____/  .   |_____/________\_|  \_\      |
#  |                              . _ _  .                                  |
#  --------------------------------------------------------------------------
#
#  All Rights Reserved.
#  Any use of this source code is subject to a license agreement with the
#  AUTOSAR development cooperation.
#  More information is available at www.autosar.org.
#
#  Disclaimer
#
#  This work (specification and/or software implementation) and the material
#  contained in it, as released by AUTOSAR, is for the purpose of information
#  only. AUTOSAR and the companies that have contributed to it shall not be
#  liable for any use of the work.
#
#  The material contained in this work is protected by copyright and other
#  types of intellectual property rights. The commercial exploitation of the
#  material contained in this work requires a license to such intellectual
#  property rights.
#
#  This work may be utilized or reproduced without any modification, in any
#  form or by any means, for informational purposes only. For any other
#  purpose, no part of the work may be utilized or reproduced, in any form
#  or by any means, without permission in writing from the publisher.
#
#  The work has been developed for automotive applications only. It has
#  neither been developed, nor tested for non-automotive applications.
#
#  The word AUTOSAR and the AUTOSAR logo are registered trademarks.
#  --------------------------------------------------------------------------

import os
import sys

# pylint: disable=too-many-lines,too-many-public-methods
from generator.parser.exception_handling import handle_exceptions
from generator.parser.autosar_mapping import PathError

def get_schema_from_tree(tree):
    schema_locations = list(tree.xpath("//*/@xsi:schemaLocation", namespaces={'xsi': "http://www.w3.org/2001/XMLSchema-instance"}))
    if len(schema_locations) == 0:
        raise AttributeError("XML validation failed! No schema defined.")
    if len(schema_locations) > 1:
        raise ValueError("XML validation failed! Multiple schemas defined.")

    schema_location_split = schema_locations[0].split()
    if len(schema_location_split) != 2:
        raise ValueError("XML validation failed! Invalid schemaLocation syntax.")
    return schema_location_split[1]

def get_schema_file_from_tree(tree, check_availability=True):
    file_name = get_schema_from_tree(tree)
    file_directory = os.path.dirname(os.path.realpath(__file__))
    schema_file = os.path.join(file_directory,
                               "schema",
                               file_name)
    if check_availability and not os.path.isfile(schema_file):
        raise ValueError("XML validation failed! The schema {0} is not supported.".format(file_name))
    return schema_file

def get_element(from_where, path):
    ns_mapping = {'AR': 'http://autosar.org/schema/r4.0'}
    p = ".//AR:" + path.replace("/", "/AR:")
    result = from_where.find(p, ns_mapping)
    if hasattr(result, '_setText'):
        result._setText(result.text.strip())
    return result

@handle_exceptions(
    error_string_template="ARXML element fetching ERROR: '{arguments[1]}' must exist " +
    "for '{arguments[0]}'")
def get_element_or_die(from_where, path):
    result = get_element(from_where, path)
    if result is None:
        raise PathError("Unable to get element {} from {}".format(path, from_where))
    return result

def get_element_or_none(from_where, path):
    try:
        return get_element(from_where, path)
    except Exception:
        return None

def short_name(fqn):
    """Get short name of fully qualified name"""
    return str(fqn).split('/')[-1]

def to_list(x):
    return x if x is not None else []

def to_str(x):
    return x.text if x else ""

def to_nanoseconds(ar_value):
    result = None
    if ar_value:
        try:
            result = int(round(float(ar_value.text) * 1000000000))
        except:
            result = None

    return result

def to_milliseconds(ar_value):
    result = None
    if ar_value:
        try:
            result = int(round(float(ar_value.text) * 1000))
        except:
            result = None

    return result
