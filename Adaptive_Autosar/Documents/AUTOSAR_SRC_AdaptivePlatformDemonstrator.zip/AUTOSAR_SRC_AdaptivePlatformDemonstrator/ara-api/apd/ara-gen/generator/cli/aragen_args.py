#  --------------------------------------------------------------------------
#  |              _    _ _______     .----.      _____         _____        |
#  |         /\  | |  | |__   __|  .  ____ .    / ____|  /\   |  __ \       |
#  |        /  \ | |  | |  | |    .  / __ \ .  | (___   /  \  | |__) |      |
#  |       / /\ \| |  | |  | |   .  / / / / v   \___ \ / /\ \ |  _  /       |
#  |      / /__\ \ |__| |  | |   . / /_/ /  .   ____) / /__\ \| | \ \       |
#  |     /________\____/   |_|   ^ \____/  .   |_____/________\_|  \_\      |
#  |                              . _ _  .                                  |
#  --------------------------------------------------------------------------
#
#  All Rights Reserved.
#  Any use of this source code is subject to a license agreement with the
#  AUTOSAR development cooperation.
#  More information is available at www.autosar.org.
#
#  Disclaimer
#
#  This work (specification and/or software implementation) and the material
#  contained in it, as released by AUTOSAR, is for the purpose of information
#  only. AUTOSAR and the companies that have contributed to it shall not be
#  liable for any use of the work.
#
#  The material contained in this work is protected by copyright and other
#  types of intellectual property rights. The commercial exploitation of the
#  material contained in this work requires a license to such intellectual
#  property rights.
#
#  This work may be utilized or reproduced without any modification, in any
#  form or by any means, for informational purposes only. For any other
#  purpose, no part of the work may be utilized or reproduced, in any form
#  or by any means, without permission in writing from the publisher.
#
#  The work has been developed for automotive applications only. It has
#  neither been developed, nor tested for non-automotive applications.
#
#  The word AUTOSAR and the AUTOSAR logo are registered trademarks.
#  --------------------------------------------------------------------------

"""
Setup an argument parser for aragen based on the information present in
doc/README.md
"""


__version__ = "0.1.0"

import argparse
import json
import logging
from generator.cli.default_config import load_default_config_values
from generator.parser.parser import Parser

EPILOG = r'''
Examples
--------
    aragen           \
        --output output \
        /path/to/arxmls/

This command would generate the code in a folder 'output' under the current
directory. It would generate PROLOC, SOME/IP, ROS, and User Defined bindings
if they are all present in the system.
'''

# Supported generators. First entry is the default
GENERATORS = ["ALL", "CONFIG", "CODE", "EM_CONFIG"]

POSSIBLE_SOMEIP_LIBS = ["vsomeip", "none"]
DEFAULT_SOMEIP_LIB = "vsomeip"
POSSIBLE_DDS_LIBS = ["opendds", "none"]
DEFAULT_DDS_LIB = "none"
POSSIBLE_USERDEF_LIBS =  ["vsomeip", "none"]
DEFAULT_USERDEF_LIB = "none"



def config_load(config):
    """
    When loading a configuration we need to know whether it is a file or inline
    JSON string.
    :param config: path to JSON configuration or inline JSON string
    :return: dictionary representation of the config
    """
    if ".json" in config:
        with open(config, "r") as config_file:
            return json.load(config_file)
    else:
        return json.loads(config)


class CsvChoices(object):
    """
    Allow a csv list to be passed and cross referenced with a limited set of
    choices.
    """
    def __init__(self, name, choices, none_value=None):
        """
        :param choices: list of possible choices
        """
        self.name = name
        self.choices = choices
        self.none_value = none_value

    def __call__(self, csv):
        """
        Splits the CSV list in to a regular python list. Note that csv must
        always contain at least one element. In the ArgumentParser there is
        always a default value associated with this type, for example.
        :param csv: comma separated list of choices
        :return: list of choices made
        """
        split = [item for item in csv.split(',')]
        invalid_choices = set(split) - set(self.choices)
        if invalid_choices:
            raise argparse.ArgumentError(
                argument=None,
                message="In {name}: {items} {isare} not valid".format(
                    name=self.name,
                    items=','.join(invalid_choices),
                    isare="is" if len(invalid_choices) == 1 else "are"))

        result = list(set(split))
        if self.none_value in result:
            # and "none" is the only item in list
            if len(result) == 1:
                result = []
            else:
                raise argparse.ArgumentError(
                    argument=None,
                    message="In {name}: either of comma separatet list or '{nv}', not both".format(
                        name=self.name,
                        nv=self.none_value))

        return result


class AragenArgs(object):
    """
    Allow to store the Aragen Args, do checks and run the corresponding
    flags.
    """
    def __init__(self, argv):
        """
        Build the argument parser and return the parsed command line
        """
        self._log = logging.getLogger(__name__)

        arg_parser = argparse.ArgumentParser(
            description="",
            epilog=EPILOG,
            formatter_class=argparse.RawTextHelpFormatter)

        # Flags

        arg_parser.add_argument(
            "-v",
            "--verbose",
            action="count",
            default=0,
            help="Increase verbosity of logging (can give multiple times)")

        arg_parser.add_argument(
            "-q",
            "--quiet",
            action="store_true",
            help="Suppress all logging output to console (overrides --verbose)")

        arg_parser.add_argument(
            "-d",
            "--debug",
            action="store_true",
            help="Specify detailed logging configuration")

        arg_parser.add_argument(
            "--list-files",
            action="store_true",
            help="Print (to stdout) the file paths (relative to the argument of -o)\n"
                 "that would be generated, but do not generate anything")

        arg_parser.add_argument(
            "--list-machines",
            action="store_true",
            help="List the names of all machines defined in the input files and exit")

        arg_parser.add_argument(
            "--list-applications",
            action="store_true",
            help="List the names of all Adaptive Applications defined in input files and exit")

        # arg_parser.add_argument(
        #     "--dump-config",
        #     action="store_true",
        #     help="Dump the configuration of the key-value pairs used by the\n"
        #          "generator and exit. Can be used to create an \n"
        #          "extendable/overwritable config file for the -c argument.")

        arg_parser.add_argument(
            "-n",
            "--dry-run",
            action="store_true",
            help="Runs the generator in dry-run mode, i.e. run all the way\n"
                 "through without actually generating anything")

        arg_parser.add_argument(
            "--version",
            action="version",
            version="%(prog)s {}".format(__version__),
            help="List versions of the generator components and exit")

        # Arguments

        # arg_parser.add_argument(
        #     "-c",
        #     "--config",
        #     type=config_load,
        #     help="Path to a config JSON file which denotes further\n"
        #          "arguments or custom arguments to the generator. The file\n"
        #          "should be key-value JSON format like:\n"
        #          "    {\n"
        #          """        "key": "value",\n"""
        #          """        "key2": "value2",\n"""
        #          "    }\n"
        #          "\n"
        #          "The config JSON can also be defined inlined like this:\n"
        #          """    python aragen.py -c {"key":"value", "key2": "value2"}""")

        arg_parser.add_argument(
            "-g",
            "--generate",
            default=GENERATORS[0],
            type=CsvChoices(name="generate", choices=GENERATORS),
            help="What to generate. Options are {generators}; default is {default}".format(generators=",".
                                                                                           join(GENERATORS),
                                                                                           default=GENERATORS[0]))

        arg_parser.add_argument(
            "-l",
            "--log",
            help="Write all log data to the specified file")

        arg_parser.add_argument(
            "-m",
            "--machines",
            type=lambda csv: [machine for machine in csv.split(',')],
            help="Generate output only for applications on machines which\n"
                 "names match the comma separated list; default is all machines")

        arg_parser.add_argument(
            "-a",
            "--applications",
            type=lambda csv: [applications for applications in csv.split(',')],
            help="Generate output only for the applications which names \n"
                 "match the comma separated list.\n"
                 "It cannot be used in conjunction with --machines")

        arg_parser.add_argument(
            "--someip-libs",
            type=CsvChoices(name="someip-libs", choices=POSSIBLE_SOMEIP_LIBS, none_value="none"),
            default=DEFAULT_SOMEIP_LIB,
            help="Generate SOMEIP network binding output for libraries in comma separated list.\n"
                 "Use --someip-libs=\"none\" when binding is not needed")

        arg_parser.add_argument(
            "--user-defined-libs",
            type=CsvChoices(name="userdef-libs", choices=POSSIBLE_USERDEF_LIBS, none_value="none"),
            default=DEFAULT_USERDEF_LIB,
            help="Generate user defined network binding output for libraries in comma separated list.\n"
                 "Use --user-defined-libs=\"none\" when binding is not needed")

        arg_parser.add_argument(
            "--dds-libs",
            type=CsvChoices(name="userdef-libs", choices=POSSIBLE_DDS_LIBS, none_value="none"),
            default=DEFAULT_DDS_LIB,
            help="Generate DDS network binding output for libraries in comma separated list.\n"
                 "Use --dds-libs=\"none\" when binding is not needed")

        arg_parser.add_argument(
            "-o",
            "--output",
            help="Output directory for the generator")

        arg_parser.add_argument(
            "file",
            nargs="+",
            help="A list of files that will be input for the generator,\n"
                 "can be either globs, individual files, or directories.\n"
                 "In the case that there is a path to a directory, all\n"
                 ".arxml files in the directory will be used as input.")

        arg_parser.add_argument(
            '--force-pkg-path-fallback',
            action='store_true',
            required=False,
            default=False,
            help='Force the fallback of using package name hierarchy'
                 'when namespaces (symbol-props) are not available')

        arg_parser.add_argument(
            '--proloc-binding',
            action='store_true',
            required=False,
            default=False,
            help='Generate proloc (Process Local) binding')

        arg_parser.add_argument(
            '--log-console',
            action='store_true',
            required=False,
            default=False,
            help="Whether vSomeIPd shall log to the console")

        arg_parser.add_argument(
            '--log-dlt',
            action='store_true',
            required=False,
            default=False,
            help="Whether vSomeIPd shall log to DLT")

        arg_parser.add_argument(
            "--log-level",
            required=False,
            default="debug",
            help="vsomeipd log level")

        arg_parser.add_argument(
            "--log-file-enable",
            action='store_true',
            required=False,
            default=False,
            help="Log file enable for vsomeipd")

        arg_parser.add_argument(
            "--log-file-path",
            required=False,
            default="/var/log/vsomeip.log",
            help="Log file path for vsomeipd")

        arguments = argv[1:]
        self._args = arg_parser.parse_args(arguments)
        # fixme: The method should be called with the config object when the --config arg is enabled.
        self._args.config = load_default_config_values(None)

    @property
    def verbose(self):
        """
        Return verbose flag.
        :return: Boolean flag
        """
        return self._args.verbose

    @property
    def quiet(self):
        """
        Return quiet flag.
        :return: Boolean flag
        """
        return self._args.quiet

    @property
    def log(self):
        """
        Return log flag.
        :return: Boolean flag
        """
        return self._args.log

    @property
    def file(self):
        """
        Return file path.
        :return: File Path
        """
        return self._args.file

    @property
    def config(self):
        """
        Return config.
        :return: Configuration Dictionary
        """
        return self._args.config

    @property
    def debug(self):
        """
        Return Debug flag.
        :return: Boolean flag
        """
        return self._args.debug

    @property
    def dry_run(self):
        """
        Return dry_run flag.
        :return: Boolean flag
        """
        return self._args.dry_run

    @property
    def generate(self):
        """
        Return Generators options List.
        :return: Generators List
        """
        return self._args.generate

    @property
    def output_dir(self):
        """
        Return Output Directory of the Generator.
        :return: Output Directory Path
        """
        return self._args.output

    @property
    def machines(self):
        """
        Return Machines Names to be generated.
        :return: Machines Names List
        """
        return self._args.machines

    @property
    def applications(self):
        """
        Return Applications Names to be generated.
        :return: Applications Names List
        """
        return self._args.applications

    @property
    def someip_libs(self):
        """
        Return SOMEIP libraries names
        :return: SOMEIP libraries names list
        """
        return self._args.someip_libs

    @property
    def user_defined_libs(self):
        """
        Return defined by user library binding names
        :return: user-defined libraries names list
        """
        return self._args.user_defined_libs

    @property
    def dds_libs(self):
        """
        Return DDS libraries names
        :return: DDS libraries names list
        """
        return self._args.dds_libs

    @property
    def list_machines(self):
        """
        Return if list-machines flag has been set.
        :return: Boolean flag
        """
        return self._args.list_machines

    @property
    def list_applications(self):
        """
        Return if list-applications flag has been set.
        :return: Boolean flag
        """
        return self._args.list_applications

    @property
    def list_files(self):
        """
        Return if list-files flag has been set.
        :return: Boolean flag
        """
        return self._args.list_files

    @property
    def pkg_path_fallback(self):
        return self._args.force_pkg_path_fallback

    @property
    def proloc_binding_needed(self):
        return self._args.proloc_binding

    @property
    def use_console_for_logging(self):
        return self._args.log_console

    @property
    def use_dlt_for_logging(self):
        return self._args.log_dlt

    @property
    def log_level(self):
        return self._args.log_level

    @property
    def use_file_for_logging(self):
        return self._args.log_file_enable

    @property
    def log_file_path(self):
        return self._args.log_file_path
