// --------------------------------------------------------------------------
// |              _    _ _______     .----.      _____         _____        |
// |         /\  | |  | |__   __|  .  ____ .    / ____|  /\   |  __ \       |
// |        /  \ | |  | |  | |    .  / __ \ .  | (___   /  \  | |__) |      |
// |       / /\ \| |  | |  | |   .  / / / / v   \___ \ / /\ \ |  _  /       |
// |      / /__\ \ |__| |  | |   . / /_/ /  .   ____) / /__\ \| | \ \       |
// |     /________\____/   |_|   ^ \____/  .   |_____/________\_|  \_\      |
// |                              . _ _  .                                  |
// --------------------------------------------------------------------------
//
// All Rights Reserved.
// Any use of this source code is subject to a license agreement with the
// AUTOSAR development cooperation.
// More information is available at www.autosar.org.
//
// Disclaimer
//
// This work (specification and/or software implementation) and the material
// contained in it, as released by AUTOSAR, is for the purpose of information
// only. AUTOSAR and the companies that have contributed to it shall not be
// liable for any use of the work.
//
// The material contained in this work is protected by copyright and other
// types of intellectual property rights. The commercial exploitation of the
// material contained in this work requires a license to such intellectual
// property rights.
//
// This work may be utilized or reproduced without any modification, in any
// form or by any means, for informational purposes only. For any other
// purpose, no part of the work may be utilized or reproduced, in any form
// or by any means, without permission in writing from the publisher.
//
// The work has been developed for automotive applications only. It has
// neither been developed, nor tested for non-automotive applications.
//
// The word AUTOSAR and the AUTOSAR logo are registered trademarks.
// --------------------------------------------------------------------------

#ifndef franca_sample_includes_impl_type_genericrawattribute_h
#define franca_sample_includes_impl_type_genericrawattribute_h

#include "impl_type_attribute1.h"
#include "impl_type_attribute2.h"
#include "impl_type_attribute3.h"
#include "impl_type_attribute4.h"
#include "impl_type_attribute5.h"
#include "impl_type_attribute6.h"

struct GenericRawAttribute {
  ::Attribute1 attribute1;
  ::Attribute2 attribute2;
  ::Attribute3 attribute3;
  ::Attribute4 attribute4;
  ::Attribute5 attribute5;
  ::Attribute6 attribute6;

  using IsEnumerableTag = void;
  template<typename F>
  void enumerate(F& fun) {
    fun(this->attribute1);
    fun(this->attribute2);
    fun(this->attribute3);
    fun(this->attribute4);
    fun(this->attribute5);
    fun(this->attribute6);
  }
};

#endif // franca_sample_includes_impl_type_genericrawattribute_h

