#  --------------------------------------------------------------------------
#  |              _    _ _______     .----.      _____         _____        |
#  |         /\  | |  | |__   __|  .  ____ .    / ____|  /\   |  __ \       |
#  |        /  \ | |  | |  | |    .  / __ \ .  | (___   /  \  | |__) |      |
#  |       / /\ \| |  | |  | |   .  / / / / v   \___ \ / /\ \ |  _  /       |
#  |      / /__\ \ |__| |  | |   . / /_/ /  .   ____) / /__\ \| | \ \       |
#  |     /________\____/   |_|   ^ \____/  .   |_____/________\_|  \_\      |
#  |                              . _ _  .                                  |
#  --------------------------------------------------------------------------
#
#  All Rights Reserved.
#  Any use of this source code is subject to a license agreement with the
#  AUTOSAR development cooperation.
#  More information is available at www.autosar.org.
#
#  Disclaimer
#
#  This work (specification and/or software implementation) and the material
#  contained in it, as released by AUTOSAR, is for the purpose of information
#  only. AUTOSAR and the companies that have contributed to it shall not be
#  liable for any use of the work.
#
#  The material contained in this work is protected by copyright and other
#  types of intellectual property rights. The commercial exploitation of the
#  material contained in this work requires a license to such intellectual
#  property rights.
#
#  This work may be utilized or reproduced without any modification, in any
#  form or by any means, for informational purposes only. For any other
#  purpose, no part of the work may be utilized or reproduced, in any form
#  or by any means, without permission in writing from the publisher.
#
#  The work has been developed for automotive applications only. It has
#  neither been developed, nor tested for non-automotive applications.
#
#  The word AUTOSAR and the AUTOSAR logo are registered trademarks.
#  --------------------------------------------------------------------------

# pylint: disable=too-many-lines,too-many-public-methods

#from generator.parser import default_parser
from generator.parser.default_parser import \
    DefaultParser, _PTM_MAPPINGS, _STM_MAPPINGS, _STP_MAPPINGS, get_element_or_die
from generator.intermediate_model.execution_management.process import Process
from generator.parser.autosar_mapping import AUTOSARMapping, PathError
from generator.parser.v47.network_binding_builder import NetworkBindingBuilder
from generator.parser.tree_helper import get_element, get_element_or_die, get_element_or_none, to_list, to_str


class Parser(DefaultParser):
    """
    Handles parsing the ARXML and providing the intermediate model that it
    represents.
    """

    def __init__(self, model, package_path_fallback=False):
        super().__init__(model, package_path_fallback)
        self._network_binding_builder = NetworkBindingBuilder(self.model)

    def read_em_info(self, ar_process):

        result = {"platform_application": None, "timer_granularity": None}
        ar_executable_ref = get_element_or_die(ar_process, "EXECUTABLE-REF")
        ar_executable = self.model.find_referable(ar_executable_ref.text)
        ar_category = get_element_or_none(ar_executable, "CATEGORY")
        ar_timer_granularity = get_element_or_none(ar_executable, "MINIMUM-TIMER-GRANULARITY")
        if ar_category:
            result["platform_application"] = ar_category.text.upper() == "PLATFORM_LEVEL"
        if ar_timer_granularity:
            result["timer_granularity"] = int(float(ar_timer_granularity.text))


        ar_md_startup_configs = get_element_or_none(ar_process, "STATE-DEPENDENT-STARTUP-CONFIGS/STATE-DEPENDENT-STARTUP-CONFIG")
        ar_md_startup_configs = to_list(ar_md_startup_configs)
        startup_configs = []
        for ar_md_startup_config in ar_md_startup_configs:

            dependencies = []
            ar_exec_dependencies = get_element_or_none(ar_md_startup_config, "EXECUTION-DEPENDENCYS/EXECUTION-DEPENDENCY")
            ar_exec_dependencies = to_list(ar_exec_dependencies)
            for ar_exec_dependency in ar_exec_dependencies:
                ar_mode_group_ref = get_element_or_die(ar_exec_dependency, "PROCESS-STATE-IREF/CONTEXT-MODE-DECLARATION-GROUP-PROTOTYPE-REF")
                ar_mode_ref = get_element_or_die(ar_exec_dependency, "PROCESS-STATE-IREF/TARGET-MODE-DECLARATION-REF")
                ar_mode = self.model.find_referable(ar_mode_ref.text)
                mode = ar_mode.SHORT_NAME
                process_ref = self.model.parent(ar_mode_group_ref.text)
                ar_process = self.model.find_referable(process_ref)
                process = ar_process.SHORT_NAME
                dependencies.append({"process": process, "mode": mode})

            fg_modes = []
            machine_states = []
            ar_fg_modes = get_element_or_none(ar_md_startup_config, "FUNCTION-GROUP-STATE-IREFS/FUNCTION-GROUP-STATE-IREF")
            ar_fg_modes = to_list(ar_fg_modes)
            for ar_fg_mode in ar_fg_modes:
                ar_mode_group_ref = get_element_or_die(ar_fg_mode, "CONTEXT-MODE-DECLARATION-GROUP-PROTOTYPE-REF")
                ar_mode_ref = get_element_or_die(ar_fg_mode, "TARGET-MODE-DECLARATION-REF")
                ar_mode_group = self.model.find_referable(ar_mode_group_ref.text)
                ar_mode = self.model.find_referable(ar_mode_ref.text)
                mode = ar_mode.SHORT_NAME
                mode_group = ar_mode_group.SHORT_NAME
                if mode_group == "MachineState":
                    machine_states.append(mode)
                else:
                    fg_modes.append({"mode_group": mode_group, "mode": mode})

            resource_group = None
            ar_resource_group_ref = get_element_or_none(ar_md_startup_config, "RESOURCE-GROUP-REF")
            if ar_resource_group_ref:
                ar_resource_group = self.model.find_referable(ar_resource_group_ref.text)
                resource_group = ar_resource_group.SHORT_NAME

            scheduling_policy = None
            scheduling_priority = None
            environment_vars = []
            arguments = []
            ar_startup_config_ref = get_element_or_none(ar_md_startup_config, "STARTUP-CONFIG-REF")
            if ar_startup_config_ref:
                ar_startup_config = self.model.find_referable(ar_startup_config_ref.text)
                scheduling_policy = to_str(get_element_or_none(ar_startup_config, "SCHEDULING-POLICY"))
                scheduling_priority = to_str(get_element_or_none(ar_startup_config, "SCHEDULING-PRIORITY"))
                ar_envs = get_element_or_none(ar_startup_config, "ENVIRONMENT-VARIABLES/TAG-WITH-OPTIONAL-VALUE")
                ar_envs = to_list(ar_envs)
                for ar_env in ar_envs:
                    var_name = ar_env.KEY
                    var_value = to_str(get_element_or_none(ar_env, "VALUE"))
                    environment_vars.append({"var_name": var_name, "var_value": var_value})

                ar_args = get_element_or_none(ar_startup_config, "STARTUP-OPTIONS/STARTUP-OPTION")
                ar_args = to_list(ar_args)
                for ar_arg in ar_args:
                    kind = ar_arg.OPTION_KIND
                    long_form = kind == "COMMAND-LINE-LONG-FORM"
                    arg = to_str(get_element_or_none(ar_arg, "OPTION-ARGUMENT"))
                    name = to_str(get_element_or_none(ar_arg, "OPTION-NAME"))
                    arguments.append({"long_form": long_form, "arg": arg, "name": name})

            md_startup_config = {
                "dependencies": dependencies,
                "fg_modes": fg_modes,
                "machine_states": machine_states,
                "resource_group": resource_group,
                "scheduling_policy": scheduling_policy,
                "scheduling_priority": scheduling_priority,
                "environment_vars": environment_vars,
                "arguments": arguments,
            }

            startup_configs.append(md_startup_config)

        result["startup_configs"] = startup_configs
        #-----------------
        states = []
        mode_machine = None
        ar_mode_machine_ref = get_element_or_none(ar_process, "PROCESS-STATE-MACHINE/TYPE-TREF")
        if ar_mode_machine_ref:
            ar_mode_machine = self.model.find_referable(ar_mode_machine_ref.text)
            mode_machine = ar_mode_machine.SHORT_NAME
            ar_modes = get_element_or_none(ar_mode_machine, "MODE-DECLARATIONS/MODE-DECLARATION")
            ar_modes = to_list(ar_modes)
            for ar_mode in ar_modes:
                states.append(ar_mode.SHORT_NAME)
        result["application_states"] = {"mode_machine": mode_machine, "states": states}
        #-----------------
        return result

    def get_processes(self, ar_machine):
        """Get the processes contained in a ar_machine"""
        ar_processes = []

        # Get the Process To Machine Mapping.
        proc_to_machine_mappings = self.model.find_elements_of_type(_PTM_MAPPINGS, MACHINE_REF=ar_machine.get_fqn())

        # If Process To Machine Mapping is given as Input.
        if proc_to_machine_mappings:
            for mapping in proc_to_machine_mappings:
                try:
                    ar_process = self.model.find_referable(mapping.PROCESS_REF)
                except PathError:
                    self._log.warning("PROCESS Ref {} used in machine {} is not found! Mapping will be ignored".
                                      format(mapping.PROCESS_REF, ar_machine))
                    continue

                ar_processes.append(ar_process)
        else:
            # Deduce the Process to Machine Mapping from SOMEIP-SERVICE-INSTANCE-TO-MACHINE-MAPPING &
            # SERVICE-INSTANCE-TO-PORT-PROTOTYPE-MAPPING
            self._log.warning("No PROCESS-TO-MACHINE-MAPPING is found in input data, trying to find Processes "
                              "for Machine {} ...".format(ar_machine))
            machine_design = self.get_machine_design(ar_machine)

            if machine_design is not None:
                communication_connector_fqn = self._get_communication_connector(machine_design).get_fqn()

                # Get the SOME/IP to Machine Mappings that match the communication connector of the current machine.
                self._log.debug("Getting SOME/IP to Machine Mappings that match the communication connector {}".
                                format(communication_connector_fqn))
                someip_to_machine_mappings = \
                    self.model.find_elements_of_type(_STM_MAPPINGS,
                                                     COMMUNICATION_CONNECTOR_REF=communication_connector_fqn)

                for someip_to_machine_mapping in someip_to_machine_mappings:
                    # Get the Service To Port Prototype Mappings that match the SERVICE INTERFACES
                    # of SOME/IP To Machines.
                    service_instance_refs = get_element_or_die(someip_to_machine_mapping, "SERVICE-INSTANCE-REFS/SERVICE-INSTANCE-REF")
                    if len(service_instance_refs) > 1:
                        self._log.warning("More than one SERVICE-INSTANCE-REF found for %s! The first match is used", someip_to_machine_mapping.name())

                    self._log.debug("Getting Service Instance To Port Prototype Mappings that match "
                                    "the Service Interface {}".format(service_instance_refs[0]))
                    service_to_port_mappings = \
                        self.model.find_elements_of_type(_STP_MAPPINGS,
                                                         SERVICE_INSTANCE_REF=service_instance_refs[0])
                    if service_to_port_mappings:
                        try:
                            self._log.debug("Getting the Process {} which maps to Machine {}"
                                            .format(service_to_port_mappings[0].PROCESS_REF,
                                                    ar_machine.get_fqn()))
                            ar_process = self.model.find_referable(service_to_port_mappings[0].PROCESS_REF)
                        except PathError:
                            self._log.warning("PROCESS Ref {} used in {} is not found! Mapping will be ignored"
                                              .format(service_to_port_mappings[0].PROCESS_REF,
                                                      service_to_port_mappings[0].SHORT_NAME))
                            continue

                        ar_processes.append(ar_process)

        processes = [Process(fqn=ar_process.get_fqn(),
                             executable=self.get_executable(ar_process),
                             em_info = self.read_em_info(ar_process))
                     for ar_process in ar_processes]

        if not processes:
            self._log.warning("No processes found for the Machine {}".format(ar_machine))
        else:
            self._log.debug("Processes {} are found for Machine {}".format(processes, ar_machine))
        return processes
