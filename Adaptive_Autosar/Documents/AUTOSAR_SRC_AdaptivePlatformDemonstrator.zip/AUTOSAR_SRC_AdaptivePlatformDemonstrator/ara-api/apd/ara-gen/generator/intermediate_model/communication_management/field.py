#  --------------------------------------------------------------------------
#  |              _    _ _______     .----.      _____         _____        |
#  |         /\  | |  | |__   __|  .  ____ .    / ____|  /\   |  __ \       |
#  |        /  \ | |  | |  | |    .  / __ \ .  | (___   /  \  | |__) |      |
#  |       / /\ \| |  | |  | |   .  / / / / v   \___ \ / /\ \ |  _  /       |
#  |      / /__\ \ |__| |  | |   . / /_/ /  .   ____) / /__\ \| | \ \       |
#  |     /________\____/   |_|   ^ \____/  .   |_____/________\_|  \_\      |
#  |                              . _ _  .                                  |
#  --------------------------------------------------------------------------
#
#  All Rights Reserved.
#  Any use of this source code is subject to a license agreement with the
#  AUTOSAR development cooperation.
#  More information is available at www.autosar.org.
#
#  Disclaimer
#
#  This work (specification and/or software implementation) and the material
#  contained in it, as released by AUTOSAR, is for the purpose of information
#  only. AUTOSAR and the companies that have contributed to it shall not be
#  liable for any use of the work.
#
#  The material contained in this work is protected by copyright and other
#  types of intellectual property rights. The commercial exploitation of the
#  material contained in this work requires a license to such intellectual
#  property rights.
#
#  This work may be utilized or reproduced without any modification, in any
#  form or by any means, for informational purposes only. For any other
#  purpose, no part of the work may be utilized or reproduced, in any form
#  or by any means, without permission in writing from the publisher.
#
#  The work has been developed for automotive applications only. It has
#  neither been developed, nor tested for non-automotive applications.
#
#  The word AUTOSAR and the AUTOSAR logo are registered trademarks.
#  --------------------------------------------------------------------------

"""
Field class.
"""


class Field(object):
    """Describes a Field in a Service"""
    def __init__(self, name, init_value="",
                 has_notifier=False, has_getter=False, has_setter=False, deployment=None, impl_type=None):
        if name == "":
            raise AttributeError("A Field must have a name")
        self._name = name
        self._has_notifier = has_notifier
        self._has_getter = has_getter
        self._has_setter = has_setter
        self._init_value = init_value
        self._deployment = deployment
        self._impl_type = impl_type

    @property
    def name(self):
        """Get the name of this Field."""
        return self._name

    @property
    def init_value(self):
        """Get the initial value of this Field."""
        return self._init_value

    @init_value.setter
    def init_value(self, init_value):
        """Set the initial value of this Field."""
        self._init_value = init_value

    @property
    def has_notifier(self):
        """Get the Notifier of this Field."""
        return self._has_notifier

    @has_notifier.setter
    def has_notifier(self, has_notifier):
        """Set the Notifier of this Field."""
        self._has_notifier = has_notifier

    @property
    def has_getter(self):
        """Get the Getter of this Field."""
        return self._has_getter

    @has_getter.setter
    def has_getter(self, has_getter):
        """Set the Getter of this Field."""
        self._has_getter = has_getter

    @property
    def has_setter(self):
        """Get the Setter of this Field."""
        return self._has_setter

    @has_setter.setter
    def has_setter(self, has_setter):
        """Set the Setter of this Field."""
        self._has_setter = has_setter

    @property
    def deployment(self):
        """Get the deployment of this Field."""
        return self._deployment

    @deployment.setter
    def deployment(self, deployment):
        """Set the deployment of this Field"""
        self._deployment = deployment

    @property
    def impl_type(self):
        """Get the implementation data type of this Field."""
        return self._impl_type

    @impl_type.setter
    def impl_type(self, impl_type):
        """Set the implementation data type of this Field"""
        self._impl_type = impl_type
