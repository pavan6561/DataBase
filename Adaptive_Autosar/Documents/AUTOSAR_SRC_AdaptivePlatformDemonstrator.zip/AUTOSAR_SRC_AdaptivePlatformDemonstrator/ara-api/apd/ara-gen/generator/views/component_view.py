#  --------------------------------------------------------------------------
#  |              _    _ _______     .----.      _____         _____        |
#  |         /\  | |  | |__   __|  .  ____ .    / ____|  /\   |  __ \       |
#  |        /  \ | |  | |  | |    .  / __ \ .  | (___   /  \  | |__) |      |
#  |       / /\ \| |  | |  | |   .  / / / / v   \___ \ / /\ \ |  _  /       |
#  |      / /__\ \ |__| |  | |   . / /_/ /  .   ____) / /__\ \| | \ \       |
#  |     /________\____/   |_|   ^ \____/  .   |_____/________\_|  \_\      |
#  |                              . _ _  .                                  |
#  --------------------------------------------------------------------------
#
#  All Rights Reserved.
#  Any use of this source code is subject to a license agreement with the
#  AUTOSAR development cooperation.
#  More information is available at www.autosar.org.
#
#  Disclaimer
#
#  This work (specification and/or software implementation) and the material
#  contained in it, as released by AUTOSAR, is for the purpose of information
#  only. AUTOSAR and the companies that have contributed to it shall not be
#  liable for any use of the work.
#
#  The material contained in this work is protected by copyright and other
#  types of intellectual property rights. The commercial exploitation of the
#  material contained in this work requires a license to such intellectual
#  property rights.
#
#  This work may be utilized or reproduced without any modification, in any
#  form or by any means, for informational purposes only. For any other
#  purpose, no part of the work may be utilized or reproduced, in any form
#  or by any means, without permission in writing from the publisher.
#
#  The work has been developed for automotive applications only. It has
#  neither been developed, nor tested for non-automotive applications.
#
#  The word AUTOSAR and the AUTOSAR logo are registered trademarks.
#  --------------------------------------------------------------------------

"""
"A view to with convenience methods for generating information about a component"
"""
import os

from generator.views.view import View
from generator.intermediate_model.execution_management.component import Component
from generator.views.service_view import ServiceView
from generator.views.view_factory import ViewFactory


class ComponentView(View):
    """Specialized View of a SoftwareComponent"""
    def __init__(self, component: Component) -> None:
        self._component = component
        self._required_services = list(set([ViewFactory.create_service_view(x) for x in self._component.required_services]))
        self._provided_services = list(set([ViewFactory.create_service_view(x) for x in self._component.provided_services]))
        super().__init__(component)

    @property
    def get_component(self):
        """Get the component in the view"""
        return self._component

    @property
    def include_list(self):
        """Get the include files list for the vsomeip_service_mapping_def template"""
        proxies_list = []
        for rs in self._required_services:
            ns = rs.namespaces
            if ns is None:
                ns = []
            include_string = "/".join(ns + ["proxy_vsomeip_" + rs.standard_name + ".h"])
            proxies_list += [include_string]

        adapters_list = []
        for ps in self._provided_services:
            ns = ps.namespaces
            if ns is None:
                ns = []
            include_string = "/".join(ns + ["adapter_" + ps.standard_name + ".h"])
            adapters_list += [include_string]

        return sorted(proxies_list) + sorted(adapters_list)

    def service_is_required(self, serviceview: ServiceView):
        return serviceview in self._required_services

    def service_is_provided(self, serviceview: ServiceView):
        return serviceview in self._provided_services


    @property
    def services_list(self):
        """Get the service list for the vsomeip_service_mapping_def template"""
        _services = list(set(self._required_services + self._provided_services))
        return sorted(_services)
