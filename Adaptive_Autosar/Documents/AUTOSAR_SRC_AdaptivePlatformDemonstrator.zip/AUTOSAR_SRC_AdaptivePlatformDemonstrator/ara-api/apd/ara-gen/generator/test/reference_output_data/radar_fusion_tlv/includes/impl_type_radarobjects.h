// --------------------------------------------------------------------------
// |              _    _ _______     .----.      _____         _____        |
// |         /\  | |  | |__   __|  .  ____ .    / ____|  /\   |  __ \       |
// |        /  \ | |  | |  | |    .  / __ \ .  | (___   /  \  | |__) |      |
// |       / /\ \| |  | |  | |   .  / / / / v   \___ \ / /\ \ |  _  /       |
// |      / /__\ \ |__| |  | |   . / /_/ /  .   ____) / /__\ \| | \ \       |
// |     /________\____/   |_|   ^ \____/  .   |_____/________\_|  \_\      |
// |                              . _ _  .                                  |
// --------------------------------------------------------------------------
//
// All Rights Reserved.
// Any use of this source code is subject to a license agreement with the
// AUTOSAR development cooperation.
// More information is available at www.autosar.org.
//
// Disclaimer
//
// This work (specification and/or software implementation) and the material
// contained in it, as released by AUTOSAR, is for the purpose of information
// only. AUTOSAR and the companies that have contributed to it shall not be
// liable for any use of the work.
//
// The material contained in this work is protected by copyright and other
// types of intellectual property rights. The commercial exploitation of the
// material contained in this work requires a license to such intellectual
// property rights.
//
// This work may be utilized or reproduced without any modification, in any
// form or by any means, for informational purposes only. For any other
// purpose, no part of the work may be utilized or reproduced, in any form
// or by any means, without permission in writing from the publisher.
//
// The work has been developed for automotive applications only. It has
// neither been developed, nor tested for non-automotive applications.
//
// The word AUTOSAR and the AUTOSAR logo are registered trademarks.
// --------------------------------------------------------------------------

#ifndef radar_fusion_tlv_includes_impl_type_radarobjects_h
#define radar_fusion_tlv_includes_impl_type_radarobjects_h

#include "ara/core/optional.h"
#include "impl_type_bytearray.h"
#include "impl_type_myarray.h"
#include <cstdint>
#include <set>

struct RadarObjects {
  ara::core::Optional<bool> active;
  ::ByteArray objectVector;
  ::MyArray objectArray;
  
  using Is_TLV_tag = void;
  using LengthFieldType = std::uint16_t;
  using TLVLengthFieldType = std::uint16_t;
  template<typename F>
  void enumerate(F& fun) {
    fun(this->active, 0x0000);
    fun(this->objectVector, 0x0001);
    fun(this->objectArray, 0x0002);
  }

  template<typename F>
  bool dispatch(std::uint32_t data_id, F& fun) {
      bool result = true;
      switch ( data_id )
      {
          case 0x0000: {fun(this->active); break;}
          case 0x0001: {fun(this->objectVector); break;}
          case 0x0002: {fun(this->objectArray); break;}
          default: {result = false; break;}
      }
      return result;
  }

  std::set<std::uint16_t> required_fields(void) {
      return {
          0x0001,
          0x0002,
      };
  }
};

#endif // radar_fusion_tlv_includes_impl_type_radarobjects_h

