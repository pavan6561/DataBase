// --------------------------------------------------------------------------
// |              _    _ _______     .----.      _____         _____        |
// |         /\  | |  | |__   __|  .  ____ .    / ____|  /\   |  __ \       |
// |        /  \ | |  | |  | |    .  / __ \ .  | (___   /  \  | |__) |      |
// |       / /\ \| |  | |  | |   .  / / / / v   \___ \ / /\ \ |  _  /       |
// |      / /__\ \ |__| |  | |   . / /_/ /  .   ____) / /__\ \| | \ \       |
// |     /________\____/   |_|   ^ \____/  .   |_____/________\_|  \_\      |
// |                              . _ _  .                                  |
// --------------------------------------------------------------------------
//
// All Rights Reserved.
// Any use of this source code is subject to a license agreement with the
// AUTOSAR development cooperation.
// More information is available at www.autosar.org.
//
// Disclaimer
//
// This work (specification and/or software implementation) and the material
// contained in it, as released by AUTOSAR, is for the purpose of information
// only. AUTOSAR and the companies that have contributed to it shall not be
// liable for any use of the work.
//
// The material contained in this work is protected by copyright and other
// types of intellectual property rights. The commercial exploitation of the
// material contained in this work requires a license to such intellectual
// property rights.
//
// This work may be utilized or reproduced without any modification, in any
// form or by any means, for informational purposes only. For any other
// purpose, no part of the work may be utilized or reproduced, in any form
// or by any means, without permission in writing from the publisher.
//
// The work has been developed for automotive applications only. It has
// neither been developed, nor tested for non-automotive applications.
//
// The word AUTOSAR and the AUTOSAR logo are registered trademarks.
// --------------------------------------------------------------------------

#ifndef map_sample_v45_vsomeip_ara_gen_adapter_map_h
#define map_sample_v45_vsomeip_ara_gen_adapter_map_h

#include "ara/com/internal/vsomeip/skeleton/vsomeip_skeleton_base.h"
#include "service_desc_map.h"
#include "ara/gen/map_skeleton.h"

namespace ara {
namespace gen {
namespace map_binding {
namespace vsomeip {

class mapServiceAdapter : public ::ara::com::internal::vsomeip::skeleton::ServiceImplBase {
 public:
  using ServiceInterface = skeleton::mapSkeleton;
  using ServiceDescriptor = descriptors::internal::Service;

  mapServiceAdapter(ServiceInterface& service, ara::com::internal::InstanceId instance) :
    ::ara::com::internal::vsomeip::skeleton::ServiceImplBase(service, instance),
    SimpleMap(instance),
    FullMap(instance) {
    Connect(service);
    OfferService(ServiceDescriptor::service_id, GetInstanceId(), ServiceDescriptor::service_version, ServiceDescriptor::minor_service_version);
    OfferField(ServiceDescriptor::service_id, GetInstanceId(), descriptors::SimpleMap::event_id, descriptors::SimpleMap::event_groups);
    OfferField(ServiceDescriptor::service_id, GetInstanceId(), descriptors::FullMap::event_id, descriptors::FullMap::event_groups);
  }

  virtual ~mapServiceAdapter() {
    StopOfferField(descriptors::SimpleMap::service_id, GetInstanceId(), descriptors::SimpleMap::event_id);
    StopOfferField(descriptors::FullMap::service_id, GetInstanceId(), descriptors::FullMap::event_id);
    StopOfferService(ServiceDescriptor::service_id, GetInstanceId());
    Disconnect(dynamic_cast<ServiceInterface&>(service_));
  }

 private:
  void Connect(ServiceInterface& service) {
    service.AddDelegate(*this);
    service.SimpleMap.AddDelegate(SimpleMap);
    service.FullMap.AddDelegate(FullMap);
  }

  void Disconnect(ServiceInterface& service) {
    service.RemoveDelegate(*this);
    service.SimpleMap.RemoveDelegate(SimpleMap);
    service.FullMap.RemoveDelegate(FullMap);
  }

  ara::com::internal::vsomeip::skeleton::FieldImpl<::ara::diag::datatypes::MetaInfoTypeInt, descriptors::SimpleMap> SimpleMap;
  ara::com::internal::vsomeip::skeleton::FieldImpl<::ara::diag::datatypes::MetaInfoType, descriptors::FullMap> FullMap;
};

} // namespace vsomeip
} // namespace map_binding
} // namespace gen
} // namespace ara

#endif // map_sample_v45_vsomeip_ara_gen_adapter_map_h

