// --------------------------------------------------------------------------
// |              _    _ _______     .----.      _____         _____        |
// |         /\  | |  | |__   __|  .  ____ .    / ____|  /\   |  __ \       |
// |        /  \ | |  | |  | |    .  / __ \ .  | (___   /  \  | |__) |      |
// |       / /\ \| |  | |  | |   .  / / / / v   \___ \ / /\ \ |  _  /       |
// |      / /__\ \ |__| |  | |   . / /_/ /  .   ____) / /__\ \| | \ \       |
// |     /________\____/   |_|   ^ \____/  .   |_____/________\_|  \_\      |
// |                              . _ _  .                                  |
// --------------------------------------------------------------------------
//
// All Rights Reserved.
// Any use of this source code is subject to a license agreement with the
// AUTOSAR development cooperation.
// More information is available at www.autosar.org.
//
// Disclaimer
//
// This work (specification and/or software implementation) and the material
// contained in it, as released by AUTOSAR, is for the purpose of information
// only. AUTOSAR and the companies that have contributed to it shall not be
// liable for any use of the work.
//
// The material contained in this work is protected by copyright and other
// types of intellectual property rights. The commercial exploitation of the
// material contained in this work requires a license to such intellectual
// property rights.
//
// This work may be utilized or reproduced without any modification, in any
// form or by any means, for informational purposes only. For any other
// purpose, no part of the work may be utilized or reproduced, in any form
// or by any means, without permission in writing from the publisher.
//
// The work has been developed for automotive applications only. It has
// neither been developed, nor tested for non-automotive applications.
//
// The word AUTOSAR and the AUTOSAR logo are registered trademarks.
// --------------------------------------------------------------------------

#ifndef radar_fusion_execution_manifest_vsomeip_ara_com_sample_proxy_vsomeip_radar_h
#define radar_fusion_execution_manifest_vsomeip_ara_com_sample_proxy_vsomeip_radar_h

#include "service_desc_radar.h"
#include "ara/com/sample/radar_proxy.h"

namespace ara {
namespace com {
namespace sample {
namespace radar_binding {
namespace vsomeip {

class radarImpl : public proxy::radarProxyBase, public ::ara::com::internal::vsomeip::proxy::ProxyImplBase {
 public:
  using ProxyInterface = proxy::radarProxy;
  using ServiceDescriptor = descriptors::internal::Service;

  explicit radarImpl(ara::com::internal::InstanceId instance) :
      ::ara::com::internal::vsomeip::proxy::ProxyImplBase(ServiceDescriptor::service_id, instance, ServiceDescriptor::service_version),
      UpdateRate(instance),
      FrontObjectDistance(instance),
      RearObjectDistance(instance),
      ObjectDetectionLimit(instance),
      brakeEvent(instance),
      parkingBrakeEvent(instance),
      Adjust(instance),
      Calibrate(instance) {}

  virtual ~radarImpl() {}

  virtual proxy::fields::UpdateRateField& GetUpdateRate() override { return UpdateRate; }
  virtual proxy::fields::FrontObjectDistanceField& GetFrontObjectDistance() override { return FrontObjectDistance; }
  virtual proxy::fields::RearObjectDistanceField& GetRearObjectDistance() override { return RearObjectDistance; }
  virtual proxy::fields::ObjectDetectionLimitField& GetObjectDetectionLimit() override { return ObjectDetectionLimit; }
  virtual proxy::events::brakeEvent& GetbrakeEvent() override { return brakeEvent; }
  virtual proxy::events::parkingBrakeEvent& GetparkingBrakeEvent() override { return parkingBrakeEvent; }
  virtual ara::com::sample::proxy::methods::Adjust& GetAdjust() override { return Adjust; }
  virtual ara::com::sample::proxy::methods::Calibrate& GetCalibrate() override { return Calibrate; }

 private:
  ara::com::internal::vsomeip::proxy::MutableFieldImpl<descriptors::UpdateRate, std::uint32_t> UpdateRate;
  ara::com::internal::vsomeip::proxy::FieldImpl<descriptors::FrontObjectDistance, std::uint16_t> FrontObjectDistance;
  ara::com::internal::vsomeip::proxy::FieldImpl<descriptors::RearObjectDistance, std::uint16_t> RearObjectDistance;
  ara::com::internal::vsomeip::proxy::MutableFieldImpl<descriptors::ObjectDetectionLimit, std::uint16_t> ObjectDetectionLimit;
  ara::com::internal::vsomeip::proxy::EventImpl<descriptors::brakeEvent, ::ara::com::sample::RadarObjects> brakeEvent;
  ara::com::internal::vsomeip::proxy::EventImpl<descriptors::parkingBrakeEvent, ::ara::com::sample::RadarObjects> parkingBrakeEvent;
  ara::com::internal::vsomeip::proxy::MethodImpl<descriptors::Adjust, ara::com::sample::proxy::methods::Adjust::signature_type> Adjust;
  ara::com::internal::vsomeip::proxy::MethodImpl<descriptors::Calibrate, ara::com::sample::proxy::methods::Calibrate::signature_type> Calibrate;
};

} // namespace vsomeip
} // namespace radar_binding
} // namespace sample
} // namespace com
} // namespace ara

#endif // radar_fusion_execution_manifest_vsomeip_ara_com_sample_proxy_vsomeip_radar_h

