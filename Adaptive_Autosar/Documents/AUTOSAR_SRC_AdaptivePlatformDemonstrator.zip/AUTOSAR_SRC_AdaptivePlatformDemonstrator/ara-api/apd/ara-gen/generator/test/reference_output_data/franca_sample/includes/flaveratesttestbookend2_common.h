// --------------------------------------------------------------------------
// |              _    _ _______     .----.      _____         _____        |
// |         /\  | |  | |__   __|  .  ____ .    / ____|  /\   |  __ \       |
// |        /  \ | |  | |  | |    .  / __ \ .  | (___   /  \  | |__) |      |
// |       / /\ \| |  | |  | |   .  / / / / v   \___ \ / /\ \ |  _  /       |
// |      / /__\ \ |__| |  | |   . / /_/ /  .   ____) / /__\ \| | \ \       |
// |     /________\____/   |_|   ^ \____/  .   |_____/________\_|  \_\      |
// |                              . _ _  .                                  |
// --------------------------------------------------------------------------
//
// All Rights Reserved.
// Any use of this source code is subject to a license agreement with the
// AUTOSAR development cooperation.
// More information is available at www.autosar.org.
//
// Disclaimer
//
// This work (specification and/or software implementation) and the material
// contained in it, as released by AUTOSAR, is for the purpose of information
// only. AUTOSAR and the companies that have contributed to it shall not be
// liable for any use of the work.
//
// The material contained in this work is protected by copyright and other
// types of intellectual property rights. The commercial exploitation of the
// material contained in this work requires a license to such intellectual
// property rights.
//
// This work may be utilized or reproduced without any modification, in any
// form or by any means, for informational purposes only. For any other
// purpose, no part of the work may be utilized or reproduced, in any form
// or by any means, without permission in writing from the publisher.
//
// The work has been developed for automotive applications only. It has
// neither been developed, nor tested for non-automotive applications.
//
// The word AUTOSAR and the AUTOSAR logo are registered trademarks.
// --------------------------------------------------------------------------

#ifndef franca_sample_includes_flaveratesttestbookend2_common_h
#define franca_sample_includes_flaveratesttestbookend2_common_h

#include <string.h>
#include "ara/core/array.h"

#include "ara/com/types.h"

#include "ara/com/exception.h"
#include "ara/core/error_code.h"
#include "impl_type_attribute1reftypea.h"
#include "impl_type_attribute1reftypec.h"
#include "impl_type_attribute2reftypea.h"
#include "impl_type_attribute3reftypeb.h"
#include "impl_type_attribute4reftypeb.h"
#include "impl_type_attribute5reftypec.h"
#include "impl_type_attribute6reftyped.h"
#include "impl_type_uint32.h"

class flaverATesttestBookend2 {
 public:
  static constexpr ara::com::internal::ServiceId service_id = 0x627e;
  static constexpr ara::com::internal::ServiceVersion service_version = 0x01000000;
  static constexpr ara::core::Array<ara::core::ErrorCode, 0> requstAttributes_PossibleErrors =
  {
  };

  struct requstAttributesOutput {
    ::Attribute1ReftypeA attributes1A;
    ::Attribute1ReftypeC attributes1B;
    ::Attribute2ReftypeA attributes2A;
    ::Attribute3ReftypeB attributes3A;
    ::Attribute4ReftypeB attributes4B;
    ::Attribute5ReftypeC attributes5C;
    ::Attribute6ReftypeD attributes6D;

    using IsEnumerableTag = void;
    template<typename F>
    void enumerate(F& fun) {
      fun(attributes1A);
      fun(attributes1B);
      fun(attributes2A);
      fun(attributes3A);
      fun(attributes4B);
      fun(attributes5C);
      fun(attributes6D);
    }
  };
};


#endif // franca_sample_includes_flaveratesttestbookend2_common_h

