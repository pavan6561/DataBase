// --------------------------------------------------------------------------
// |              _    _ _______     .----.      _____         _____        |
// |         /\  | |  | |__   __|  .  ____ .    / ____|  /\   |  __ \       |
// |        /  \ | |  | |  | |    .  / __ \ .  | (___   /  \  | |__) |      |
// |       / /\ \| |  | |  | |   .  / / / / v   \___ \ / /\ \ |  _  /       |
// |      / /__\ \ |__| |  | |   . / /_/ /  .   ____) / /__\ \| | \ \       |
// |     /________\____/   |_|   ^ \____/  .   |_____/________\_|  \_\      |
// |                              . _ _  .                                  |
// --------------------------------------------------------------------------
//
// All Rights Reserved.
// Any use of this source code is subject to a license agreement with the
// AUTOSAR development cooperation.
// More information is available at www.autosar.org.
//
// Disclaimer
//
// This work (specification and/or software implementation) and the material
// contained in it, as released by AUTOSAR, is for the purpose of information
// only. AUTOSAR and the companies that have contributed to it shall not be
// liable for any use of the work.
//
// The material contained in this work is protected by copyright and other
// types of intellectual property rights. The commercial exploitation of the
// material contained in this work requires a license to such intellectual
// property rights.
//
// This work may be utilized or reproduced without any modification, in any
// form or by any means, for informational purposes only. For any other
// purpose, no part of the work may be utilized or reproduced, in any form
// or by any means, without permission in writing from the publisher.
//
// The work has been developed for automotive applications only. It has
// neither been developed, nor tested for non-automotive applications.
//
// The word AUTOSAR and the AUTOSAR logo are registered trademarks.
// --------------------------------------------------------------------------

#ifndef radar_fusion_bare_v45_vsomeip_apd_interface_errors_radar_h
#define radar_fusion_bare_v45_vsomeip_apd_interface_errors_radar_h

#include <ara/com/internal/vsomeip/vsomeip_error.h>

#include "apd/interface/radar_common.h"
namespace apd {
namespace interface {
namespace radar_binding {
namespace vsomeip {

void serializeGeneralFailure(
    const ara::com::ApplicationErrorException& error,
    std::vector<::vsomeip::byte_t>& dst)
{
    const GeneralFailure& err = static_cast<const GeneralFailure&>(error);
    ara::com::internal::vsomeip::common::error::Enumerator enumerator(dst);
    err.enumerate(enumerator);
}

std::exception_ptr deserializeGeneralFailure(
    const ::vsomeip::payload& src)
{
    ara::com::internal::vsomeip::common::Deserializer<GeneralFailure> deserializer(src.get_data(), src.get_length());
    GeneralFailure error = deserializer.getValue();
    return std::make_exception_ptr(error);
}

void serializeInvalidConfigString(
    const ara::com::ApplicationErrorException& error,
    std::vector<::vsomeip::byte_t>& dst)
{
    const InvalidConfigString& err = static_cast<const InvalidConfigString&>(error);
    ara::com::internal::vsomeip::common::error::Enumerator enumerator(dst);
    err.enumerate(enumerator);
}

std::exception_ptr deserializeInvalidConfigString(
    const ::vsomeip::payload& src)
{
    ara::com::internal::vsomeip::common::Deserializer<InvalidConfigString> deserializer(src.get_data(), src.get_length());
    InvalidConfigString error = deserializer.getValue();
    return std::make_exception_ptr(error);
}

void registerErrors()
{
    static const ara::com::internal::vsomeip::common::error::ErrorEntry<apd::interface::GeneralFailure> GeneralFailure_(
        12 & 0x3F,
        serializeGeneralFailure,
        deserializeGeneralFailure);

    static const ara::com::internal::vsomeip::common::error::ErrorEntry<apd::interface::InvalidConfigString> InvalidConfigString_(
        5 & 0x3F,
        serializeInvalidConfigString,
        deserializeInvalidConfigString);

}

} // namespace vsomeip
} // namespace radar_binding
} // namespace interface
} // namespace apd


#endif // radar_fusion_bare_v45_vsomeip_apd_interface_errors_radar_h

