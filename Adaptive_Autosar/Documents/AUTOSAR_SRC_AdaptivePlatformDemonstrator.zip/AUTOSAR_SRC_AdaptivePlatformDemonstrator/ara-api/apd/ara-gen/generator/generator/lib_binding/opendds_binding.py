#  --------------------------------------------------------------------------
#  |              _    _ _______     .----.      _____         _____        |
#  |         /\  | |  | |__   __|  .  ____ .    / ____|  /\   |  __ \       |
#  |        /  \ | |  | |  | |    .  / __ \ .  | (___   /  \  | |__) |      |
#  |       / /\ \| |  | |  | |   .  / / / / v   \___ \ / /\ \ |  _  /       |
#  |      / /__\ \ |__| |  | |   . / /_/ /  .   ____) / /__\ \| | \ \       |
#  |     /________\____/   |_|   ^ \____/  .   |_____/________\_|  \_\      |
#  |                              . _ _  .                                  |
#  --------------------------------------------------------------------------
#
#  All Rights Reserved.
#  Any use of this source code is subject to a license agreement with the
#  AUTOSAR development cooperation.
#  More information is available at www.autosar.org.
#
#  Disclaimer
#
#  This work (specification and/or software implementation) and the material
#  contained in it, as released by AUTOSAR, is for the purpose of information
#  only. AUTOSAR and the companies that have contributed to it shall not be
#  liable for any use of the work.
#
#  The material contained in this work is protected by copyright and other
#  types of intellectual property rights. The commercial exploitation of the
#  material contained in this work requires a license to such intellectual
#  property rights.
#
#  This work may be utilized or reproduced without any modification, in any
#  form or by any means, for informational purposes only. For any other
#  purpose, no part of the work may be utilized or reproduced, in any form
#  or by any means, without permission in writing from the publisher.
#
#  The work has been developed for automotive applications only. It has
#  neither been developed, nor tested for non-automotive applications.
#
#  The word AUTOSAR and the AUTOSAR logo are registered trademarks.
#  --------------------------------------------------------------------------

import os
import logging
from generator.parser.exception_handling import handle_method_exceptions
from generator.generator.datatype_container import DataTypeContainer
from generator.views.model_to_view import ViewManipulations

class OpenDdsBinding(object):
    def __init__(self, template_loader, template_renderer, output_dir) -> None:
        self._render_template = template_renderer
        self._load_template = template_loader
        self._output_dir = output_dir
        self._log = logging.getLogger(__name__)

    @property
    def opendds_root_dir(self):
        return os.path.join(self._output_dir, 'opendds')


    @handle_method_exceptions(error_string_template="idls generation ERROR: {exception_text}")
    def generate_idls(self, services):
        idl_types_template = self._load_template("opendds_binding/dds_idl_types.j2", trim_blocks=True)
        idl_services_template = self._load_template("opendds_binding/dds_idl_services.j2", trim_blocks=True)

        type_views = set()
        for service in services:
            data_types = DataTypeContainer(service)
            t = set(data_types.types)
            type_views = type_views.union(t)

        structures = list(filter(
            lambda x: ViewManipulations.get_view_kind(x) == 'structure',
            type_views))
        enums = list(filter(
            lambda x: ViewManipulations.get_view_kind(x) == 'enum',
            type_views))
        maps = list(filter(
            lambda x: ViewManipulations.get_view_kind(x) == 'map',
            type_views))
        vectors = list(filter(
            lambda x: ViewManipulations.get_view_kind(x) == 'vector',
            type_views))
        arrays = list(filter(
            lambda x: ViewManipulations.get_view_kind(x) == 'array',
            type_views))
        aliased_impltypes = list(filter(
            lambda x: ViewManipulations.get_view_kind(x) == 'aliased_impltype',
            type_views))
        aliased_basetypes = list(filter(
            lambda x: ViewManipulations.get_view_kind(x) == 'aliased_basetype',
            type_views))
        strings = list(filter(
            lambda x: ViewManipulations.get_view_kind(x) == 'string',
            type_views))
        basetypes = list(filter(
            lambda x: ViewManipulations.get_view_kind(x) == 'basetype',
            type_views))


        self._render_template(idl_types_template, self.opendds_root_dir, "types.idl",
            structures=sorted(structures),
            enums=sorted(enums),
            maps=sorted(maps),
            vectors=sorted(vectors),
            arrays=sorted(arrays),
            aliased_impltypes=sorted(aliased_impltypes),
            aliased_basetypes=sorted(aliased_basetypes),
            strings=sorted(strings),
            basetypes=sorted(basetypes))

        self._render_template(idl_services_template, self.opendds_root_dir, "services.idl",
            services=sorted(services))
