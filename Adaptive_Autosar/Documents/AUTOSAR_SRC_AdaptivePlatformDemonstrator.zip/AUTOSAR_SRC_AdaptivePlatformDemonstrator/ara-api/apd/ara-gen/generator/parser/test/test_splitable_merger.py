#  --------------------------------------------------------------------------
#  |              _    _ _______     .----.      _____         _____        |
#  |         /\  | |  | |__   __|  .  ____ .    / ____|  /\   |  __ \       |
#  |        /  \ | |  | |  | |    .  / __ \ .  | (___   /  \  | |__) |      |
#  |       / /\ \| |  | |  | |   .  / / / / v   \___ \ / /\ \ |  _  /       |
#  |      / /__\ \ |__| |  | |   . / /_/ /  .   ____) / /__\ \| | \ \       |
#  |     /________\____/   |_|   ^ \____/  .   |_____/________\_|  \_\      |
#  |                              . _ _  .                                  |
#  --------------------------------------------------------------------------
#
#  All Rights Reserved.
#  Any use of this source code is subject to a license agreement with the
#  AUTOSAR development cooperation.
#  More information is available at www.autosar.org.
#
#  Disclaimer
#
#  This work (specification and/or software implementation) and the material
#  contained in it, as released by AUTOSAR, is for the purpose of information
#  only. AUTOSAR and the companies that have contributed to it shall not be
#  liable for any use of the work.
#
#  The material contained in this work is protected by copyright and other
#  types of intellectual property rights. The commercial exploitation of the
#  material contained in this work requires a license to such intellectual
#  property rights.
#
#  This work may be utilized or reproduced without any modification, in any
#  form or by any means, for informational purposes only. For any other
#  purpose, no part of the work may be utilized or reproduced, in any form
#  or by any means, without permission in writing from the publisher.
#
#  The work has been developed for automotive applications only. It has
#  neither been developed, nor tested for non-automotive applications.
#
#  The word AUTOSAR and the AUTOSAR logo are registered trademarks.
#  --------------------------------------------------------------------------

"""
Intermediate model tests.
"""

import unittest
import os
import tempfile

from generator.parser.parser import Parser
from generator.parser.merge import merge_files
from generator.parser.merge import to_string
import generator.parser


class SplitableMergerTest(unittest.TestCase):
    """
    Testing Splitable merging.
    """
    # pylint: disable=R0902
    # - too many instance attributes
    # pylint: disable=W0201
    # - attributes not initialised in __init__

    # Various utilities

    def init_types(self):
        """Init types model paths."""
        self.init_impl_types()
        self.init_base_types()
        self.ints = self.impl_ints + self.base_ints
        self.uints = self.impl_uints + self.base_uints
        self.booleans = self.impl_boolean + self.base_boolean
        self.floats = self.impl_floats + self.base_floats

    def init_impl_types(self):
        """Init ImplementationDataType model paths."""
        prefix = 'ara/stdtypes/{}'
        self.impl_boolean = [prefix.format('Boolean')]
        self.impl_ints = [prefix.format(e) for e in ['Int8', 'Int16', 'Int32']]
        self.impl_uints = [prefix.format(e) for e in ['UInt8', 'UInt16', 'UInt32']]
        self.impl_floats = [prefix.format(e) for e in ['Float', 'Double']]
        self.impl_bytearray = [prefix.format('ByteArray')]
        self.impl_string = [prefix.format('String')]

    def init_base_types(self):
        """Init BaseType model paths."""
        prefix = 'ara/stdtypes/{}'
        self.base_boolean = [prefix.format('cpp_bool')]
        self.base_ints = [prefix.format(e) for e in ['std_int8_t', 'std_int16_t', 'std_int32_t']]
        self.base_uints = [prefix.format(e) for e in ['std_uint8_t', 'std_uint16_t', 'std_uint32_t']]
        self.base_floats = [prefix.format(e) for e in ['cpp_float', 'cpp_double']]

    def init_service(self):
        """Init service-related data."""
        prefix_interface = 'com/da/{}'
        self.service_interface = [prefix_interface.format('radar')]

        prefix_errors = 'RadarFusionErrors/{}'
        self.app_error_generic_failure = [prefix_errors.format('GenericFailure')]
        self.app_error_invalid_config_string = [prefix_errors.format('InvalidConfigString')]
        self.app_errors = self.app_error_generic_failure + self.app_error_invalid_config_string

    def check_presence(self, tree, present, absent):
        """Check for present/absent elements in tree."""
        for element in present:
            self.assertIn(element, tree)
        for element in absent:
            self.assertNotIn(element, tree)

    def check_memory_and_file(self, merged, present, absent):
        """Check in memory and file-based content for present/absent elements."""
        merged.write(self.out_file.name, encoding=generator.parser.TEXT_ENCODING)
        memory = self.parser.parse(to_string(merged), False)
        disk = self.parser.parse(self.out_file.name, False)
        for content in [memory, disk]:
            self.check_presence(content, present, absent)

    # Tests part

    def setUp(self):
        """
        Setup Method for all tests in this class
        """
        self.test_output_dir = tempfile.TemporaryDirectory()
        self.file_directory = os.path.dirname(os.path.realpath(__file__))
        self.model_files = [os.path.join(self.file_directory, 'data',
                                         'radarfusion{}.arxml'.format(i)) for i in range(3)]
        self.parser = Parser()
        self.out_file = tempfile.NamedTemporaryFile(mode='a+', encoding=generator.parser.TEXT_ENCODING, delete=False)
        self.init_types()
        self.init_service()

    def test_merge_one_file(self):
        """Merge a single file."""
        present = self.booleans
        absent = self.ints + self.uints + self.floats + self.impl_bytearray + self.impl_string + self.service_interface
        merged = merge_files([self.model_files[2]])
        self.check_memory_and_file(merged, present, absent)

    def test_merge_two_files(self):
        """Merge two files."""
        present = self.ints + self.uints + self.floats + self.impl_bytearray + self.impl_string +\
            self.service_interface + self.app_errors
        absent = self.booleans
        merged = merge_files(self.model_files[:2])
        self.check_memory_and_file(merged, present, absent)

    def test_merge_three_files(self):
        """Merge three files."""
        present = self.booleans + self.ints + self.uints + self.floats + self.impl_bytearray + self.impl_string + \
            self.service_interface + self.app_errors
        absent = []
        merged = merge_files(self.model_files[:3])
        self.check_memory_and_file(merged, present, absent)

    def test_non_splitable(self):
        """Ensure that non-splitable elements are not merged"""
        merged = merge_files([self.model_files[2]])
        root = merged.getroot()
        compu_scales = root.findall('.//{http://autosar.org/schema/r4.0}COMPU-SCALE')

        self.assertEqual(len(compu_scales), 4, "Should be four distinct COMPU-SCALE")

    def test_merge_first_last(self):
        """Merge first and last files."""
        present = self.booleans + self.ints + self.floats + self.impl_bytearray + self.impl_string + \
            self.service_interface + self.app_error_generic_failure
        absent = self.uints + self.app_error_invalid_config_string
        merged = merge_files([self.model_files[0], self.model_files[2]])
        self.check_memory_and_file(merged, present, absent)

    def tearDown(self):
        self.test_output_dir.cleanup()
        self.out_file.close()
        os.unlink(self.out_file.name)
