// --------------------------------------------------------------------------
// |              _    _ _______     .----.      _____         _____        |
// |         /\  | |  | |__   __|  .  ____ .    / ____|  /\   |  __ \       |
// |        /  \ | |  | |  | |    .  / __ \ .  | (___   /  \  | |__) |      |
// |       / /\ \| |  | |  | |   .  / / / / v   \___ \ / /\ \ |  _  /       |
// |      / /__\ \ |__| |  | |   . / /_/ /  .   ____) / /__\ \| | \ \       |
// |     /________\____/   |_|   ^ \____/  .   |_____/________\_|  \_\      |
// |                              . _ _  .                                  |
// --------------------------------------------------------------------------
//
// All Rights Reserved.
// Any use of this source code is subject to a license agreement with the
// AUTOSAR development cooperation.
// More information is available at www.autosar.org.
//
// Disclaimer
//
// This work (specification and/or software implementation) and the material
// contained in it, as released by AUTOSAR, is for the purpose of information
// only. AUTOSAR and the companies that have contributed to it shall not be
// liable for any use of the work.
//
// The material contained in this work is protected by copyright and other
// types of intellectual property rights. The commercial exploitation of the
// material contained in this work requires a license to such intellectual
// property rights.
//
// This work may be utilized or reproduced without any modification, in any
// form or by any means, for informational purposes only. For any other
// purpose, no part of the work may be utilized or reproduced, in any form
// or by any means, without permission in writing from the publisher.
//
// The work has been developed for automotive applications only. It has
// neither been developed, nor tested for non-automotive applications.
//
// The word AUTOSAR and the AUTOSAR logo are registered trademarks.
// --------------------------------------------------------------------------

#ifndef franca_sample_vsomeip_adapter_flaverbtesttestbookend2_h
#define franca_sample_vsomeip_adapter_flaverbtesttestbookend2_h

#include "ara/com/internal/vsomeip/skeleton/vsomeip_skeleton_base.h"
#include "service_desc_flaverbtesttestbookend2.h"
#include "/flaverbtesttestbookend2_skeleton.h"

namespace flaverbtesttestbookend2_binding {
namespace vsomeip {

class flaverBTesttestBookend2ServiceAdapter : public ::ara::com::internal::vsomeip::skeleton::ServiceImplBase {
 public:
  using ServiceInterface = skeleton::flaverBTesttestBookend2Skeleton;
  using ServiceDescriptor = descriptors::internal::Service;

  flaverBTesttestBookend2ServiceAdapter(ServiceInterface& service, ara::com::internal::InstanceId instance) :
    ::ara::com::internal::vsomeip::skeleton::ServiceImplBase(service, instance),
    input1(instance),
    input2(instance),
    attributeResponse1(instance),
    attributeResponse2(instance),
    attributeResponse3(instance),
    attributeResponse4(instance),
    attributeResponse5(instance),
    attributeResponse6(instance),
    attributeResponse7(instance) {
    Connect(service);
    RegisterMethodDispatcher(ServiceDescriptor::service_id,
                             [this](const std::shared_ptr<::vsomeip::message>& msg) { DispatchMethodCall(msg); });
    OfferService(ServiceDescriptor::service_id, GetInstanceId(), ServiceDescriptor::service_version, ServiceDescriptor::minor_service_version);
    OfferEvent(ServiceDescriptor::service_id, GetInstanceId(), descriptors::attributeResponse1::event_id, descriptors::attributeResponse1::event_groups);
    OfferEvent(ServiceDescriptor::service_id, GetInstanceId(), descriptors::attributeResponse2::event_id, descriptors::attributeResponse2::event_groups);
    OfferEvent(ServiceDescriptor::service_id, GetInstanceId(), descriptors::attributeResponse3::event_id, descriptors::attributeResponse3::event_groups);
    OfferEvent(ServiceDescriptor::service_id, GetInstanceId(), descriptors::attributeResponse4::event_id, descriptors::attributeResponse4::event_groups);
    OfferEvent(ServiceDescriptor::service_id, GetInstanceId(), descriptors::attributeResponse5::event_id, descriptors::attributeResponse5::event_groups);
    OfferEvent(ServiceDescriptor::service_id, GetInstanceId(), descriptors::attributeResponse6::event_id, descriptors::attributeResponse6::event_groups);
    OfferEvent(ServiceDescriptor::service_id, GetInstanceId(), descriptors::attributeResponse7::event_id, descriptors::attributeResponse7::event_groups);
    OfferField(ServiceDescriptor::service_id, GetInstanceId(), descriptors::input1::event_id, descriptors::input1::event_groups);
    OfferField(ServiceDescriptor::service_id, GetInstanceId(), descriptors::input2::event_id, descriptors::input2::event_groups);
  }

  virtual ~flaverBTesttestBookend2ServiceAdapter() {
    StopOfferEvent(descriptors::attributeResponse1::service_id, GetInstanceId(), descriptors::attributeResponse1::event_id);
    StopOfferEvent(descriptors::attributeResponse2::service_id, GetInstanceId(), descriptors::attributeResponse2::event_id);
    StopOfferEvent(descriptors::attributeResponse3::service_id, GetInstanceId(), descriptors::attributeResponse3::event_id);
    StopOfferEvent(descriptors::attributeResponse4::service_id, GetInstanceId(), descriptors::attributeResponse4::event_id);
    StopOfferEvent(descriptors::attributeResponse5::service_id, GetInstanceId(), descriptors::attributeResponse5::event_id);
    StopOfferEvent(descriptors::attributeResponse6::service_id, GetInstanceId(), descriptors::attributeResponse6::event_id);
    StopOfferEvent(descriptors::attributeResponse7::service_id, GetInstanceId(), descriptors::attributeResponse7::event_id);
    StopOfferField(descriptors::input1::service_id, GetInstanceId(), descriptors::input1::event_id);
    StopOfferField(descriptors::input2::service_id, GetInstanceId(), descriptors::input2::event_id);
    StopOfferService(ServiceDescriptor::service_id, GetInstanceId());
    UnregisterMethodDispatcher(ServiceDescriptor::service_id);
    Disconnect(dynamic_cast<ServiceInterface&>(service_));
  }
 protected:
  void DispatchMethodCall(const std::shared_ptr<::vsomeip::message>& msg) {
    ServiceInterface& service = dynamic_cast<ServiceInterface&>(service_);
    switch(msg->get_method()) {
      case descriptors::requstAttributes::method_id:
        HandleCall(service, &ServiceInterface::requstAttributes, msg);
        break;
    }
  }

 private:
  void Connect(ServiceInterface& service) {
    service.AddDelegate(*this);
    service.input1.AddDelegate(input1);
    service.input2.AddDelegate(input2);
    service.attributeResponse1.AddDelegate(attributeResponse1);
    service.attributeResponse2.AddDelegate(attributeResponse2);
    service.attributeResponse3.AddDelegate(attributeResponse3);
    service.attributeResponse4.AddDelegate(attributeResponse4);
    service.attributeResponse5.AddDelegate(attributeResponse5);
    service.attributeResponse6.AddDelegate(attributeResponse6);
    service.attributeResponse7.AddDelegate(attributeResponse7);
  }

  void Disconnect(ServiceInterface& service) {
    service.RemoveDelegate(*this);
    service.input1.RemoveDelegate(input1);
    service.input2.RemoveDelegate(input2);
    service.attributeResponse1.RemoveDelegate(attributeResponse1);
    service.attributeResponse2.RemoveDelegate(attributeResponse2);
    service.attributeResponse3.RemoveDelegate(attributeResponse3);
    service.attributeResponse4.RemoveDelegate(attributeResponse4);
    service.attributeResponse5.RemoveDelegate(attributeResponse5);
    service.attributeResponse6.RemoveDelegate(attributeResponse6);
    service.attributeResponse7.RemoveDelegate(attributeResponse7);
  }

  ara::com::internal::vsomeip::skeleton::MutableFieldImpl<::Int32, descriptors::input1> input1;
  ara::com::internal::vsomeip::skeleton::MutableFieldImpl<::Int32, descriptors::input2> input2;
  ara::com::internal::vsomeip::skeleton::EventImpl<::attributeResponse1Struct, descriptors::attributeResponse1> attributeResponse1;
  ara::com::internal::vsomeip::skeleton::EventImpl<::attributeResponse2Struct, descriptors::attributeResponse2> attributeResponse2;
  ara::com::internal::vsomeip::skeleton::EventImpl<::attributeResponse3Struct, descriptors::attributeResponse3> attributeResponse3;
  ara::com::internal::vsomeip::skeleton::EventImpl<::attributeResponse4Struct, descriptors::attributeResponse4> attributeResponse4;
  ara::com::internal::vsomeip::skeleton::EventImpl<::attributeResponse5Struct, descriptors::attributeResponse5> attributeResponse5;
  ara::com::internal::vsomeip::skeleton::EventImpl<::attributeResponse6Struct, descriptors::attributeResponse6> attributeResponse6;
  ara::com::internal::vsomeip::skeleton::EventImpl<::attributeResponse7Struct, descriptors::attributeResponse7> attributeResponse7;
};

} // namespace vsomeip
} // namespace flaverbtesttestbookend2_binding

#endif // franca_sample_vsomeip_adapter_flaverbtesttestbookend2_h

