// --------------------------------------------------------------------------
// |              _    _ _______     .----.      _____         _____        |
// |         /\  | |  | |__   __|  .  ____ .    / ____|  /\   |  __ \       |
// |        /  \ | |  | |  | |    .  / __ \ .  | (___   /  \  | |__) |      |
// |       / /\ \| |  | |  | |   .  / / / / v   \___ \ / /\ \ |  _  /       |
// |      / /__\ \ |__| |  | |   . / /_/ /  .   ____) / /__\ \| | \ \       |
// |     /________\____/   |_|   ^ \____/  .   |_____/________\_|  \_\      |
// |                              . _ _  .                                  |
// --------------------------------------------------------------------------
//
// All Rights Reserved.
// Any use of this source code is subject to a license agreement with the
// AUTOSAR development cooperation.
// More information is available at www.autosar.org.
//
// Disclaimer
//
// This work (specification and/or software implementation) and the material
// contained in it, as released by AUTOSAR, is for the purpose of information
// only. AUTOSAR and the companies that have contributed to it shall not be
// liable for any use of the work.
//
// The material contained in this work is protected by copyright and other
// types of intellectual property rights. The commercial exploitation of the
// material contained in this work requires a license to such intellectual
// property rights.
//
// This work may be utilized or reproduced without any modification, in any
// form or by any means, for informational purposes only. For any other
// purpose, no part of the work may be utilized or reproduced, in any form
// or by any means, without permission in writing from the publisher.
//
// The work has been developed for automotive applications only. It has
// neither been developed, nor tested for non-automotive applications.
//
// The word AUTOSAR and the AUTOSAR logo are registered trademarks.
// --------------------------------------------------------------------------

#ifndef radar_fusion_extended_proloc_bosch_da_proloc_proxy_radar_h
#define radar_fusion_extended_proloc_bosch_da_proloc_proxy_radar_h

#include <memory>
#include "ara/com/internal/proloc/proxy/proloc_proxy_base.h"
#include "proloc_service_desc_radar.h"
#include "bosch/da/radar_proxy.h"

namespace bosch {
namespace da {
namespace radar_binding {
namespace proloc {

class radarImpl : public
                      proxy::radarProxyBase, public
                      ::ara::com::internal::proloc::proxy::ProxyImplBase {
 public:
 using ServiceBase = ::ara::com::internal::proloc::skeleton::ServiceImplBase;

  radarImpl(std::weak_ptr<ServiceBase> service, ::ara::com::internal::InstanceId instance) :
 ::ara::com::internal::proloc::proxy::ProxyImplBase(service, instance),
      UpdateRate(service),
      FrontObjectDistance(service),
      RearObjectDistance(service),
      ObjectDetectionLimit(service),
      brakeEvent(service),
      parkingBrakeEvent(service),
      driveEvent(service),
      Adjust(service),
      Calibrate(service) {}

  virtual ~radarImpl() {}

  virtual proxy::fields::UpdateRateField& GetUpdateRate() override { return UpdateRate; }
  virtual proxy::fields::FrontObjectDistanceField& GetFrontObjectDistance() override { return FrontObjectDistance; }
  virtual proxy::fields::RearObjectDistanceField& GetRearObjectDistance() override { return RearObjectDistance; }
  virtual proxy::fields::ObjectDetectionLimitField& GetObjectDetectionLimit() override { return ObjectDetectionLimit; }
  virtual proxy::events::brakeEvent& GetbrakeEvent() override { return brakeEvent; }
  virtual proxy::events::parkingBrakeEvent& GetparkingBrakeEvent() override { return parkingBrakeEvent; }
  virtual proxy::events::driveEvent& GetdriveEvent() override { return driveEvent; }
  virtual bosch::da::proxy::methods::Adjust& GetAdjust() override { return Adjust; }
  virtual bosch::da::proxy::methods::Calibrate& GetCalibrate() override { return Calibrate; }

 private:
  ara::com::internal::proloc::proxy::MutableFieldImpl<descriptors::UpdateRate, ::UInt32> UpdateRate;
  ara::com::internal::proloc::proxy::FieldImpl<descriptors::FrontObjectDistance, ::UInt16> FrontObjectDistance;
  ara::com::internal::proloc::proxy::FieldImpl<descriptors::RearObjectDistance, ::UInt16> RearObjectDistance;
  ara::com::internal::proloc::proxy::MutableFieldImpl<descriptors::ObjectDetectionLimit, ::UInt16> ObjectDetectionLimit;
  ara::com::internal::proloc::proxy::EventImpl<descriptors::brakeEvent, ::RadarObjects> brakeEvent;
  ara::com::internal::proloc::proxy::EventImpl<descriptors::parkingBrakeEvent, ::RadarObjects> parkingBrakeEvent;
  ara::com::internal::proloc::proxy::EventImpl<descriptors::driveEvent, ::RadarObjects> driveEvent;
  ara::com::internal::proloc::proxy::MethodImpl<descriptors::Adjust, bosch::da::proxy::methods::Adjust::signature_type> Adjust;
  ara::com::internal::proloc::proxy::MethodImpl<descriptors::Calibrate, bosch::da::proxy::methods::Calibrate::signature_type> Calibrate;
};

} // namespace proloc
} // namespace radar_binding
} // namespace da
} // namespace bosch

#endif // radar_fusion_extended_proloc_bosch_da_proloc_proxy_radar_h

