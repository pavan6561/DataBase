// --------------------------------------------------------------------------
// |              _    _ _______     .----.      _____         _____        |
// |         /\  | |  | |__   __|  .  ____ .    / ____|  /\   |  __ \       |
// |        /  \ | |  | |  | |    .  / __ \ .  | (___   /  \  | |__) |      |
// |       / /\ \| |  | |  | |   .  / / / / v   \___ \ / /\ \ |  _  /       |
// |      / /__\ \ |__| |  | |   . / /_/ /  .   ____) / /__\ \| | \ \       |
// |     /________\____/   |_|   ^ \____/  .   |_____/________\_|  \_\      |
// |                              . _ _  .                                  |
// --------------------------------------------------------------------------
//
// All Rights Reserved.
// Any use of this source code is subject to a license agreement with the
// AUTOSAR development cooperation.
// More information is available at www.autosar.org.
//
// Disclaimer
//
// This work (specification and/or software implementation) and the material
// contained in it, as released by AUTOSAR, is for the purpose of information
// only. AUTOSAR and the companies that have contributed to it shall not be
// liable for any use of the work.
//
// The material contained in this work is protected by copyright and other
// types of intellectual property rights. The commercial exploitation of the
// material contained in this work requires a license to such intellectual
// property rights.
//
// This work may be utilized or reproduced without any modification, in any
// form or by any means, for informational purposes only. For any other
// purpose, no part of the work may be utilized or reproduced, in any form
// or by any means, without permission in writing from the publisher.
//
// The work has been developed for automotive applications only. It has
// neither been developed, nor tested for non-automotive applications.
//
// The word AUTOSAR and the AUTOSAR logo are registered trademarks.
// --------------------------------------------------------------------------

#ifndef franca_sample_includes_flaverbtesttestbookend2_skeleton_h
#define franca_sample_includes_flaverbtesttestbookend2_skeleton_h

#include "ara/com/internal/skeleton/ara_skeleton_base.h"

#include "ara/com/illegal_state_exception.h"
#include "flaverbtesttestbookend2_common.h"

namespace skeleton {

namespace fields {
  /// @uptrace{SWS_CM_00007}
  using input1 = ara::com::internal::skeleton::MutableFieldDispatcher<::Int32>;
  using input2 = ara::com::internal::skeleton::MutableFieldDispatcher<::Int32>;
} // namespace fields

namespace events {
  /// @uptrace{SWS_CM_00003}
  using attributeResponse1 = ara::com::internal::skeleton::EventDispatcher<::attributeResponse1Struct>;
  using attributeResponse2 = ara::com::internal::skeleton::EventDispatcher<::attributeResponse2Struct>;
  using attributeResponse3 = ara::com::internal::skeleton::EventDispatcher<::attributeResponse3Struct>;
  using attributeResponse4 = ara::com::internal::skeleton::EventDispatcher<::attributeResponse4Struct>;
  using attributeResponse5 = ara::com::internal::skeleton::EventDispatcher<::attributeResponse5Struct>;
  using attributeResponse6 = ara::com::internal::skeleton::EventDispatcher<::attributeResponse6Struct>;
  using attributeResponse7 = ara::com::internal::skeleton::EventDispatcher<::attributeResponse7Struct>;
} // namespace events

/// @uptrace{SWS_CM_00002}
class flaverBTesttestBookend2Skeleton : public ::flaverBTesttestBookend2, public ara::com::internal::skeleton::TypedServiceImplBase<flaverBTesttestBookend2Skeleton> {
public:
  /// @uptrace{SWS_CM_00130}
  flaverBTesttestBookend2Skeleton(ara::com::InstanceIdentifier instance_id, ara::com::MethodCallProcessingMode mode = ara::com::MethodCallProcessingMode::kEvent) : ara::com::internal::skeleton::TypedServiceImplBase<flaverBTesttestBookend2Skeleton>(instance_id, mode) {}
  virtual ~flaverBTesttestBookend2Skeleton() {
    StopOfferService();
  }

  /// @brief Skeleton shall be move constructable.
  ///
  /// @uptrace{SWS_CM_00135}
  explicit flaverBTesttestBookend2Skeleton(flaverBTesttestBookend2Skeleton&&) = default;

  /// @brief Skeleton shall be move assignable.
  ///
  /// @uptrace{SWS_CM_00135}
  flaverBTesttestBookend2Skeleton& operator=(flaverBTesttestBookend2Skeleton&&) = default;

  /// @brief Skeleton shall not be copy constructable.
  ///
  /// @uptrace{SWS_CM_00134}
  explicit flaverBTesttestBookend2Skeleton(const flaverBTesttestBookend2Skeleton&) = delete;

  /// @brief Skeleton shall not be copy assignable.
  ///
  /// @uptrace{SWS_CM_00134}
  flaverBTesttestBookend2Skeleton& operator=(const flaverBTesttestBookend2Skeleton&) = delete;

  void OfferService() {
    if(!input1.IsInitialized()) {
      throw ara::com::IllegalStateException("Attempt to offer service \"/test/serviceinterfaces/flaverBTesttestBookend2\" with uninitialized field \"input1\"");
    }
    if(!input2.IsInitialized()) {
      throw ara::com::IllegalStateException("Attempt to offer service \"/test/serviceinterfaces/flaverBTesttestBookend2\" with uninitialized field \"input2\"");
    }

    ara::com::internal::skeleton::TypedServiceImplBase<flaverBTesttestBookend2Skeleton>::OfferService();
  }

  /// @uptrace{SWS_CM_00191}
  using ::flaverBTesttestBookend2::requstAttributesOutput;
  virtual ara::core::Future<requstAttributesOutput> requstAttributes(const ::UInt32& edgesOfIterest) = 0;
  fields::input1 input1;
  fields::input2 input2;
  events::attributeResponse1 attributeResponse1;
  events::attributeResponse2 attributeResponse2;
  events::attributeResponse3 attributeResponse3;
  events::attributeResponse4 attributeResponse4;
  events::attributeResponse5 attributeResponse5;
  events::attributeResponse6 attributeResponse6;
  events::attributeResponse7 attributeResponse7;
};

} // namespace skeleton

#endif // franca_sample_includes_flaverbtesttestbookend2_skeleton_h

