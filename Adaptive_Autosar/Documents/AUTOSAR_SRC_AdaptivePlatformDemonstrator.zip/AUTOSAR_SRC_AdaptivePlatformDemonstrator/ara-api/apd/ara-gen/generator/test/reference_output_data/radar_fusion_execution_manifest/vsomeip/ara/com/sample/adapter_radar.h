// --------------------------------------------------------------------------
// |              _    _ _______     .----.      _____         _____        |
// |         /\  | |  | |__   __|  .  ____ .    / ____|  /\   |  __ \       |
// |        /  \ | |  | |  | |    .  / __ \ .  | (___   /  \  | |__) |      |
// |       / /\ \| |  | |  | |   .  / / / / v   \___ \ / /\ \ |  _  /       |
// |      / /__\ \ |__| |  | |   . / /_/ /  .   ____) / /__\ \| | \ \       |
// |     /________\____/   |_|   ^ \____/  .   |_____/________\_|  \_\      |
// |                              . _ _  .                                  |
// --------------------------------------------------------------------------
//
// All Rights Reserved.
// Any use of this source code is subject to a license agreement with the
// AUTOSAR development cooperation.
// More information is available at www.autosar.org.
//
// Disclaimer
//
// This work (specification and/or software implementation) and the material
// contained in it, as released by AUTOSAR, is for the purpose of information
// only. AUTOSAR and the companies that have contributed to it shall not be
// liable for any use of the work.
//
// The material contained in this work is protected by copyright and other
// types of intellectual property rights. The commercial exploitation of the
// material contained in this work requires a license to such intellectual
// property rights.
//
// This work may be utilized or reproduced without any modification, in any
// form or by any means, for informational purposes only. For any other
// purpose, no part of the work may be utilized or reproduced, in any form
// or by any means, without permission in writing from the publisher.
//
// The work has been developed for automotive applications only. It has
// neither been developed, nor tested for non-automotive applications.
//
// The word AUTOSAR and the AUTOSAR logo are registered trademarks.
// --------------------------------------------------------------------------

#ifndef radar_fusion_execution_manifest_vsomeip_ara_com_sample_adapter_radar_h
#define radar_fusion_execution_manifest_vsomeip_ara_com_sample_adapter_radar_h

#include "ara/com/internal/vsomeip/skeleton/vsomeip_skeleton_base.h"
#include "service_desc_radar.h"
#include "ara/com/sample/radar_skeleton.h"

namespace ara {
namespace com {
namespace sample {
namespace radar_binding {
namespace vsomeip {

class radarServiceAdapter : public ::ara::com::internal::vsomeip::skeleton::ServiceImplBase {
 public:
  using ServiceInterface = skeleton::radarSkeleton;
  using ServiceDescriptor = descriptors::internal::Service;

  radarServiceAdapter(ServiceInterface& service, ara::com::internal::InstanceId instance) :
    ::ara::com::internal::vsomeip::skeleton::ServiceImplBase(service, instance),
    UpdateRate(instance),
    FrontObjectDistance(instance),
    RearObjectDistance(instance),
    ObjectDetectionLimit(instance),
    brakeEvent(instance),
    parkingBrakeEvent(instance) {
    Connect(service);
    RegisterMethodDispatcher(ServiceDescriptor::service_id,
                             [this](const std::shared_ptr<::vsomeip::message>& msg) { DispatchMethodCall(msg); });
    OfferService(ServiceDescriptor::service_id, GetInstanceId(), ServiceDescriptor::service_version, ServiceDescriptor::minor_service_version);
    OfferEvent(ServiceDescriptor::service_id, GetInstanceId(), descriptors::brakeEvent::event_id, descriptors::brakeEvent::event_groups);
    OfferEvent(ServiceDescriptor::service_id, GetInstanceId(), descriptors::parkingBrakeEvent::event_id, descriptors::parkingBrakeEvent::event_groups);
    OfferField(ServiceDescriptor::service_id, GetInstanceId(), descriptors::UpdateRate::event_id, descriptors::UpdateRate::event_groups);
    OfferField(ServiceDescriptor::service_id, GetInstanceId(), descriptors::FrontObjectDistance::event_id, descriptors::FrontObjectDistance::event_groups);
    OfferField(ServiceDescriptor::service_id, GetInstanceId(), descriptors::RearObjectDistance::event_id, descriptors::RearObjectDistance::event_groups);
    OfferField(ServiceDescriptor::service_id, GetInstanceId(), descriptors::ObjectDetectionLimit::event_id, descriptors::ObjectDetectionLimit::event_groups);
  }

  virtual ~radarServiceAdapter() {
    StopOfferEvent(descriptors::brakeEvent::service_id, GetInstanceId(), descriptors::brakeEvent::event_id);
    StopOfferEvent(descriptors::parkingBrakeEvent::service_id, GetInstanceId(), descriptors::parkingBrakeEvent::event_id);
    StopOfferField(descriptors::UpdateRate::service_id, GetInstanceId(), descriptors::UpdateRate::event_id);
    StopOfferField(descriptors::FrontObjectDistance::service_id, GetInstanceId(), descriptors::FrontObjectDistance::event_id);
    StopOfferField(descriptors::RearObjectDistance::service_id, GetInstanceId(), descriptors::RearObjectDistance::event_id);
    StopOfferField(descriptors::ObjectDetectionLimit::service_id, GetInstanceId(), descriptors::ObjectDetectionLimit::event_id);
    StopOfferService(ServiceDescriptor::service_id, GetInstanceId());
    UnregisterMethodDispatcher(ServiceDescriptor::service_id);
    Disconnect(dynamic_cast<ServiceInterface&>(service_));
  }
 protected:
  void DispatchMethodCall(const std::shared_ptr<::vsomeip::message>& msg) {
    ServiceInterface& service = dynamic_cast<ServiceInterface&>(service_);
    switch(msg->get_method()) {
      case descriptors::Adjust::method_id:
        HandleCall(service, &ServiceInterface::Adjust, msg);
        break;
      case descriptors::Calibrate::method_id:
        HandleCall(service, &ServiceInterface::Calibrate, msg);
        break;
    }
  }

 private:
  void Connect(ServiceInterface& service) {
    service.AddDelegate(*this);
    service.UpdateRate.AddDelegate(UpdateRate);
    service.FrontObjectDistance.AddDelegate(FrontObjectDistance);
    service.RearObjectDistance.AddDelegate(RearObjectDistance);
    service.ObjectDetectionLimit.AddDelegate(ObjectDetectionLimit);
    service.brakeEvent.AddDelegate(brakeEvent);
    service.parkingBrakeEvent.AddDelegate(parkingBrakeEvent);
  }

  void Disconnect(ServiceInterface& service) {
    service.RemoveDelegate(*this);
    service.UpdateRate.RemoveDelegate(UpdateRate);
    service.FrontObjectDistance.RemoveDelegate(FrontObjectDistance);
    service.RearObjectDistance.RemoveDelegate(RearObjectDistance);
    service.ObjectDetectionLimit.RemoveDelegate(ObjectDetectionLimit);
    service.brakeEvent.RemoveDelegate(brakeEvent);
    service.parkingBrakeEvent.RemoveDelegate(parkingBrakeEvent);
  }

  ara::com::internal::vsomeip::skeleton::MutableFieldImpl<std::uint32_t, descriptors::UpdateRate> UpdateRate;
  ara::com::internal::vsomeip::skeleton::FieldImpl<std::uint16_t, descriptors::FrontObjectDistance> FrontObjectDistance;
  ara::com::internal::vsomeip::skeleton::FieldImpl<std::uint16_t, descriptors::RearObjectDistance> RearObjectDistance;
  ara::com::internal::vsomeip::skeleton::MutableFieldImpl<std::uint16_t, descriptors::ObjectDetectionLimit> ObjectDetectionLimit;
  ara::com::internal::vsomeip::skeleton::EventImpl<::ara::com::sample::RadarObjects, descriptors::brakeEvent> brakeEvent;
  ara::com::internal::vsomeip::skeleton::EventImpl<::ara::com::sample::RadarObjects, descriptors::parkingBrakeEvent> parkingBrakeEvent;
};

} // namespace vsomeip
} // namespace radar_binding
} // namespace sample
} // namespace com
} // namespace ara

#endif // radar_fusion_execution_manifest_vsomeip_ara_com_sample_adapter_radar_h

