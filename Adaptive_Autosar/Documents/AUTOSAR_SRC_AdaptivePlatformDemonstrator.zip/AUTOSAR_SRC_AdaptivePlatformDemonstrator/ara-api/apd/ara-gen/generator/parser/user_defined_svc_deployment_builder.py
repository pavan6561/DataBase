#  --------------------------------------------------------------------------
#  |              _    _ _______     .----.      _____         _____        |
#  |         /\  | |  | |__   __|  .  ____ .    / ____|  /\   |  __ \       |
#  |        /  \ | |  | |  | |    .  / __ \ .  | (___   /  \  | |__) |      |
#  |       / /\ \| |  | |  | |   .  / / / / v   \___ \ / /\ \ |  _  /       |
#  |      / /__\ \ |__| |  | |   . / /_/ /  .   ____) / /__\ \| | \ \       |
#  |     /________\____/   |_|   ^ \____/  .   |_____/________\_|  \_\      |
#  |                              . _ _  .                                  |
#  --------------------------------------------------------------------------
#
#  All Rights Reserved.
#  Any use of this source code is subject to a license agreement with the
#  AUTOSAR development cooperation.
#  More information is available at www.autosar.org.
#
#  Disclaimer
#
#  This work (specification and/or software implementation) and the material
#  contained in it, as released by AUTOSAR, is for the purpose of information
#  only. AUTOSAR and the companies that have contributed to it shall not be
#  liable for any use of the work.
#
#  The material contained in this work is protected by copyright and other
#  types of intellectual property rights. The commercial exploitation of the
#  material contained in this work requires a license to such intellectual
#  property rights.
#
#  This work may be utilized or reproduced without any modification, in any
#  form or by any means, for informational purposes only. For any other
#  purpose, no part of the work may be utilized or reproduced, in any form
#  or by any means, without permission in writing from the publisher.
#
#  The work has been developed for automotive applications only. It has
#  neither been developed, nor tested for non-automotive applications.
#
#  The word AUTOSAR and the AUTOSAR logo are registered trademarks.
#  --------------------------------------------------------------------------

"""
User defined service deployment builder class.
"""

# pylint: disable=too-many-lines,too-many-public-methods
import hashlib
import logging
import collections
from generator.parser.tree_helper import get_element
from generator.parser.interface_builder import _GET, _SET, _NOTIFIER


class UserDefinedServiceDeploymentBuilder():
    """
    Handles parsing the ARXML part, related to user defined network binding.
    """

    def __init__(self):
        self._log = logging.getLogger(__name__)
        self._user_defined_service_interfaces_ids = []

    @staticmethod
    def _get_event_deployment(ar_event_depl, id_counter):
        """
        Extract IPC event deployment information, will be returned as
        a dict with information
        """
        result = dict(
            name=ar_event_depl.get_fqn(),
            id=id_counter,
            proto="IPC"
        )

        return result

    @staticmethod
    def _get_field_deployment(ar_field_depl, id_counter):
        """
        Extract IPC field deployment information, will be returned as
        a dict with information
        """
        result = dict(getter={}, setter={}, notifier={})
        # incrementing_id is a local counter to be incremented inside this function. getter, setter and notifier use
        # it to have different ids
        # id_counter itself will be changed in a caller function according to the number of non-empty elements in
        # the resulting dict
        incrementing_id = id_counter

        getter = getattr(ar_field_depl, _GET, None)
        if getter is not None:
            result['getter'] = dict(
                name=get_element(getter, "SHORT-NAME"),
                id=incrementing_id,
                proto="IPC"
            )
            incrementing_id += 1

        setter = getattr(ar_field_depl, _SET, None)
        if setter is not None:
            result['setter'] = dict(
                name=get_element(setter, "SHORT-NAME"),
                id=incrementing_id,
                proto="IPC"
            )
            incrementing_id += 1

        notifier = getattr(ar_field_depl, _NOTIFIER, None)
        if notifier is not None:
            result['notifier'] = dict(
                name=notifier.get_fqn(),
                id=incrementing_id,
                proto="IPC"
            )

        return result

    @staticmethod
    def _get_method_deployment(ar_method_depl, id_counter):
        """
        Extract IPC method deployment information, will be returned as
        a dict with information
        """
        result = dict(
            name=get_element(ar_method_depl, "SHORT-NAME"),
            id=id_counter
        )

        return result

    @staticmethod
    def _get_eventgrps_deployment(events_deployment, fields_deployment):
        """
        Extract IPC event group deployment information, will be returned
        as a dict with information
        """
        inner = collections.OrderedDict()
        result = dict(event_groups=inner)

        for _, event_depl in events_deployment.items():
            if event_depl:
                # Construct an unique name for a newly created eventgroup by appending fixed string to an event's name
                group_name = event_depl["name"] + "EventGroup"
                result['event_groups'][group_name] = dict(
                    id=event_depl["id"],
                    events=[event_depl["id"]]
                )

        for _, field_depl in fields_deployment.items():
            if field_depl:
                notifier = field_depl["notifier"]
                if notifier:
                    # Construct an unique name for a newly created eventgroup by appending fixed to an notifier's name
                    group_name = notifier["name"] + "EventGroup"
                    result['event_groups'][group_name] = dict(
                        id=notifier["id"],
                        events=[notifier["id"]]
                    )

        return result

    def get_instance_deployment(self, ar_si):
        """
        Extract IPC deployment information, will be returned as a
        dict with information
        """

        def get_si_id(ar_si):
            fqn = ar_si.get_fqn()
            hash_algo = hashlib.new('sha1')
            hash_algo.update(fqn.encode('UTF-8'))
            result = 0
            digest = bytearray(hash_algo.digest())
            for i in digest[0:2]:
                result = result * 256 + int(i)
            return result

        id_counter = 1
        id = get_si_id(ar_si)

        if id in self._user_defined_service_interfaces_ids:
            self._log.warning("Service Interface id collision for {} with id {}".format(ar_si.get_fqn(), id))
            while id in self._user_defined_service_interfaces_ids:
                id += 1

        self._user_defined_service_interfaces_ids.append(id)

        result = dict(service_id=id,
                      events={}, methods={}, fields={}, event_groups={})

        if hasattr(ar_si, 'EVENT_DEPLOYMENTS'):
            event_depls = ar_si.EVENT_DEPLOYMENTS.find_elements_of_type(
                "USER-DEFINED-EVENT-DEPLOYMENT")
            for event_depl in event_depls:
                result['events'][event_depl.EVENT_REF] = \
                    self._get_event_deployment(event_depl, id_counter)
                id_counter += 1

        if hasattr(ar_si, 'FIELD_DEPLOYMENTS'):
            field_depls = ar_si.FIELD_DEPLOYMENTS.find_elements_of_type(
                "USER-DEFINED-FIELD-DEPLOYMENT")
            for field_depl in field_depls:
                result['fields'][field_depl.FIELD_REF] = \
                    self._get_field_deployment(field_depl, id_counter)
                # get_field_user_defined_deployment function use an id for every non-empty dict in returned dict, so
                # increment id_counter by a number of used ids, which is total number of elements in returned dict minus
                # number of empty elements
                methods = list(result['fields'][field_depl.FIELD_REF].values())
                id_counter += len(methods) - methods.count({})

        if hasattr(ar_si, 'METHOD_DEPLOYMENTS'):
            method_depls = ar_si.METHOD_DEPLOYMENTS.find_elements_of_type(
                "USER-DEFINED-METHOD-DEPLOYMENT")
            for method_depl in method_depls:
                result['methods'][method_depl.METHOD_REF] = \
                    self._get_method_deployment(method_depl, id_counter)
                id_counter += 1

        event_group_depls = self._get_eventgrps_deployment(
            result['events'], result['fields'])

        result = {**result, **event_group_depls}
        return result
