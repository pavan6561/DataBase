// --------------------------------------------------------------------------
// |              _    _ _______     .----.      _____         _____        |
// |         /\  | |  | |__   __|  .  ____ .    / ____|  /\   |  __ \       |
// |        /  \ | |  | |  | |    .  / __ \ .  | (___   /  \  | |__) |      |
// |       / /\ \| |  | |  | |   .  / / / / v   \___ \ / /\ \ |  _  /       |
// |      / /__\ \ |__| |  | |   . / /_/ /  .   ____) / /__\ \| | \ \       |
// |     /________\____/   |_|   ^ \____/  .   |_____/________\_|  \_\      |
// |                              . _ _  .                                  |
// --------------------------------------------------------------------------
//
// All Rights Reserved.
// Any use of this source code is subject to a license agreement with the
// AUTOSAR development cooperation.
// More information is available at www.autosar.org.
//
// Disclaimer
//
// This work (specification and/or software implementation) and the material
// contained in it, as released by AUTOSAR, is for the purpose of information
// only. AUTOSAR and the companies that have contributed to it shall not be
// liable for any use of the work.
//
// The material contained in this work is protected by copyright and other
// types of intellectual property rights. The commercial exploitation of the
// material contained in this work requires a license to such intellectual
// property rights.
//
// This work may be utilized or reproduced without any modification, in any
// form or by any means, for informational purposes only. For any other
// purpose, no part of the work may be utilized or reproduced, in any form
// or by any means, without permission in writing from the publisher.
//
// The work has been developed for automotive applications only. It has
// neither been developed, nor tested for non-automotive applications.
//
// The word AUTOSAR and the AUTOSAR logo are registered trademarks.
// --------------------------------------------------------------------------

#ifndef franca_sample_vsomeip_adapter_flaveratesttestbookend2_h
#define franca_sample_vsomeip_adapter_flaveratesttestbookend2_h

#include "ara/com/internal/vsomeip/skeleton/vsomeip_skeleton_base.h"
#include "service_desc_flaveratesttestbookend2.h"
#include "/flaveratesttestbookend2_skeleton.h"

namespace flaveratesttestbookend2_binding {
namespace vsomeip {

class flaverATesttestBookend2ServiceAdapter : public ::ara::com::internal::vsomeip::skeleton::ServiceImplBase {
 public:
  using ServiceInterface = skeleton::flaverATesttestBookend2Skeleton;
  using ServiceDescriptor = descriptors::internal::Service;

  flaverATesttestBookend2ServiceAdapter(ServiceInterface& service, ara::com::internal::InstanceId instance) :
    ::ara::com::internal::vsomeip::skeleton::ServiceImplBase(service, instance) {
    Connect(service);
    RegisterMethodDispatcher(ServiceDescriptor::service_id,
                             [this](const std::shared_ptr<::vsomeip::message>& msg) { DispatchMethodCall(msg); });
    OfferService(ServiceDescriptor::service_id, GetInstanceId(), ServiceDescriptor::service_version, ServiceDescriptor::minor_service_version);
  }

  virtual ~flaverATesttestBookend2ServiceAdapter() {
    StopOfferService(ServiceDescriptor::service_id, GetInstanceId());
    UnregisterMethodDispatcher(ServiceDescriptor::service_id);
    Disconnect(dynamic_cast<ServiceInterface&>(service_));
  }
 protected:
  void DispatchMethodCall(const std::shared_ptr<::vsomeip::message>& msg) {
    ServiceInterface& service = dynamic_cast<ServiceInterface&>(service_);
    switch(msg->get_method()) {
      case descriptors::requstAttributes::method_id:
        HandleCall(service, &ServiceInterface::requstAttributes, msg);
        break;
    }
  }

 private:
  void Connect(ServiceInterface& service) {
    service.AddDelegate(*this);
  }

  void Disconnect(ServiceInterface& service) {
    service.RemoveDelegate(*this);
  }

};

} // namespace vsomeip
} // namespace flaveratesttestbookend2_binding

#endif // franca_sample_vsomeip_adapter_flaveratesttestbookend2_h

