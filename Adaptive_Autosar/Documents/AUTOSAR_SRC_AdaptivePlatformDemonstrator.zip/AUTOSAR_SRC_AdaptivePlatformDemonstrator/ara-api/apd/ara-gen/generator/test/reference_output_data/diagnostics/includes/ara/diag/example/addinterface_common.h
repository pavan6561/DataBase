// --------------------------------------------------------------------------
// |              _    _ _______     .----.      _____         _____        |
// |         /\  | |  | |__   __|  .  ____ .    / ____|  /\   |  __ \       |
// |        /  \ | |  | |  | |    .  / __ \ .  | (___   /  \  | |__) |      |
// |       / /\ \| |  | |  | |   .  / / / / v   \___ \ / /\ \ |  _  /       |
// |      / /__\ \ |__| |  | |   . / /_/ /  .   ____) / /__\ \| | \ \       |
// |     /________\____/   |_|   ^ \____/  .   |_____/________\_|  \_\      |
// |                              . _ _  .                                  |
// --------------------------------------------------------------------------
//
// All Rights Reserved.
// Any use of this source code is subject to a license agreement with the
// AUTOSAR development cooperation.
// More information is available at www.autosar.org.
//
// Disclaimer
//
// This work (specification and/or software implementation) and the material
// contained in it, as released by AUTOSAR, is for the purpose of information
// only. AUTOSAR and the companies that have contributed to it shall not be
// liable for any use of the work.
//
// The material contained in this work is protected by copyright and other
// types of intellectual property rights. The commercial exploitation of the
// material contained in this work requires a license to such intellectual
// property rights.
//
// This work may be utilized or reproduced without any modification, in any
// form or by any means, for informational purposes only. For any other
// purpose, no part of the work may be utilized or reproduced, in any form
// or by any means, without permission in writing from the publisher.
//
// The work has been developed for automotive applications only. It has
// neither been developed, nor tested for non-automotive applications.
//
// The word AUTOSAR and the AUTOSAR logo are registered trademarks.
// --------------------------------------------------------------------------

#ifndef diagnostics_includes_ara_diag_example_addinterface_common_h
#define diagnostics_includes_ara_diag_example_addinterface_common_h

#include <string.h>
#include "ara/core/array.h"

#include "ara/com/types.h"

#include "ara/com/exception.h"
#include "ara/core/error_code.h"
#include <cstdint>
#include "error_domain_diagexample.h"
namespace ara {
namespace diag {
namespace example {

class AddInterface {
 public:
  static constexpr ara::com::internal::ServiceId service_id = 0x8b5f;
  static constexpr ara::com::internal::ServiceVersion service_version = 0x01000000;
  static constexpr ara::core::Array<ara::core::ErrorCode, 2> AddMethod_PossibleErrors =
  {
    ::ara::diag::example::MakeErrorCode(::ara::diag::example::DiagExampleErrc::kCalculationOverflow, 0),
    ::ara::diag::example::MakeErrorCode(::ara::diag::example::DiagExampleErrc::kCalculationUnderflow, 0),
  };

  struct AddMethodOutput {
    std::int32_t Lhs;
    std::int32_t Rhs;

    using IsEnumerableTag = void;
    template<typename F>
    void enumerate(F& fun) {
      fun(Lhs);
      fun(Rhs);
    }
  };
};

} // namespace example
} // namespace diag
} // namespace ara

#endif // diagnostics_includes_ara_diag_example_addinterface_common_h

