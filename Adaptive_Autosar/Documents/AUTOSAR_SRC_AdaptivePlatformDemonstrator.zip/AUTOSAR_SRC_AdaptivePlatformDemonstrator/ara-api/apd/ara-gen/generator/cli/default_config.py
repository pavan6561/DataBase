#  --------------------------------------------------------------------------
#  |              _    _ _______     .----.      _____         _____        |
#  |         /\  | |  | |__   __|  .  ____ .    / ____|  /\   |  __ \       |
#  |        /  \ | |  | |  | |    .  / __ \ .  | (___   /  \  | |__) |      |
#  |       / /\ \| |  | |  | |   .  / / / / v   \___ \ / /\ \ |  _  /       |
#  |      / /__\ \ |__| |  | |   . / /_/ /  .   ____) / /__\ \| | \ \       |
#  |     /________\____/   |_|   ^ \____/  .   |_____/________\_|  \_\      |
#  |                              . _ _  .                                  |
#  --------------------------------------------------------------------------
#
#  All Rights Reserved.
#  Any use of this source code is subject to a license agreement with the
#  AUTOSAR development cooperation.
#  More information is available at www.autosar.org.
#
#  Disclaimer
#
#  This work (specification and/or software implementation) and the material
#  contained in it, as released by AUTOSAR, is for the purpose of information
#  only. AUTOSAR and the companies that have contributed to it shall not be
#  liable for any use of the work.
#
#  The material contained in this work is protected by copyright and other
#  types of intellectual property rights. The commercial exploitation of the
#  material contained in this work requires a license to such intellectual
#  property rights.
#
#  This work may be utilized or reproduced without any modification, in any
#  form or by any means, for informational purposes only. For any other
#  purpose, no part of the work may be utilized or reproduced, in any form
#  or by any means, without permission in writing from the publisher.
#
#  The work has been developed for automotive applications only. It has
#  neither been developed, nor tested for non-automotive applications.
#
#  The word AUTOSAR and the AUTOSAR logo are registered trademarks.
#  --------------------------------------------------------------------------


"""
Default config key-value pairs and setup methods
"""


import os

# Key for fetching the parsers in the config
CONFIG_PARSERS = "parsers"
# Key for fetching the generators in the config
CONFIG_GENERATORS = "generators"
# Key for fetching the name of a model belonging to a parser/generator in the config
CONFIG_NAME = "name"
# Key for fetching the path of a parser/generator module in the config
CONFIG_PATH = "path"
# Key for fetching the import statement of a parser/generator module in the config
CONFIG_IMPORT_STATEMENT = "import"


# Name for model used for standard generator
STD_GENERATOR_NAME = "intermediate_model"
# Import statement used for standard generator
STD_GENERATOR_IMPORT = "generator.generator.generator"
# Name for model used for standard parser
STD_PARSER_NAME = "arxml_tree"
# Import statement used for standard parser
STD_PARSER_IMPORT = "generator.parser.parser"


def load_default_config_values(config):
    """
    Adds the config with default config values for generator and parser,
    if not already present in the input config. If the default values
    have been already specified, this function will not override the values.
    """

    if not config:
        config = dict()

    overridden_default_generator = False

    default_gen = dict()
    default_gen[CONFIG_NAME] = STD_GENERATOR_NAME
    path = os.path.join(os.path.dirname(__file__), "..")

    default_gen[CONFIG_PATH] = path
    default_gen[CONFIG_IMPORT_STATEMENT] = STD_GENERATOR_IMPORT

    if CONFIG_GENERATORS in config:
        for generator in config[CONFIG_GENERATORS]:
            if CONFIG_NAME in generator and \
               generator[CONFIG_NAME] == STD_GENERATOR_NAME:

                overridden_default_generator = True
                break

        if not overridden_default_generator:
            config[CONFIG_GENERATORS].append(default_gen)
    else:
        config[CONFIG_GENERATORS] = list()
        config[CONFIG_GENERATORS].append(default_gen)

    overridden_default_parser = False

    default_parser = dict()
    default_parser[CONFIG_NAME] = STD_PARSER_NAME

    default_parser[CONFIG_PATH] = path
    default_parser[CONFIG_IMPORT_STATEMENT] = STD_PARSER_IMPORT

    if CONFIG_PARSERS in config:
        for parser in config[CONFIG_PARSERS]:
            if CONFIG_NAME in parser and \
               parser[CONFIG_NAME] == STD_PARSER_NAME:

                overridden_default_parser = True
                break

        if not overridden_default_parser:
            config[CONFIG_PARSERS].append(default_parser)
    else:
        config[CONFIG_PARSERS] = list()
        config[CONFIG_PARSERS].append(default_parser)

    return config
