#  --------------------------------------------------------------------------
#  |              _    _ _______     .----.      _____         _____        |
#  |         /\  | |  | |__   __|  .  ____ .    / ____|  /\   |  __ \       |
#  |        /  \ | |  | |  | |    .  / __ \ .  | (___   /  \  | |__) |      |
#  |       / /\ \| |  | |  | |   .  / / / / v   \___ \ / /\ \ |  _  /       |
#  |      / /__\ \ |__| |  | |   . / /_/ /  .   ____) / /__\ \| | \ \       |
#  |     /________\____/   |_|   ^ \____/  .   |_____/________\_|  \_\      |
#  |                              . _ _  .                                  |
#  --------------------------------------------------------------------------
#
#  All Rights Reserved.
#  Any use of this source code is subject to a license agreement with the
#  AUTOSAR development cooperation.
#  More information is available at www.autosar.org.
#
#  Disclaimer
#
#  This work (specification and/or software implementation) and the material
#  contained in it, as released by AUTOSAR, is for the purpose of information
#  only. AUTOSAR and the companies that have contributed to it shall not be
#  liable for any use of the work.
#
#  The material contained in this work is protected by copyright and other
#  types of intellectual property rights. The commercial exploitation of the
#  material contained in this work requires a license to such intellectual
#  property rights.
#
#  This work may be utilized or reproduced without any modification, in any
#  form or by any means, for informational purposes only. For any other
#  purpose, no part of the work may be utilized or reproduced, in any form
#  or by any means, without permission in writing from the publisher.
#
#  The work has been developed for automotive applications only. It has
#  neither been developed, nor tested for non-automotive applications.
#
#  The word AUTOSAR and the AUTOSAR logo are registered trademarks.
#  --------------------------------------------------------------------------

"""
Intermediate model tests.
"""

import unittest
import os
from typing import List

import generator.parser
from generator.parser.parser import Parser as Parser
from generator.intermediate_model.execution_management.component \
    import Component
from generator.intermediate_model.communication_management.service \
    import Service


def find_service(path, services, service_interfaces):
    """Utility: resolve link path to a service interface"""
    name = path.split("/")[-1]
    for service in services:
        if name == service.name:
            return service
    for interface in service_interfaces:
        interface_name = interface.SHORT_NAME
        if name == interface_name:
            service = Service(name)
            services.append(service)
            return service
    return None


class IntermediateModelTest(unittest.TestCase):
    """
    Testing Intermediate Model Components and Services.
    """

    def setUp(self):
        """
        Setup Method for all tests in this class
        """
        self.file_directory = os.path.dirname(os.path.realpath(__file__))
        self.radarfusion_arxml_path = os.path.join(self.file_directory, "data",
                                                   "radarfusion.arxml")
        self.arxml_parser = Parser()
        self.tree = self.arxml_parser.parse(self.radarfusion_arxml_path)
        self.applications = self.tree.findall(
            './/' + generator.parser.AR_NAMESPACE +
            'ADAPTIVE-APPLICATION-SW-COMPONENT-TYPE')
        self.service_interfaces = self.tree.findall(
            './/' + generator.parser.AR_NAMESPACE + 'SERVICE-INTERFACE')

    def get_components(self) -> List[Component]:
        """Get list of all Components"""
        services = list()  # type: List[Service]
        components = list()  # type: List[Component]

        for application in self.applications:
            name = application.SHORT_NAME
            component = Component(name)
            components.append(component)

            ports = application.PORTS

            if hasattr(ports, "R_PORT_PROTOTYPE"):
                for _, port in enumerate(ports.R_PORT_PROTOTYPE):
                    service_interface_path = port.REQUIRED_INTERFACE_TREF
                    service = find_service(service_interface_path, services,
                                           self.service_interfaces)
                    component.add_required_service(service)

            if hasattr(ports, "P_PORT_PROTOTYPE"):
                for _, port in enumerate(ports.P_PORT_PROTOTYPE):
                    service_interface_path = port.PROVIDED_INTERFACE_TREF
                    service = find_service(service_interface_path, services,
                                           self.service_interfaces)
                    component.add_provided_service(service)
        return components

    def test_construct_components(self):
        """
        Check all Components were constructed.
        """
        components = self.get_components()
        component_names = {component.name for component in components}
        self.assertSetEqual(component_names, {'fusion', 'radarService'})

    def test_check_provided_services(self):
        """
        Check services provided by components.
        """
        components = self.get_components()
        svc_per_comp = [component.provided_services for component in
                        components]
        provided_service_names = {svc.name for svc_comp in svc_per_comp
                                  for svc in svc_comp}
        self.assertSetEqual(provided_service_names, {'radar'})
        provider_components = list(
            filter(lambda comp: comp.name == 'radarService', components))
        self.assertEqual(1, len(provider_components))
        comp_services = set(provider_components[0].provided_services)
        comp_service_names = set(service.name for service in comp_services)
        self.assertSetEqual({'radar'}, comp_service_names)
