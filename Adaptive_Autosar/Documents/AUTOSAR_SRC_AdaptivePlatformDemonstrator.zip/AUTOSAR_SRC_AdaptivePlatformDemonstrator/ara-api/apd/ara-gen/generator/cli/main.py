#  --------------------------------------------------------------------------
#  |              _    _ _______     .----.      _____         _____        |
#  |         /\  | |  | |__   __|  .  ____ .    / ____|  /\   |  __ \       |
#  |        /  \ | |  | |  | |    .  / __ \ .  | (___   /  \  | |__) |      |
#  |       / /\ \| |  | |  | |   .  / / / / v   \___ \ / /\ \ |  _  /       |
#  |      / /__\ \ |__| |  | |   . / /_/ /  .   ____) / /__\ \| | \ \       |
#  |     /________\____/   |_|   ^ \____/  .   |_____/________\_|  \_\      |
#  |                              . _ _  .                                  |
#  --------------------------------------------------------------------------
#
#  All Rights Reserved.
#  Any use of this source code is subject to a license agreement with the
#  AUTOSAR development cooperation.
#  More information is available at www.autosar.org.
#
#  Disclaimer
#
#  This work (specification and/or software implementation) and the material
#  contained in it, as released by AUTOSAR, is for the purpose of information
#  only. AUTOSAR and the companies that have contributed to it shall not be
#  liable for any use of the work.
#
#  The material contained in this work is protected by copyright and other
#  types of intellectual property rights. The commercial exploitation of the
#  material contained in this work requires a license to such intellectual
#  property rights.
#
#  This work may be utilized or reproduced without any modification, in any
#  form or by any means, for informational purposes only. For any other
#  purpose, no part of the work may be utilized or reproduced, in any form
#  or by any means, without permission in writing from the publisher.
#
#  The work has been developed for automotive applications only. It has
#  neither been developed, nor tested for non-automotive applications.
#
#  The word AUTOSAR and the AUTOSAR logo are registered trademarks.
#  --------------------------------------------------------------------------

"""
Entry point of aragen.
"""

import importlib.util
import sys
import os
import signal
import logging

from generator.cli.aragen_args import AragenArgs
from generator.cli.default_config import CONFIG_GENERATORS
from generator.cli.default_config import CONFIG_PARSERS
from generator.cli.default_config import CONFIG_PATH
from generator.cli.default_config import CONFIG_NAME
from generator.cli.default_config import CONFIG_IMPORT_STATEMENT
from generator.parser.default_parser import DefaultParser
from generator.parser.v47.parser import Parser as Parser_v47
from generator.parser.tree_helper import get_schema_from_tree


def handle_sigint(signum, frame):
    """
    Handle SIGINT (i.e. Ctrl-c) properly.
    This entails triggering the system's default SIGINT handler
    after all our own processing has been done, so that a calling
    shell knows that we have terminated because of SIGINT.
    """
    # pylint: disable=unused-argument
    print('Interrupted by user', file=sys.stderr)
    signal.signal(signum, signal.SIG_DFL)
    os.kill(os.getpid(), signum)


def main(argv=None):
    """
    Main entry point to aragen.
    """
    signal.signal(signal.SIGINT, handle_sigint)

    if argv is None:
        argv = sys.argv
    args = AragenArgs(argv)

    # Configure root logger, from which all other logger inherit their settings.
    root_level = logging.WARNING - 10*args.verbose
    # The simple calculation above does not cope with the fact that our own TRACE level
    # does not fully adher to the level number sequence rule.
    if args.verbose >= 3:
        root_level = logging.TRACE
    log_format = '{asctime} - [{levelname:<8}] {name} : {message}'
    log_handlers = []
    # First make sure that there is always at least one handler in the list,
    # otherwise logging.basicConfig() might add in some default handlers.
    log_handlers.append(logging.NullHandler())
    if not args.quiet:
        # This option only concerns itself with suppressing console output.
        stream_handler = logging.StreamHandler()
        log_handlers.append(stream_handler)
    if args.log:
        file_handler = logging.FileHandler(args.log)
        log_handlers.append(file_handler)
    logging.basicConfig(level=root_level, format=log_format, style='{', handlers=log_handlers)

    log = logging.getLogger(__name__)
    log.info('Starting up...')

    log.debug("Using input from %s", args.file)

    models = dict()

    # Step 1: Parse Input Files.
    for parser_entry in args.config[CONFIG_PARSERS]:
        sys.path.insert(0, parser_entry[CONFIG_PATH])

        parser_module = importlib.import_module(parser_entry[CONFIG_IMPORT_STATEMENT])
        models[parser_entry[CONFIG_NAME]] = parser_module.Parser().parse(args.file)
        sys.path = sys.path[1:]

    # generator = Generator(config=args.config,
    #                       debug=args.debug,
    #                       dry_run=args.dry_run,
    #                       generate=args.generate,
    #                       list_files=args.list_files,
    #                       output_dir=args.output)


    # Step 2: Create Parser
    # This should be reworked, just trying to make CLI work for vsomeip.json generation.
    used_schema = get_schema_from_tree(models["arxml_tree"])
    if used_schema == "AUTOSAR_00047.xsd":
        used_parser = Parser_v47(models["arxml_tree"], args.pkg_path_fallback)
    else:
        used_parser = DefaultParser(models["arxml_tree"], args.pkg_path_fallback)
    #


    # Step 3: Execute the Aragen Command-line Arguments.

    # TODO: It's assumed for name that --applications and --machines are mutually
    # TODO: exclusive and can not be used in conjunction, this is to avoid conflicts in generation
    if args.applications and args.machines:
        log.error("The command line argument --applications can not be used in conjunction with --machines")
        sys.exit("The command line argument --applications can not be used in conjunction with --machines")

    if args.list_machines:
        machines = used_parser.get_machines_fqn()
        log.info("Found {%s} machines in the input data", " ".join(machines))

        if machines:
            for machine in machines:
                print(machine)
        else:
            log.warning("No machines were found in the input data!")
        exit(0)

    if args.list_applications:
        applications = used_parser.get_adaptive_applications_fqn()
        log.info("Found {%s} Adaptive Application in the input data", " ".join(applications))

        if applications:
            for application in applications:
                print(application)
        else:
            log.warning("No Adaptive Applications were found in the input data!")
        exit(0)

    # Step 4: Create Intermediate Model.
    # Create Intermediate Model should be done after executing command line args as the create_intermediate_model
    # requires the input to be complete and it will fail otherwise but the user might be interested in querying some
    # data like --list-applications and --list-machines.
    models["intermediate_model"] = used_parser.create_intermediate_model(args.machines, args.applications)

    # Step 5: Generation.
    for generator_entry in args.config[CONFIG_GENERATORS]:
        sys.path.insert(0, generator_entry[CONFIG_PATH])

        generator_module = importlib.import_module(generator_entry[CONFIG_IMPORT_STATEMENT])
        # fixme: Use the corresponding args instead of None when enabled.
        gen = generator_module.Generator(args)

        gen.generate(models[generator_entry[CONFIG_NAME]])

        sys.path = sys.path[1:]

    log.info('Finished.')
