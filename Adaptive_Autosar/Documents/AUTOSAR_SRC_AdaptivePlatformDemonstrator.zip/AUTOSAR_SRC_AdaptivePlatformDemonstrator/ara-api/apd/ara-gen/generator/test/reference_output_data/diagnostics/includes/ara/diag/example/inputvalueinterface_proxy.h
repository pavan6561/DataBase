// --------------------------------------------------------------------------
// |              _    _ _______     .----.      _____         _____        |
// |         /\  | |  | |__   __|  .  ____ .    / ____|  /\   |  __ \       |
// |        /  \ | |  | |  | |    .  / __ \ .  | (___   /  \  | |__) |      |
// |       / /\ \| |  | |  | |   .  / / / / v   \___ \ / /\ \ |  _  /       |
// |      / /__\ \ |__| |  | |   . / /_/ /  .   ____) / /__\ \| | \ \       |
// |     /________\____/   |_|   ^ \____/  .   |_____/________\_|  \_\      |
// |                              . _ _  .                                  |
// --------------------------------------------------------------------------
//
// All Rights Reserved.
// Any use of this source code is subject to a license agreement with the
// AUTOSAR development cooperation.
// More information is available at www.autosar.org.
//
// Disclaimer
//
// This work (specification and/or software implementation) and the material
// contained in it, as released by AUTOSAR, is for the purpose of information
// only. AUTOSAR and the companies that have contributed to it shall not be
// liable for any use of the work.
//
// The material contained in this work is protected by copyright and other
// types of intellectual property rights. The commercial exploitation of the
// material contained in this work requires a license to such intellectual
// property rights.
//
// This work may be utilized or reproduced without any modification, in any
// form or by any means, for informational purposes only. For any other
// purpose, no part of the work may be utilized or reproduced, in any form
// or by any means, without permission in writing from the publisher.
//
// The work has been developed for automotive applications only. It has
// neither been developed, nor tested for non-automotive applications.
//
// The word AUTOSAR and the AUTOSAR logo are registered trademarks.
// --------------------------------------------------------------------------

#ifndef diagnostics_includes_ara_diag_example_inputvalueinterface_proxy_h
#define diagnostics_includes_ara_diag_example_inputvalueinterface_proxy_h

#include "ara/com/internal/proxy/ara_proxy_base.h"
#include "inputvalueinterface_common.h"

namespace ara {
namespace diag {
namespace example {
namespace proxy {


namespace fields {
using input1Field = ara::com::internal::proxy::MutableField<std::int32_t>;
template <typename T, bool E2E = ara::com::internal::e2e::is_e2e_enabled<T>::value>
class input1Proxy {
private:
  input1Field& field;

public:
  explicit input1Proxy(input1Field& field_base)
      : field(field_base)
      /// @uptrace{SWS_CM_00133}
      , Set(field_base.Set)
  { }

  // Event Base.
  void Subscribe(ara::com::EventCacheUpdatePolicy policy, std::size_t cacheSize) {
    field.Subscribe(policy, cacheSize);
  }
  
  bool IsSubscribed() const {
    return field.IsSubscribed();
  }

  void Unsubscribe() {
    return field.Unsubscribe();
  }

  void Cleanup() {
    field.Cleanup();
  }

  void SetReceiveHandler(ara::com::EventReceiveHandler handler) {
    field.SetReceiveHandler(handler);
  }

  void UnsetReceiveHandler() {
    field.UnsetReceiveHandler();
  }

  void SetSubscriptionStateChangeHandler(ara::com::SubscriptionStateChangeHandler handler) {
    field.SetSubscriptionStateChangeHandler(handler);
  }

  void UnsetSubscriptionStateChangeHandler() {
    field.UnsetSubscriptionStateChangeHandler();
  }

  using container_type = input1Field::container_type;

  // Event.
  bool Update() {
    return field.Update();
  }

  bool Update(ara::com::FilterFunction<T> filter) {
    return field.Update(filter);
  }

  const container_type &GetCachedSamples() const {
    return field.GetCachedSamples();
  }

  template <typename U=T, typename = std::enable_if_t<E2E, U>>
  ara::com::e2exf::E2EResult GetE2EResult() const noexcept {
    return field.GetE2EResult();
  }

  /// @brief Field.
  /// @uptrace{SWS_CM_00132}
  ara::core::Future<std::int32_t> Get() {
    return field.Get();
  }

  /// @brief Mutable Field.
  /// @uptrace{SWS_CM_00133}
  using const_reference = input1Field::const_reference;
  using MethodSet = ara::com::internal::proxy::Method<void(const_reference)>;
  MethodSet &Set;

};
/// @uptrace{SWS_CM_00008}
using input1 = input1Proxy<std::int32_t>;
using input2Field = ara::com::internal::proxy::MutableField<std::int32_t>;
template <typename T, bool E2E = ara::com::internal::e2e::is_e2e_enabled<T>::value>
class input2Proxy {
private:
  input2Field& field;

public:
  explicit input2Proxy(input2Field& field_base)
      : field(field_base)
      /// @uptrace{SWS_CM_00133}
      , Set(field_base.Set)
  { }

  // Event Base.
  void Subscribe(ara::com::EventCacheUpdatePolicy policy, std::size_t cacheSize) {
    field.Subscribe(policy, cacheSize);
  }
  
  bool IsSubscribed() const {
    return field.IsSubscribed();
  }

  void Unsubscribe() {
    return field.Unsubscribe();
  }

  void Cleanup() {
    field.Cleanup();
  }

  void SetReceiveHandler(ara::com::EventReceiveHandler handler) {
    field.SetReceiveHandler(handler);
  }

  void UnsetReceiveHandler() {
    field.UnsetReceiveHandler();
  }

  void SetSubscriptionStateChangeHandler(ara::com::SubscriptionStateChangeHandler handler) {
    field.SetSubscriptionStateChangeHandler(handler);
  }

  void UnsetSubscriptionStateChangeHandler() {
    field.UnsetSubscriptionStateChangeHandler();
  }

  using container_type = input2Field::container_type;

  // Event.
  bool Update() {
    return field.Update();
  }

  bool Update(ara::com::FilterFunction<T> filter) {
    return field.Update(filter);
  }

  const container_type &GetCachedSamples() const {
    return field.GetCachedSamples();
  }

  template <typename U=T, typename = std::enable_if_t<E2E, U>>
  ara::com::e2exf::E2EResult GetE2EResult() const noexcept {
    return field.GetE2EResult();
  }

  /// @brief Field.
  /// @uptrace{SWS_CM_00132}
  ara::core::Future<std::int32_t> Get() {
    return field.Get();
  }

  /// @brief Mutable Field.
  /// @uptrace{SWS_CM_00133}
  using const_reference = input2Field::const_reference;
  using MethodSet = ara::com::internal::proxy::Method<void(const_reference)>;
  MethodSet &Set;

};
/// @uptrace{SWS_CM_00008}
using input2 = input2Proxy<std::int32_t>;
} // namespace fields


class InputValueInterfaceProxyBase : public ara::com::internal::proxy::ProxyBindingBase, public ara::diag::example::InputValueInterface {
public:
  virtual fields::input1Field& Getinput1() = 0;
  virtual fields::input2Field& Getinput2() = 0;
};

/// @uptrace{SWS_CM_00004}
class InputValueInterfaceProxy : public ara::com::internal::proxy::ProxyBase<InputValueInterfaceProxyBase>, public ara::diag::example::InputValueInterface {
private:
  fields::input1Field& input1Field;
  fields::input2Field& input2Field;

public:
  /// @brief Proxy constructor.
  ///
  /// @uptrace{SWS_CM_00131}
  explicit InputValueInterfaceProxy(const HandleType& proxy_base_factory)
      : ara::com::internal::proxy::ProxyBase<InputValueInterfaceProxyBase>(proxy_base_factory)
      , input1Field(proxy_base_->Getinput1())
      , input2Field(proxy_base_->Getinput2())
      , input1(input1Field)
      , input2(input2Field)
  {}

  /// @brief Proxy shall be move constructable.
  ///
  /// @uptrace{SWS_CM_00137}
  explicit InputValueInterfaceProxy(InputValueInterfaceProxy&&) = default;

  /// @brief Proxy shall be move assignable.
  ///
  /// @uptrace{SWS_CM_00137}
  InputValueInterfaceProxy& operator=(InputValueInterfaceProxy&&) = default;

  /// @brief Proxy shall not be copy constructable.
  ///
  /// @uptrace{SWS_CM_00136}
  explicit InputValueInterfaceProxy(const InputValueInterfaceProxy&) = delete;

  /// @brief Proxy shall not be copy assignable.
  ///
  /// @uptrace{SWS_CM_00136}
  InputValueInterfaceProxy& operator=(const InputValueInterfaceProxy&) = delete;

  fields::input1 input1;
  fields::input2 input2;
};

} // namespace proxy
} // namespace example
} // namespace diag
} // namespace ara

#endif // diagnostics_includes_ara_diag_example_inputvalueinterface_proxy_h

