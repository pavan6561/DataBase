// --------------------------------------------------------------------------
// |              _    _ _______     .----.      _____         _____        |
// |         /\  | |  | |__   __|  .  ____ .    / ____|  /\   |  __ \       |
// |        /  \ | |  | |  | |    .  / __ \ .  | (___   /  \  | |__) |      |
// |       / /\ \| |  | |  | |   .  / / / / v   \___ \ / /\ \ |  _  /       |
// |      / /__\ \ |__| |  | |   . / /_/ /  .   ____) / /__\ \| | \ \       |
// |     /________\____/   |_|   ^ \____/  .   |_____/________\_|  \_\      |
// |                              . _ _  .                                  |
// --------------------------------------------------------------------------
//
// All Rights Reserved.
// Any use of this source code is subject to a license agreement with the
// AUTOSAR development cooperation.
// More information is available at www.autosar.org.
//
// Disclaimer
//
// This work (specification and/or software implementation) and the material
// contained in it, as released by AUTOSAR, is for the purpose of information
// only. AUTOSAR and the companies that have contributed to it shall not be
// liable for any use of the work.
//
// The material contained in this work is protected by copyright and other
// types of intellectual property rights. The commercial exploitation of the
// material contained in this work requires a license to such intellectual
// property rights.
//
// This work may be utilized or reproduced without any modification, in any
// form or by any means, for informational purposes only. For any other
// purpose, no part of the work may be utilized or reproduced, in any form
// or by any means, without permission in writing from the publisher.
//
// The work has been developed for automotive applications only. It has
// neither been developed, nor tested for non-automotive applications.
//
// The word AUTOSAR and the AUTOSAR logo are registered trademarks.
// --------------------------------------------------------------------------

#ifndef diagnostics_includes_ara_diag_example_inputvalueinterface_skeleton_h
#define diagnostics_includes_ara_diag_example_inputvalueinterface_skeleton_h

#include "ara/com/internal/skeleton/ara_skeleton_base.h"

#include "ara/com/illegal_state_exception.h"
#include "inputvalueinterface_common.h"

namespace ara {
namespace diag {
namespace example {
namespace skeleton {

namespace fields {
  /// @uptrace{SWS_CM_00007}
  using input1 = ara::com::internal::skeleton::MutableFieldDispatcher<std::int32_t>;
  using input2 = ara::com::internal::skeleton::MutableFieldDispatcher<std::int32_t>;
} // namespace fields


/// @uptrace{SWS_CM_00002}
class InputValueInterfaceSkeleton : public ara::diag::example::InputValueInterface, public ara::com::internal::skeleton::TypedServiceImplBase<InputValueInterfaceSkeleton> {
public:
  /// @uptrace{SWS_CM_00130}
  InputValueInterfaceSkeleton(ara::com::InstanceIdentifier instance_id, ara::com::MethodCallProcessingMode mode = ara::com::MethodCallProcessingMode::kEvent) : ara::com::internal::skeleton::TypedServiceImplBase<InputValueInterfaceSkeleton>(instance_id, mode) {}
  virtual ~InputValueInterfaceSkeleton() {
    StopOfferService();
  }

  /// @brief Skeleton shall be move constructable.
  ///
  /// @uptrace{SWS_CM_00135}
  explicit InputValueInterfaceSkeleton(InputValueInterfaceSkeleton&&) = default;

  /// @brief Skeleton shall be move assignable.
  ///
  /// @uptrace{SWS_CM_00135}
  InputValueInterfaceSkeleton& operator=(InputValueInterfaceSkeleton&&) = default;

  /// @brief Skeleton shall not be copy constructable.
  ///
  /// @uptrace{SWS_CM_00134}
  explicit InputValueInterfaceSkeleton(const InputValueInterfaceSkeleton&) = delete;

  /// @brief Skeleton shall not be copy assignable.
  ///
  /// @uptrace{SWS_CM_00134}
  InputValueInterfaceSkeleton& operator=(const InputValueInterfaceSkeleton&) = delete;

  void OfferService() {
    if(!input1.IsInitialized()) {
      throw ara::com::IllegalStateException("Attempt to offer service \"/ara/diag/example/InputValueInterface\" with uninitialized field \"input1\"");
    }
    if(!input2.IsInitialized()) {
      throw ara::com::IllegalStateException("Attempt to offer service \"/ara/diag/example/InputValueInterface\" with uninitialized field \"input2\"");
    }

    ara::com::internal::skeleton::TypedServiceImplBase<InputValueInterfaceSkeleton>::OfferService();
  }

  fields::input1 input1;
  fields::input2 input2;
};

} // namespace skeleton
} // namespace example
} // namespace diag
} // namespace ara

#endif // diagnostics_includes_ara_diag_example_inputvalueinterface_skeleton_h

