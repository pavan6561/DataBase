#  --------------------------------------------------------------------------
#  |              _    _ _______     .----.      _____         _____        |
#  |         /\  | |  | |__   __|  .  ____ .    / ____|  /\   |  __ \       |
#  |        /  \ | |  | |  | |    .  / __ \ .  | (___   /  \  | |__) |      |
#  |       / /\ \| |  | |  | |   .  / / / / v   \___ \ / /\ \ |  _  /       |
#  |      / /__\ \ |__| |  | |   . / /_/ /  .   ____) / /__\ \| | \ \       |
#  |     /________\____/   |_|   ^ \____/  .   |_____/________\_|  \_\      |
#  |                              . _ _  .                                  |
#  --------------------------------------------------------------------------
#
#  All Rights Reserved.
#  Any use of this source code is subject to a license agreement with the
#  AUTOSAR development cooperation.
#  More information is available at www.autosar.org.
#
#  Disclaimer
#
#  This work (specification and/or software implementation) and the material
#  contained in it, as released by AUTOSAR, is for the purpose of information
#  only. AUTOSAR and the companies that have contributed to it shall not be
#  liable for any use of the work.
#
#  The material contained in this work is protected by copyright and other
#  types of intellectual property rights. The commercial exploitation of the
#  material contained in this work requires a license to such intellectual
#  property rights.
#
#  This work may be utilized or reproduced without any modification, in any
#  form or by any means, for informational purposes only. For any other
#  purpose, no part of the work may be utilized or reproduced, in any form
#  or by any means, without permission in writing from the publisher.
#
#  The work has been developed for automotive applications only. It has
#  neither been developed, nor tested for non-automotive applications.
#
#  The word AUTOSAR and the AUTOSAR logo are registered trademarks.
#  --------------------------------------------------------------------------

"""
Service class.
"""

# Unused import check suppressed, because only used in type annotation, which is not found by PyLint
from typing import List, Dict   # pylint: disable=unused-import

from ..utils.container import Container
from .event import Event
from .method import Method
from .field import Field
from .ara_com_deployment.service_deployment import ServiceDeployment


class Service(object):
    """Describes a Service that can be provided by
    or requested from a component"""
    def __init__(self, fqn: str) -> None:
        if fqn == "":
            raise AttributeError("A Service must have a name")
        self._fqn = fqn
        self._version = None
        self._namespaces = list()  # type: List[str]
        self._exposed_api_content = {}   # type: Dict
        self._exposed_api_content["events"] = Container()
        self._exposed_api_content["methods"] = Container()
        self._exposed_api_content["fields"] = Container()
        self._exposed_api_content["errors"] = Container()
        self._deployment = None  # type: ServiceDeployment

    @property
    def service_deployment(self):
        """Get the Service deployment."""
        return self._deployment

    @service_deployment.setter
    def service_deployment(self, deployment: ServiceDeployment):
        """Set the service deployment of this Service."""
        self._deployment = deployment

    @property
    def namespaces(self):
        """Get the namespaces of this Service."""
        return self._namespaces

    @namespaces.setter
    def namespaces(self, namespaces: List[str]):
        """Set the namespaces for this Service."""
        self._namespaces = namespaces

    @property
    def name(self) -> str:
        """Get the Service name"""
        return self._fqn.split("/")[-1]

    def add_event(self, event: Event):
        """Add an Event to this Service."""
        self._exposed_api_content["events"].add(event)

    def add_method(self, method: Method):
        """Add a Method to this Service."""
        self._exposed_api_content["methods"].add(method)

    def add_field(self, field: Field):
        """Add a Field to this Service."""
        self._exposed_api_content["fields"].add(field)

    @property
    def events(self) -> Container:
        """Get the Events of this Service."""
        return self._exposed_api_content["events"]

    @property
    def methods(self) -> Container:
        """Get the Methods of this Service."""
        return self._exposed_api_content["methods"]

    @property
    def fields(self) -> Container:
        """Get the Fields of this Service."""
        return self._exposed_api_content["fields"]

    @property
    def version(self) -> str:
        """Get the version of this Service"""
        return self._version

    @property
    def errors(self):
        """Get the possible errors of this Service"""
        return self._exposed_api_content["errors"]

    @property
    def fqn(self):
        return self._fqn

    def add_error(self, error):
        """Add an error to the possible errors of this Service"""
        self._exposed_api_content["errors"].add(error)
