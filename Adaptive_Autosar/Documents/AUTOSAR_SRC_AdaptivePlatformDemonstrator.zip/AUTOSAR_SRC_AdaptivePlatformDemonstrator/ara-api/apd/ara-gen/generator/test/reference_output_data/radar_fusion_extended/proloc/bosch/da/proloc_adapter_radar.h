// --------------------------------------------------------------------------
// |              _    _ _______     .----.      _____         _____        |
// |         /\  | |  | |__   __|  .  ____ .    / ____|  /\   |  __ \       |
// |        /  \ | |  | |  | |    .  / __ \ .  | (___   /  \  | |__) |      |
// |       / /\ \| |  | |  | |   .  / / / / v   \___ \ / /\ \ |  _  /       |
// |      / /__\ \ |__| |  | |   . / /_/ /  .   ____) / /__\ \| | \ \       |
// |     /________\____/   |_|   ^ \____/  .   |_____/________\_|  \_\      |
// |                              . _ _  .                                  |
// --------------------------------------------------------------------------
//
// All Rights Reserved.
// Any use of this source code is subject to a license agreement with the
// AUTOSAR development cooperation.
// More information is available at www.autosar.org.
//
// Disclaimer
//
// This work (specification and/or software implementation) and the material
// contained in it, as released by AUTOSAR, is for the purpose of information
// only. AUTOSAR and the companies that have contributed to it shall not be
// liable for any use of the work.
//
// The material contained in this work is protected by copyright and other
// types of intellectual property rights. The commercial exploitation of the
// material contained in this work requires a license to such intellectual
// property rights.
//
// This work may be utilized or reproduced without any modification, in any
// form or by any means, for informational purposes only. For any other
// purpose, no part of the work may be utilized or reproduced, in any form
// or by any means, without permission in writing from the publisher.
//
// The work has been developed for automotive applications only. It has
// neither been developed, nor tested for non-automotive applications.
//
// The word AUTOSAR and the AUTOSAR logo are registered trademarks.
// --------------------------------------------------------------------------

#ifndef radar_fusion_extended_proloc_bosch_da_proloc_adapter_radar_h
#define radar_fusion_extended_proloc_bosch_da_proloc_adapter_radar_h

#include "bosch/da/radar_skeleton.h"
#include "ara/com/internal/proloc/skeleton/proloc_service_impl_base.h"
#include "ara/com/internal/proloc/skeleton/proloc_event_impl.h"
#include "ara/com/internal/proloc/skeleton/proloc_field_impl.h"
#include "ara/com/internal/proloc/skeleton/proloc_mutable_field_impl.h"

namespace bosch {
namespace da {
namespace radar_binding {
namespace proloc {

class radarServiceAdapter : public ::ara::com::internal::proloc::skeleton::ServiceImplBase {
 public:
  using ServiceInterface = skeleton::radarSkeleton;

  radarServiceAdapter(ServiceInterface& service, ara::com::internal::InstanceId instance) :
    ::ara::com::internal::proloc::skeleton::ServiceImplBase(service, instance),
    UpdateRate(instance),
    FrontObjectDistance(instance),
    RearObjectDistance(instance),
    ObjectDetectionLimit(instance),
    brakeEvent(instance),
    parkingBrakeEvent(instance),
    driveEvent(instance) {
    Connect(service);
  }

  virtual ~radarServiceAdapter() {
    Disconnect(dynamic_cast<ServiceInterface&>(service_));
  }

 private:
  void Connect(ServiceInterface& service) {
    service.UpdateRate.AddDelegate(UpdateRate);
    service.FrontObjectDistance.AddDelegate(FrontObjectDistance);
    service.RearObjectDistance.AddDelegate(RearObjectDistance);
    service.ObjectDetectionLimit.AddDelegate(ObjectDetectionLimit);
    service.brakeEvent.AddDelegate(brakeEvent);
    service.parkingBrakeEvent.AddDelegate(parkingBrakeEvent);
    service.driveEvent.AddDelegate(driveEvent);
  }

  void Disconnect(ServiceInterface& service) {
    service.UpdateRate.RemoveDelegate(UpdateRate);
    service.FrontObjectDistance.RemoveDelegate(FrontObjectDistance);
    service.RearObjectDistance.RemoveDelegate(RearObjectDistance);
    service.ObjectDetectionLimit.RemoveDelegate(ObjectDetectionLimit);
    service.brakeEvent.RemoveDelegate(brakeEvent);
    service.parkingBrakeEvent.RemoveDelegate(parkingBrakeEvent);
    service.driveEvent.RemoveDelegate(driveEvent);
  }

public:
  ara::com::internal::proloc::skeleton::MutableFieldImpl<::UInt32> UpdateRate;
  ara::com::internal::proloc::skeleton::FieldImpl<::UInt16> FrontObjectDistance;
  ara::com::internal::proloc::skeleton::FieldImpl<::UInt16> RearObjectDistance;
  ara::com::internal::proloc::skeleton::MutableFieldImpl<::UInt16> ObjectDetectionLimit;
  ara::com::internal::proloc::skeleton::EventImpl<::RadarObjects> brakeEvent;
  ara::com::internal::proloc::skeleton::EventImpl<::RadarObjects> parkingBrakeEvent;
  ara::com::internal::proloc::skeleton::EventImpl<::RadarObjects> driveEvent;
};

} // namespace proloc
} // namespace radar_binding
} // namespace da
} // namespace bosch

#endif // radar_fusion_extended_proloc_bosch_da_proloc_adapter_radar_h

