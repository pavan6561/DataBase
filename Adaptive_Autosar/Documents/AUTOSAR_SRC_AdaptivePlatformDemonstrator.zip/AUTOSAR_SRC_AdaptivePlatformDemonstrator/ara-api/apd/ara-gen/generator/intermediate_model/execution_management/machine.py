#  --------------------------------------------------------------------------
#  |              _    _ _______     .----.      _____         _____        |
#  |         /\  | |  | |__   __|  .  ____ .    / ____|  /\   |  __ \       |
#  |        /  \ | |  | |  | |    .  / __ \ .  | (___   /  \  | |__) |      |
#  |       / /\ \| |  | |  | |   .  / / / / v   \___ \ / /\ \ |  _  /       |
#  |      / /__\ \ |__| |  | |   . / /_/ /  .   ____) / /__\ \| | \ \       |
#  |     /________\____/   |_|   ^ \____/  .   |_____/________\_|  \_\      |
#  |                              . _ _  .                                  |
#  --------------------------------------------------------------------------
#
#  All Rights Reserved.
#  Any use of this source code is subject to a license agreement with the
#  AUTOSAR development cooperation.
#  More information is available at www.autosar.org.
#
#  Disclaimer
#
#  This work (specification and/or software implementation) and the material
#  contained in it, as released by AUTOSAR, is for the purpose of information
#  only. AUTOSAR and the companies that have contributed to it shall not be
#  liable for any use of the work.
#
#  The material contained in this work is protected by copyright and other
#  types of intellectual property rights. The commercial exploitation of the
#  material contained in this work requires a license to such intellectual
#  property rights.
#
#  This work may be utilized or reproduced without any modification, in any
#  form or by any means, for informational purposes only. For any other
#  purpose, no part of the work may be utilized or reproduced, in any form
#  or by any means, without permission in writing from the publisher.
#
#  The work has been developed for automotive applications only. It has
#  neither been developed, nor tested for non-automotive applications.
#
#  The word AUTOSAR and the AUTOSAR logo are registered trademarks.
#  --------------------------------------------------------------------------

"""
Machine class.
"""

from ..utils.container import Container


class Machine(object):
    """Machine"""
    def __init__(self, fqn, em_info):
        self._processes = Container()
        self._ip_address = ""
        self._network_mask = ""
        self._sd_address = ""
        self._sd_port = ""
        self._fqn = fqn
        self._em_info = em_info


    def add_process(self, process):
        """Appends a process to the set of processes on the machine"""
        self._processes.add(process)

    @property
    def processes(self):
        """Getter"""
        return self._processes

    @property
    def name(self):
        return self._fqn.split("/")[-1]

    @property
    def ip_address(self):
        """Get the ip assigned to the machine"""
        return self._ip_address

    @ip_address.setter
    def ip_address(self, ip_address: str):
        """Set the ip address of the machine"""
        self._ip_address = ip_address

    @property
    def network_mask(self):
        """Get the network mask for the machine"""
        return self._network_mask

    @network_mask.setter
    def network_mask(self, network_mask: str):
        """Set the network mask to specify the subnet of the machine"""
        self._network_mask = network_mask

    @property
    def sd_address(self):
        """Get the SD multicast address assigned to the machine"""
        return self._sd_address

    @sd_address.setter
    def sd_address(self, ip_address: str):
        """Set the SD multicast address of the machine"""
        self._sd_address = ip_address

    @property
    def sd_port(self):
        """Get the SD port number of the machine"""
        return self._sd_port

    @sd_port.setter
    def sd_port(self, port: str):
        """Set the SD port number of the machine"""
        self._sd_port = port

    @property
    def fqn(self):
        return self._fqn

    @property
    def em_info(self):
        return self._em_info
