#  --------------------------------------------------------------------------
#  |              _    _ _______     .----.      _____         _____        |
#  |         /\  | |  | |__   __|  .  ____ .    / ____|  /\   |  __ \       |
#  |        /  \ | |  | |  | |    .  / __ \ .  | (___   /  \  | |__) |      |
#  |       / /\ \| |  | |  | |   .  / / / / v   \___ \ / /\ \ |  _  /       |
#  |      / /__\ \ |__| |  | |   . / /_/ /  .   ____) / /__\ \| | \ \       |
#  |     /________\____/   |_|   ^ \____/  .   |_____/________\_|  \_\      |
#  |                              . _ _  .                                  |
#  --------------------------------------------------------------------------
#
#  All Rights Reserved.
#  Any use of this source code is subject to a license agreement with the
#  AUTOSAR development cooperation.
#  More information is available at www.autosar.org.
#
#  Disclaimer
#
#  This work (specification and/or software implementation) and the material
#  contained in it, as released by AUTOSAR, is for the purpose of information
#  only. AUTOSAR and the companies that have contributed to it shall not be
#  liable for any use of the work.
#
#  The material contained in this work is protected by copyright and other
#  types of intellectual property rights. The commercial exploitation of the
#  material contained in this work requires a license to such intellectual
#  property rights.
#
#  This work may be utilized or reproduced without any modification, in any
#  form or by any means, for informational purposes only. For any other
#  purpose, no part of the work may be utilized or reproduced, in any form
#  or by any means, without permission in writing from the publisher.
#
#  The work has been developed for automotive applications only. It has
#  neither been developed, nor tested for non-automotive applications.
#
#  The word AUTOSAR and the AUTOSAR logo are registered trademarks.
#  --------------------------------------------------------------------------

"""
TransformationPropsToServiceInterfaceElementMapping class.
"""
from generator.intermediate_model.communication_management.tld_data_id_definition import TlvDataIdDefinition
from generator.intermediate_model.communication_management.ap_someip_transformation_props import \
    ApSomeipTransformationProps


class TransformationPropsToServiceInterfaceElementMapping(object):
    def __init__(self, name: str) -> None:
        super().__init__()

        if name == "":
            raise AttributeError("A TransformationPropsToServiceInterfaceElementMapping must have a name")
        self._name = name
        self._data_ids = []
        self._transformation_props = None
        self._event_references = None
        self._method_references = None
        self._field_references = None

    @property
    def data_ids(self) -> [TlvDataIdDefinition]:
        """Get the implementation data type of this Field."""
        return self._data_ids

    @data_ids.setter
    def data_ids(self, data_ids: [TlvDataIdDefinition]):
        """Set the implementation data type of this Field."""
        self._data_ids = data_ids

    @property
    def transformation_props(self) -> ApSomeipTransformationProps:
        """Get the referenced AP SOMEIP transformation properties."""
        return self._transformation_props

    @transformation_props.setter
    def transformation_props(self, transformation_props: ApSomeipTransformationProps):
        """Set the referenced AP SOMEIP transformation properties."""
        self._transformation_props = transformation_props

    @property
    def event_references(self) -> [str]:
        """Get the list of referenced events."""
        return self._event_references

    @event_references.setter
    def event_references(self, event_references: [str]):
        """Set the list of referenced events."""
        self._event_references = event_references

    @property
    def method_references(self) -> [str]:
        """Get the list of referenced methods."""
        return self._method_references

    @method_references.setter
    def method_references(self, method_references: [str]):
        """Set the list of referenced methods."""
        self._method_references = method_references

    @property
    def field_references(self) -> [str]:
        """Get the list of referenced fields."""
        return self._field_references

    @field_references.setter
    def field_references(self, field_references: [str]):
        """Set the list of referenced fields."""
        self._field_references = field_references
