// --------------------------------------------------------------------------
// |              _    _ _______     .----.      _____         _____        |
// |         /\  | |  | |__   __|  .  ____ .    / ____|  /\   |  __ \       |
// |        /  \ | |  | |  | |    .  / __ \ .  | (___   /  \  | |__) |      |
// |       / /\ \| |  | |  | |   .  / / / / v   \___ \ / /\ \ |  _  /       |
// |      / /__\ \ |__| |  | |   . / /_/ /  .   ____) / /__\ \| | \ \       |
// |     /________\____/   |_|   ^ \____/  .   |_____/________\_|  \_\      |
// |                              . _ _  .                                  |
// --------------------------------------------------------------------------
//
// All Rights Reserved.
// Any use of this source code is subject to a license agreement with the
// AUTOSAR development cooperation.
// More information is available at www.autosar.org.
//
// Disclaimer
//
// This work (specification and/or software implementation) and the material
// contained in it, as released by AUTOSAR, is for the purpose of information
// only. AUTOSAR and the companies that have contributed to it shall not be
// liable for any use of the work.
//
// The material contained in this work is protected by copyright and other
// types of intellectual property rights. The commercial exploitation of the
// material contained in this work requires a license to such intellectual
// property rights.
//
// This work may be utilized or reproduced without any modification, in any
// form or by any means, for informational purposes only. For any other
// purpose, no part of the work may be utilized or reproduced, in any form
// or by any means, without permission in writing from the publisher.
//
// The work has been developed for automotive applications only. It has
// neither been developed, nor tested for non-automotive applications.
//
// The word AUTOSAR and the AUTOSAR logo are registered trademarks.
// --------------------------------------------------------------------------

#ifndef franca_sample_includes_flaveratesttestbookend2_skeleton_h
#define franca_sample_includes_flaveratesttestbookend2_skeleton_h

#include "ara/com/internal/skeleton/ara_skeleton_base.h"

#include "ara/com/illegal_state_exception.h"
#include "flaveratesttestbookend2_common.h"

namespace skeleton {



/// @uptrace{SWS_CM_00002}
class flaverATesttestBookend2Skeleton : public ::flaverATesttestBookend2, public ara::com::internal::skeleton::TypedServiceImplBase<flaverATesttestBookend2Skeleton> {
public:
  /// @uptrace{SWS_CM_00130}
  flaverATesttestBookend2Skeleton(ara::com::InstanceIdentifier instance_id, ara::com::MethodCallProcessingMode mode = ara::com::MethodCallProcessingMode::kEvent) : ara::com::internal::skeleton::TypedServiceImplBase<flaverATesttestBookend2Skeleton>(instance_id, mode) {}
  virtual ~flaverATesttestBookend2Skeleton() {
    StopOfferService();
  }

  /// @brief Skeleton shall be move constructable.
  ///
  /// @uptrace{SWS_CM_00135}
  explicit flaverATesttestBookend2Skeleton(flaverATesttestBookend2Skeleton&&) = default;

  /// @brief Skeleton shall be move assignable.
  ///
  /// @uptrace{SWS_CM_00135}
  flaverATesttestBookend2Skeleton& operator=(flaverATesttestBookend2Skeleton&&) = default;

  /// @brief Skeleton shall not be copy constructable.
  ///
  /// @uptrace{SWS_CM_00134}
  explicit flaverATesttestBookend2Skeleton(const flaverATesttestBookend2Skeleton&) = delete;

  /// @brief Skeleton shall not be copy assignable.
  ///
  /// @uptrace{SWS_CM_00134}
  flaverATesttestBookend2Skeleton& operator=(const flaverATesttestBookend2Skeleton&) = delete;

  void OfferService() {

    ara::com::internal::skeleton::TypedServiceImplBase<flaverATesttestBookend2Skeleton>::OfferService();
  }

  /// @uptrace{SWS_CM_00191}
  using ::flaverATesttestBookend2::requstAttributesOutput;
  virtual ara::core::Future<requstAttributesOutput> requstAttributes(const ::UInt32& edgesOfIterest) = 0;
};

} // namespace skeleton

#endif // franca_sample_includes_flaveratesttestbookend2_skeleton_h

