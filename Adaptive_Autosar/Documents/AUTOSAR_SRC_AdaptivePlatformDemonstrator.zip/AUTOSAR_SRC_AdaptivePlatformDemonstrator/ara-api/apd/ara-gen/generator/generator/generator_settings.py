#  --------------------------------------------------------------------------
#  |              _    _ _______     .----.      _____         _____        |
#  |         /\  | |  | |__   __|  .  ____ .    / ____|  /\   |  __ \       |
#  |        /  \ | |  | |  | |    .  / __ \ .  | (___   /  \  | |__) |      |
#  |       / /\ \| |  | |  | |   .  / / / / v   \___ \ / /\ \ |  _  /       |
#  |      / /__\ \ |__| |  | |   . / /_/ /  .   ____) / /__\ \| | \ \       |
#  |     /________\____/   |_|   ^ \____/  .   |_____/________\_|  \_\      |
#  |                              . _ _  .                                  |
#  --------------------------------------------------------------------------
#
#  All Rights Reserved.
#  Any use of this source code is subject to a license agreement with the
#  AUTOSAR development cooperation.
#  More information is available at www.autosar.org.
#
#  Disclaimer
#
#  This work (specification and/or software implementation) and the material
#  contained in it, as released by AUTOSAR, is for the purpose of information
#  only. AUTOSAR and the companies that have contributed to it shall not be
#  liable for any use of the work.
#
#  The material contained in this work is protected by copyright and other
#  types of intellectual property rights. The commercial exploitation of the
#  material contained in this work requires a license to such intellectual
#  property rights.
#
#  This work may be utilized or reproduced without any modification, in any
#  form or by any means, for informational purposes only. For any other
#  purpose, no part of the work may be utilized or reproduced, in any form
#  or by any means, without permission in writing from the publisher.
#
#  The work has been developed for automotive applications only. It has
#  neither been developed, nor tested for non-automotive applications.
#
#  The word AUTOSAR and the AUTOSAR logo are registered trademarks.
#  --------------------------------------------------------------------------

"""
Generator Settings
"""

import os
import logging
import sys
from typing import ItemsView

from generator.generator.loggingsettings import LoggingSettings

class GeneratorSettings(object):
    """
    Convenience class for storing and accessing a set of settings for the generator.
    """

    def __init__(self, args):
        self._args = args
        self._log = logging.getLogger(__name__)
        self._logging_settings = LoggingSettings(
            self.log_level,
            self.use_console_for_logging,
            self.use_dlt_for_logging,
            self.use_file_for_logging,
            self.log_file_path)

        if not self.output_dir:
            self._log.error("The generator must be given an output directory as an input")
            sys.exit("error: the following arguments are required: -o/--output, file\n")

    def __getattr__(self, item):
        # pass through getters to underlying args object
        return getattr(self._args, item)

    @property
    def configuration_dump(self):
        result = []
        result += ["config: {}".format(self.config)]
        result += ["debug: {}".format(self.debug)]
        result += ["dry_run: {}".format(self.dry_run)]
        result += ["generate: {}".format(self.generate)]
        result += ["list_files: {}".format(self.list_files)]
        result += ["output_dir: {}".format(self.output_dir)]
        result += ["quiet: {}".format(self.quiet)]
        result += ["target_machines: {}".format(self.machines)]
        result += ["target_applications: {}".format(self.applications)]
        result += ["verbose: {}".format(self.verbose)]
        result += ["logging_settings: "]
        result += self.logging_settings.configuration_dump
        return result

    @property
    def logging_settings(self) -> LoggingSettings:
        """Get logging settings"""
        return self._logging_settings

