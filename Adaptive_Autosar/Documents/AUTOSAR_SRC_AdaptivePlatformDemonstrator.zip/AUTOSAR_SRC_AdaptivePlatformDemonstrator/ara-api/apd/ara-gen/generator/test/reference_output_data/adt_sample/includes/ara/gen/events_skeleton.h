// --------------------------------------------------------------------------
// |              _    _ _______     .----.      _____         _____        |
// |         /\  | |  | |__   __|  .  ____ .    / ____|  /\   |  __ \       |
// |        /  \ | |  | |  | |    .  / __ \ .  | (___   /  \  | |__) |      |
// |       / /\ \| |  | |  | |   .  / / / / v   \___ \ / /\ \ |  _  /       |
// |      / /__\ \ |__| |  | |   . / /_/ /  .   ____) / /__\ \| | \ \       |
// |     /________\____/   |_|   ^ \____/  .   |_____/________\_|  \_\      |
// |                              . _ _  .                                  |
// --------------------------------------------------------------------------
//
// All Rights Reserved.
// Any use of this source code is subject to a license agreement with the
// AUTOSAR development cooperation.
// More information is available at www.autosar.org.
//
// Disclaimer
//
// This work (specification and/or software implementation) and the material
// contained in it, as released by AUTOSAR, is for the purpose of information
// only. AUTOSAR and the companies that have contributed to it shall not be
// liable for any use of the work.
//
// The material contained in this work is protected by copyright and other
// types of intellectual property rights. The commercial exploitation of the
// material contained in this work requires a license to such intellectual
// property rights.
//
// This work may be utilized or reproduced without any modification, in any
// form or by any means, for informational purposes only. For any other
// purpose, no part of the work may be utilized or reproduced, in any form
// or by any means, without permission in writing from the publisher.
//
// The work has been developed for automotive applications only. It has
// neither been developed, nor tested for non-automotive applications.
//
// The word AUTOSAR and the AUTOSAR logo are registered trademarks.
// --------------------------------------------------------------------------

#ifndef adt_sample_includes_ara_gen_events_skeleton_h
#define adt_sample_includes_ara_gen_events_skeleton_h

#include "ara/com/internal/skeleton/ara_skeleton_base.h"

#include "ara/com/illegal_state_exception.h"
#include "events_common.h"

namespace ara {
namespace gen {
namespace skeleton {


namespace events {
  /// @uptrace{SWS_CM_00003}
  using Array = ara::com::internal::skeleton::EventDispatcher<::ArrayCppIdt>;
  using Vector = ara::com::internal::skeleton::EventDispatcher<::VectorCppIdt>;
  using ArrayOfStruct = ara::com::internal::skeleton::EventDispatcher<::ComplexCppIdt_ArrayOfStruct>;
  using StructOfArray = ara::com::internal::skeleton::EventDispatcher<::ComplexCppIdt_StructOfArray>;
  using Structure = ara::com::internal::skeleton::EventDispatcher<::StructureCppIdt>;
  using TypeRef = ara::com::internal::skeleton::EventDispatcher<::TypeRefCppIdt>;
} // namespace events

/// @uptrace{SWS_CM_00002}
class eventsSkeleton : public ara::gen::events, public ara::com::internal::skeleton::TypedServiceImplBase<eventsSkeleton> {
public:
  /// @uptrace{SWS_CM_00130}
  eventsSkeleton(ara::com::InstanceIdentifier instance_id, ara::com::MethodCallProcessingMode mode = ara::com::MethodCallProcessingMode::kEvent) : ara::com::internal::skeleton::TypedServiceImplBase<eventsSkeleton>(instance_id, mode) {}
  virtual ~eventsSkeleton() {
    StopOfferService();
  }

  /// @brief Skeleton shall be move constructable.
  ///
  /// @uptrace{SWS_CM_00135}
  explicit eventsSkeleton(eventsSkeleton&&) = default;

  /// @brief Skeleton shall be move assignable.
  ///
  /// @uptrace{SWS_CM_00135}
  eventsSkeleton& operator=(eventsSkeleton&&) = default;

  /// @brief Skeleton shall not be copy constructable.
  ///
  /// @uptrace{SWS_CM_00134}
  explicit eventsSkeleton(const eventsSkeleton&) = delete;

  /// @brief Skeleton shall not be copy assignable.
  ///
  /// @uptrace{SWS_CM_00134}
  eventsSkeleton& operator=(const eventsSkeleton&) = delete;

  void OfferService() {

    ara::com::internal::skeleton::TypedServiceImplBase<eventsSkeleton>::OfferService();
  }

  events::Array Array;
  events::Vector Vector;
  events::ArrayOfStruct ArrayOfStruct;
  events::StructOfArray StructOfArray;
  events::Structure Structure;
  events::TypeRef TypeRef;
};

} // namespace skeleton
} // namespace gen
} // namespace ara

#endif // adt_sample_includes_ara_gen_events_skeleton_h

