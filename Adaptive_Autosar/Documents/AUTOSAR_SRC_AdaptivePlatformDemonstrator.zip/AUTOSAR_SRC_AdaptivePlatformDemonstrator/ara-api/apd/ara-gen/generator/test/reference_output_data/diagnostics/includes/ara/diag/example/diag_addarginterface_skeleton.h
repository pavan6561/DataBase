// --------------------------------------------------------------------------
// |              _    _ _______     .----.      _____         _____        |
// |         /\  | |  | |__   __|  .  ____ .    / ____|  /\   |  __ \       |
// |        /  \ | |  | |  | |    .  / __ \ .  | (___   /  \  | |__) |      |
// |       / /\ \| |  | |  | |   .  / / / / v   \___ \ / /\ \ |  _  /       |
// |      / /__\ \ |__| |  | |   . / /_/ /  .   ____) / /__\ \| | \ \       |
// |     /________\____/   |_|   ^ \____/  .   |_____/________\_|  \_\      |
// |                              . _ _  .                                  |
// --------------------------------------------------------------------------
//
// All Rights Reserved.
// Any use of this source code is subject to a license agreement with the
// AUTOSAR development cooperation.
// More information is available at www.autosar.org.
//
// Disclaimer
//
// This work (specification and/or software implementation) and the material
// contained in it, as released by AUTOSAR, is for the purpose of information
// only. AUTOSAR and the companies that have contributed to it shall not be
// liable for any use of the work.
//
// The material contained in this work is protected by copyright and other
// types of intellectual property rights. The commercial exploitation of the
// material contained in this work requires a license to such intellectual
// property rights.
//
// This work may be utilized or reproduced without any modification, in any
// form or by any means, for informational purposes only. For any other
// purpose, no part of the work may be utilized or reproduced, in any form
// or by any means, without permission in writing from the publisher.
//
// The work has been developed for automotive applications only. It has
// neither been developed, nor tested for non-automotive applications.
//
// The word AUTOSAR and the AUTOSAR logo are registered trademarks.
// --------------------------------------------------------------------------

#ifndef diagnostics_includes_ara_diag_example_diag_addarginterface_skeleton_h
#define diagnostics_includes_ara_diag_example_diag_addarginterface_skeleton_h

#include "ara/com/internal/skeleton/ara_skeleton_base.h"

#include "ara/com/illegal_state_exception.h"
#include "diag_addarginterface_common.h"

namespace ara {
namespace diag {
namespace example {
namespace skeleton {



/// @uptrace{SWS_CM_00002}
class Diag_AddArgInterfaceSkeleton : public ara::diag::example::Diag_AddArgInterface, public ara::com::internal::skeleton::TypedServiceImplBase<Diag_AddArgInterfaceSkeleton> {
public:
  /// @uptrace{SWS_CM_00130}
  Diag_AddArgInterfaceSkeleton(ara::com::InstanceIdentifier instance_id, ara::com::MethodCallProcessingMode mode = ara::com::MethodCallProcessingMode::kEvent) : ara::com::internal::skeleton::TypedServiceImplBase<Diag_AddArgInterfaceSkeleton>(instance_id, mode) {}
  virtual ~Diag_AddArgInterfaceSkeleton() {
    StopOfferService();
  }

  /// @brief Skeleton shall be move constructable.
  ///
  /// @uptrace{SWS_CM_00135}
  explicit Diag_AddArgInterfaceSkeleton(Diag_AddArgInterfaceSkeleton&&) = default;

  /// @brief Skeleton shall be move assignable.
  ///
  /// @uptrace{SWS_CM_00135}
  Diag_AddArgInterfaceSkeleton& operator=(Diag_AddArgInterfaceSkeleton&&) = default;

  /// @brief Skeleton shall not be copy constructable.
  ///
  /// @uptrace{SWS_CM_00134}
  explicit Diag_AddArgInterfaceSkeleton(const Diag_AddArgInterfaceSkeleton&) = delete;

  /// @brief Skeleton shall not be copy assignable.
  ///
  /// @uptrace{SWS_CM_00134}
  Diag_AddArgInterfaceSkeleton& operator=(const Diag_AddArgInterfaceSkeleton&) = delete;

  void OfferService() {

    ara::com::internal::skeleton::TypedServiceImplBase<Diag_AddArgInterfaceSkeleton>::OfferService();
  }

  /// @uptrace{SWS_CM_00191}
  using ara::diag::example::Diag_AddArgInterface::AddArgMethod_StartOutput;
  virtual ara::core::Future<AddArgMethod_StartOutput> AddArgMethod_Start(const std::int32_t& arg) = 0;
  using ara::diag::example::Diag_AddArgInterface::AddArgMethod_StopOutput;
  virtual ara::core::Future<AddArgMethod_StopOutput> AddArgMethod_Stop() = 0;
};

} // namespace skeleton
} // namespace example
} // namespace diag
} // namespace ara

#endif // diagnostics_includes_ara_diag_example_diag_addarginterface_skeleton_h

