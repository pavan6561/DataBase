#  --------------------------------------------------------------------------
#  |              _    _ _______     .----.      _____         _____        |
#  |         /\  | |  | |__   __|  .  ____ .    / ____|  /\   |  __ \       |
#  |        /  \ | |  | |  | |    .  / __ \ .  | (___   /  \  | |__) |      |
#  |       / /\ \| |  | |  | |   .  / / / / v   \___ \ / /\ \ |  _  /       |
#  |      / /__\ \ |__| |  | |   . / /_/ /  .   ____) / /__\ \| | \ \       |
#  |     /________\____/   |_|   ^ \____/  .   |_____/________\_|  \_\      |
#  |                              . _ _  .                                  |
#  --------------------------------------------------------------------------
#
#  All Rights Reserved.
#  Any use of this source code is subject to a license agreement with the
#  AUTOSAR development cooperation.
#  More information is available at www.autosar.org.
#
#  Disclaimer
#
#  This work (specification and/or software implementation) and the material
#  contained in it, as released by AUTOSAR, is for the purpose of information
#  only. AUTOSAR and the companies that have contributed to it shall not be
#  liable for any use of the work.
#
#  The material contained in this work is protected by copyright and other
#  types of intellectual property rights. The commercial exploitation of the
#  material contained in this work requires a license to such intellectual
#  property rights.
#
#  This work may be utilized or reproduced without any modification, in any
#  form or by any means, for informational purposes only. For any other
#  purpose, no part of the work may be utilized or reproduced, in any form
#  or by any means, without permission in writing from the publisher.
#
#  The work has been developed for automotive applications only. It has
#  neither been developed, nor tested for non-automotive applications.
#
#  The word AUTOSAR and the AUTOSAR logo are registered trademarks.
#  --------------------------------------------------------------------------

"""
Component class.
"""

from ..utils.container import Container
from ..communication_management.service import Service


class Component(object):
    """An Adaptive Component corresponds to one functional
    entity capable of communicating via ara::com"""
    def __init__(self, name, fqn=None):
        if name == "":
            raise AssertionError("A component must have a name")
        self._name = name
        self._required_services = Container()
        self._provided_services = Container()
        self._fqn = fqn

    def add_required_service(self, service: Service):
        """Adds the service to the set of services in this component,
        the set is composed of all services required or provided
        by the component"""
        self._required_services.add(service)

    def add_provided_service(self, service: Service):
        """Adds the service to the set of services in this component,
        the set is composed of all services required or provided
        by the component"""
        self._provided_services.add(service)

    @property
    def name(self) -> str:
        """Get the name of the component"""
        return self._name

    @property
    def fqn(self) -> str:
        """Get the fqn of the component"""
        return self._fqn

    @fqn.setter
    def fqn(self, fqn: str):
        """Set the fqn of the component"""
        self._fqn = fqn

    @property
    def required_services(self) -> [Service]:
        """Get the set of services belonging to this Component"""
        return self._required_services

    @property
    def provided_services(self) -> [Service]:
        """Get the set of services belonging to this Component"""
        return self._provided_services

    @property
    def services(self) -> [Service]:
        return self._provided_services + self._required_services
