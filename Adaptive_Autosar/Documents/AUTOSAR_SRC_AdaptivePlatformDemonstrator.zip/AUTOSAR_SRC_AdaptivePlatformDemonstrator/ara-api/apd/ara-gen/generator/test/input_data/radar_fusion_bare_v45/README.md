The ARXML files contained here are considered the bare minimum required to set
up communication between a service provider and a corresponding consumer.
