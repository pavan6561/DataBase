// --------------------------------------------------------------------------
// |              _    _ _______     .----.      _____         _____        |
// |         /\  | |  | |__   __|  .  ____ .    / ____|  /\   |  __ \       |
// |        /  \ | |  | |  | |    .  / __ \ .  | (___   /  \  | |__) |      |
// |       / /\ \| |  | |  | |   .  / / / / v   \___ \ / /\ \ |  _  /       |
// |      / /__\ \ |__| |  | |   . / /_/ /  .   ____) / /__\ \| | \ \       |
// |     /________\____/   |_|   ^ \____/  .   |_____/________\_|  \_\      |
// |                              . _ _  .                                  |
// --------------------------------------------------------------------------
//
// All Rights Reserved.
// Any use of this source code is subject to a license agreement with the
// AUTOSAR development cooperation.
// More information is available at www.autosar.org.
//
// Disclaimer
//
// This work (specification and/or software implementation) and the material
// contained in it, as released by AUTOSAR, is for the purpose of information
// only. AUTOSAR and the companies that have contributed to it shall not be
// liable for any use of the work.
//
// The material contained in this work is protected by copyright and other
// types of intellectual property rights. The commercial exploitation of the
// material contained in this work requires a license to such intellectual
// property rights.
//
// This work may be utilized or reproduced without any modification, in any
// form or by any means, for informational purposes only. For any other
// purpose, no part of the work may be utilized or reproduced, in any form
// or by any means, without permission in writing from the publisher.
//
// The work has been developed for automotive applications only. It has
// neither been developed, nor tested for non-automotive applications.
//
// The word AUTOSAR and the AUTOSAR logo are registered trademarks.
// --------------------------------------------------------------------------

#ifndef radar_fusion_extended_proloc_bosch_da_proloc_service_desc_radar_h
#define radar_fusion_extended_proloc_bosch_da_proloc_service_desc_radar_h

#include "bosch/da/radar_common.h"
#include "bosch/da/radar_skeleton.h"

#include "ara/com/internal/proloc/proxy/proloc_proxy_base.h"
#include "ara/com/internal/proloc/skeleton/proloc_skeleton_base.h"

#include "proloc_adapter_radar.h"

namespace bosch {
namespace da {
namespace radar_binding {
namespace proloc {

class radarImpl;
class radarServiceAdapter;

namespace descriptors {

namespace internal {
    struct Service {
        using skeleton = skeleton::radarSkeleton;
        using adapter = radarServiceAdapter;
    };
}

struct Adjust: public internal::Service {
  using element_type = ara::core::Future<::bosch::da::radar::AdjustOutput> (skeleton::*)(const ::Position&);
  static constexpr element_type element = &skeleton::Adjust;
};
              
struct Calibrate: public internal::Service {
  using element_type = ara::core::Future<::bosch::da::radar::CalibrateOutput> (skeleton::*)(const ::String&,const ::FusionVariant&);
  static constexpr element_type element = &skeleton::Calibrate;
};
              
struct UpdateRate : public internal::Service {
  using element_type = ara::com::internal::proloc::skeleton::MutableFieldImpl<::UInt32> (adapter::*);
  static constexpr element_type element = &adapter::UpdateRate;

};
struct FrontObjectDistance : public internal::Service {
  using element_type = ara::com::internal::proloc::skeleton::FieldImpl<::UInt16> (adapter::*);
  static constexpr element_type element = &adapter::FrontObjectDistance;

};
struct RearObjectDistance : public internal::Service {
  using element_type = ara::com::internal::proloc::skeleton::FieldImpl<::UInt16> (adapter::*);
  static constexpr element_type element = &adapter::RearObjectDistance;

};
struct ObjectDetectionLimit : public internal::Service {
  using element_type = ara::com::internal::proloc::skeleton::MutableFieldImpl<::UInt16> (adapter::*);
  static constexpr element_type element = &adapter::ObjectDetectionLimit;

};
struct brakeEvent : public internal::Service {
  using element_type = ara::com::internal::proloc::skeleton::EventImpl<::RadarObjects> (adapter::*);
  static constexpr element_type element = &adapter::brakeEvent;

};
struct parkingBrakeEvent : public internal::Service {
  using element_type = ara::com::internal::proloc::skeleton::EventImpl<::RadarObjects> (adapter::*);
  static constexpr element_type element = &adapter::parkingBrakeEvent;

};
struct driveEvent : public internal::Service {
  using element_type = ara::com::internal::proloc::skeleton::EventImpl<::RadarObjects> (adapter::*);
  static constexpr element_type element = &adapter::driveEvent;

};
} // namespace descriptors
} // namespace proloc
} // namespace radar_binding
} // namespace da
} // namespace bosch

#endif // radar_fusion_extended_proloc_bosch_da_proloc_service_desc_radar_h

