#  --------------------------------------------------------------------------
#  |              _    _ _______     .----.      _____         _____        |
#  |         /\  | |  | |__   __|  .  ____ .    / ____|  /\   |  __ \       |
#  |        /  \ | |  | |  | |    .  / __ \ .  | (___   /  \  | |__) |      |
#  |       / /\ \| |  | |  | |   .  / / / / v   \___ \ / /\ \ |  _  /       |
#  |      / /__\ \ |__| |  | |   . / /_/ /  .   ____) / /__\ \| | \ \       |
#  |     /________\____/   |_|   ^ \____/  .   |_____/________\_|  \_\      |
#  |                              . _ _  .                                  |
#  --------------------------------------------------------------------------
#
#  All Rights Reserved.
#  Any use of this source code is subject to a license agreement with the
#  AUTOSAR development cooperation.
#  More information is available at www.autosar.org.
#
#  Disclaimer
#
#  This work (specification and/or software implementation) and the material
#  contained in it, as released by AUTOSAR, is for the purpose of information
#  only. AUTOSAR and the companies that have contributed to it shall not be
#  liable for any use of the work.
#
#  The material contained in this work is protected by copyright and other
#  types of intellectual property rights. The commercial exploitation of the
#  material contained in this work requires a license to such intellectual
#  property rights.
#
#  This work may be utilized or reproduced without any modification, in any
#  form or by any means, for informational purposes only. For any other
#  purpose, no part of the work may be utilized or reproduced, in any form
#  or by any means, without permission in writing from the publisher.
#
#  The work has been developed for automotive applications only. It has
#  neither been developed, nor tested for non-automotive applications.
#
#  The word AUTOSAR and the AUTOSAR logo are registered trademarks.
#  --------------------------------------------------------------------------

"""
ServiceView corresponding to a Service IM object.
"""

from generator.intermediate_model.communication_management.service \
    import Service
from generator.views.view import View
from generator.views.error_view import ErrorView
from generator.views.event_view import EventView
from generator.views.field_view import FieldView
from generator.views.method_view import MethodView


CPP_SCOPE_RES_OPERATOR = "::"
CPP_UNDERSCORE_DELIMITER = "_"
CPP_INCLUDE_PATH_SEPARATOR = "/"

class ServiceView(View):
    """Specialized View of a Service."""

    def __init__(self, service: Service) -> None:
        self._service = service
        super().__init__(service)

    def __eq__(self, other):
        if type(other) is ServiceView:
            return self.fqn == other.fqn
        return False

    def __lt__(self, other):
        return self.qualified_cpp_name.lower() < other.qualified_cpp_name.lower()

    def __hash__(self):
        return hash(self.fqn)

    @property
    def absolute_namespace(self):
        """Get the global scoped namespace of this ServiceView."""
        if self.namespaces is not None:
            return CPP_SCOPE_RES_OPERATOR.join(self.namespaces)

    @property
    def get_namespace_as_include(self):
        """
        Get the global scoped namespace of this service separated by /
        """
        if self.namespaces is not None:
            return CPP_INCLUDE_PATH_SEPARATOR.join(self.namespaces)

    @property
    def deployment_id(self):
        """Get the service id"""
        return hex(int(self._service.service_deployment.deployment_id))

    @property
    def instance_id(self):
        return hex(int(self._service.service_deployment.instance_id))

    @property
    def events(self):
        """Get the events as EventViews for this service"""
        event_views = list()
        for event in self._service.events:
            event_views.append(EventView(event))
        return event_views

    @property
    def methods(self):
        """Get the methods as MethodViews for this service"""
        method_views = list()
        for method in self._service.methods:
            method_views.append(MethodView(method))
        return method_views

    @property
    def all_fields(self):
        """Get the fields as FieldViews for this service"""
        field_views = list()
        for field in self._service.fields:
            field_views.append(FieldView(field))

        return field_views

    @property
    def includes(self):
        """Get the include statements required by the service interface"""
        includes = set()

        args = []
        for method in self.methods:
            args.extend(method.get_args)

        for arg in args:
            includes.add(arg.type_include)

        for event in self.events:
            includes.add(event.type_include)

        for field in self.all_fields:
            includes.add(field.type_include)

        #filter out empty includes (for bool etc.)
        include_list = list(filter(None, includes))
        include_list.sort()

        error_domains_includes = set()
        for method in self.methods:
            for error_domain in method.error_domains:
                error_domains_includes.add(error_domain.include_name)

        error_domains_includes_list = list(error_domains_includes)
        error_domains_includes_list.sort()

        return include_list + error_domains_includes_list

    @property
    def possible_errors(self):
        """Get the possible errors for this service"""
        possible_errors = []
        for error in self._service.errors:
            if error is not None:
                possible_errors.append(ErrorView(error))
        return possible_errors

    def get_error_method_name(self, error):
        """Get the name of the method which is referencing this error"""
        if error.error.error_contexts:
            error_context_fqn = error.error.error_contexts[0].referable_fqn
            method_name = error_context_fqn.split("/")[-2]
            return method_name
        return ""

    @property
    def version(self):
        """Get the service version of this service"""
        if self._service.version is not None:
            return self._service.version
        return "0x01000000"

    @property
    def qualified_cpp_name(self):
        """
        Get the fully qualified cpp name of this service,
        IE namespace::name
        """
        fqn = []
        if self.namespaces is not None:
            fqn.extend(self.namespaces)
        fqn.append(self.name)
        return CPP_SCOPE_RES_OPERATOR.join(fqn)

    @property
    def event_impl_type_namespace(self):
        """Get the implementation data type namespace string for an event"""
        event_impl_namespaces = ""
        if self.namespaces is not None:
            event_impl_namespaces = CPP_SCOPE_RES_OPERATOR.join(self.namespaces) + CPP_SCOPE_RES_OPERATOR
        return CPP_SCOPE_RES_OPERATOR + event_impl_namespaces + "events" + CPP_SCOPE_RES_OPERATOR

    @property
    def namespacepath(self):
        """Returns the namespace string as a path with slashes"""
        namespacepath = ""
        if self.namespaces is not None:
            namespacepath = CPP_INCLUDE_PATH_SEPARATOR.join(self.namespaces)
        return namespacepath + CPP_INCLUDE_PATH_SEPARATOR

    @property
    def packagepath(self):
        """to be removed once migration to this aragen is complete"""
        result = self.fqn
        parts = result.split("/")
        parts_modified = [x.lower() for x in parts[:-1]] + [parts[-1]]
        result = "/".join(parts_modified)
        return result

    @property
    def service_mapping_name(self):
        return "__".join(self.namespaces + [self.standard_name] + ["mapping"])
