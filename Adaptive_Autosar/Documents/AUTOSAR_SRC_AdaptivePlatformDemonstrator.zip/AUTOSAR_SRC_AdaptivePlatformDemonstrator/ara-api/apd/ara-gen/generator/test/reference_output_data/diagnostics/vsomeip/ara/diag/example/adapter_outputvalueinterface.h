// --------------------------------------------------------------------------
// |              _    _ _______     .----.      _____         _____        |
// |         /\  | |  | |__   __|  .  ____ .    / ____|  /\   |  __ \       |
// |        /  \ | |  | |  | |    .  / __ \ .  | (___   /  \  | |__) |      |
// |       / /\ \| |  | |  | |   .  / / / / v   \___ \ / /\ \ |  _  /       |
// |      / /__\ \ |__| |  | |   . / /_/ /  .   ____) / /__\ \| | \ \       |
// |     /________\____/   |_|   ^ \____/  .   |_____/________\_|  \_\      |
// |                              . _ _  .                                  |
// --------------------------------------------------------------------------
//
// All Rights Reserved.
// Any use of this source code is subject to a license agreement with the
// AUTOSAR development cooperation.
// More information is available at www.autosar.org.
//
// Disclaimer
//
// This work (specification and/or software implementation) and the material
// contained in it, as released by AUTOSAR, is for the purpose of information
// only. AUTOSAR and the companies that have contributed to it shall not be
// liable for any use of the work.
//
// The material contained in this work is protected by copyright and other
// types of intellectual property rights. The commercial exploitation of the
// material contained in this work requires a license to such intellectual
// property rights.
//
// This work may be utilized or reproduced without any modification, in any
// form or by any means, for informational purposes only. For any other
// purpose, no part of the work may be utilized or reproduced, in any form
// or by any means, without permission in writing from the publisher.
//
// The work has been developed for automotive applications only. It has
// neither been developed, nor tested for non-automotive applications.
//
// The word AUTOSAR and the AUTOSAR logo are registered trademarks.
// --------------------------------------------------------------------------

#ifndef diagnostics_vsomeip_ara_diag_example_adapter_outputvalueinterface_h
#define diagnostics_vsomeip_ara_diag_example_adapter_outputvalueinterface_h

#include "ara/com/internal/vsomeip/skeleton/vsomeip_skeleton_base.h"
#include "service_desc_outputvalueinterface.h"
#include "ara/diag/example/outputvalueinterface_skeleton.h"

namespace ara {
namespace diag {
namespace example {
namespace outputvalueinterface_binding {
namespace vsomeip {

class OutputValueInterfaceServiceAdapter : public ::ara::com::internal::vsomeip::skeleton::ServiceImplBase {
 public:
  using ServiceInterface = skeleton::OutputValueInterfaceSkeleton;
  using ServiceDescriptor = descriptors::internal::Service;

  OutputValueInterfaceServiceAdapter(ServiceInterface& service, ara::com::internal::InstanceId instance) :
    ::ara::com::internal::vsomeip::skeleton::ServiceImplBase(service, instance),
    OutputValue(instance) {
    Connect(service);
    OfferService(ServiceDescriptor::service_id, GetInstanceId(), ServiceDescriptor::service_version, ServiceDescriptor::minor_service_version);
    OfferField(ServiceDescriptor::service_id, GetInstanceId(), descriptors::OutputValue::event_id, descriptors::OutputValue::event_groups);
  }

  virtual ~OutputValueInterfaceServiceAdapter() {
    StopOfferField(descriptors::OutputValue::service_id, GetInstanceId(), descriptors::OutputValue::event_id);
    StopOfferService(ServiceDescriptor::service_id, GetInstanceId());
    Disconnect(dynamic_cast<ServiceInterface&>(service_));
  }

 private:
  void Connect(ServiceInterface& service) {
    service.AddDelegate(*this);
    service.OutputValue.AddDelegate(OutputValue);
  }

  void Disconnect(ServiceInterface& service) {
    service.RemoveDelegate(*this);
    service.OutputValue.RemoveDelegate(OutputValue);
  }

  ara::com::internal::vsomeip::skeleton::FieldImpl<std::int32_t, descriptors::OutputValue> OutputValue;
};

} // namespace vsomeip
} // namespace outputvalueinterface_binding
} // namespace example
} // namespace diag
} // namespace ara

#endif // diagnostics_vsomeip_ara_diag_example_adapter_outputvalueinterface_h

