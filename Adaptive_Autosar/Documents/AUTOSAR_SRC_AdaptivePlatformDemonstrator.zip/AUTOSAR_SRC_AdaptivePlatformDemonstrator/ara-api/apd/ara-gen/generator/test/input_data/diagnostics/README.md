# Diagnostics ARXML usage

## Diagnostic Manager

This is the current (CMakeLists function) call to the generator:

```
add_aragen(
  DESTINATION ${PROJECT_BINARY_DIR}/gen
  TARGET dmMiddlewareInterfaces
  SWC /ara/diag/DiagnosticManager/DiagnosticManagerSwComponent
  ARXMLS
      ${ARA_ARXMLS_DIR}/stdtypes.arxml
      ${ARA_MODEL_DIR}/diagnostics.arxml
      ${ARA_MODEL_DIR}/metainfo.arxml
      ${ARA_MODEL_DIR}/security_access.arxml
      ${ARA_MODEL_DIR}/service_ClearDTC.arxml
      ${ARA_MODEL_DIR}/service_DiagnosticCondition.arxml
      ${ARA_MODEL_DIR}/service_DiagnosticEvent.arxml
      ${ARA_MODEL_DIR}/service_DiagnosticEventNotification.arxml
      ${ARA_MODEL_DIR}/service_DiagnosticMonitor.arxml
      ${ARA_MODEL_DIR}/service_DiagnosticStatus.arxml
      ${ARA_MODEL_DIR}/service_DoIPGroupIdentification.arxml
      ${ARA_MODEL_DIR}/service_DTCInformation.arxml
      ${ARA_MODEL_DIR}/service_IndicatorStatus.arxml
      ${ARA_MODEL_DIR}/service_OperationCycle.arxml
      ${ARA_MODEL_DIR}/system_manifest.arxml
      ${ARA_MODEL_DIR}/system_manifest_eth.arxml
      ${ARA_MODEL_DIR}/system_manifest_security_access.arxml
)
```

Depending on the client side application, additional generation for the Diagnostic Manager is needed. Currently, there are two use cases:


## Calculator sample application, plugin part

In order to have the service interface skeletons for the sample application generated, a plugin needs to be compiled, which requires skeletons:

```
  add_aragen(
    DESTINATION ${PROJECT_BINARY_DIR}/gen
    TARGET dcmPluginCalculatorTyped
    SWC /ara/diag/example/dcmCalculatorPluginTyped
    ARXMLS
        ${ARA_ARXMLS_DIR}/stdtypes.arxml
        ${ARA_MODEL_DIR}/dcm_calculator_plugin_typed.arxml
        ${ARA_MODEL_DIR}/calculator.arxml
        ${ARA_MODEL_DIR}/system_manifest.arxml
        ${ARA_MODEL_DIR}/system_manifest_eth.arxml
  )
```


## System test, plugin part 

The system test application relies on a plugin in the Diagnostic Manager that allows for raw UDS communication. This needs the following service skeletons & proxies to be generated:

```
  add_aragen(
    DESTINATION ${PROJECT_BINARY_DIR}/gen
    TARGET dcmPluginRawUDS
    SWC /ara/diag/dcmPluginRawUDS/dcmPluginRawUDS
    ARXMLS
        ${ARA_ARXMLS_DIR}/stdtypes.arxml
        ${ARA_MODEL_DIR}/dcm_plugin_raw_diagnostics.arxml
        ${ARA_MODEL_DIR}/system_manifest.arxml
        ${ARA_MODEL_DIR}/system_manifest_eth.arxml
  )
```


