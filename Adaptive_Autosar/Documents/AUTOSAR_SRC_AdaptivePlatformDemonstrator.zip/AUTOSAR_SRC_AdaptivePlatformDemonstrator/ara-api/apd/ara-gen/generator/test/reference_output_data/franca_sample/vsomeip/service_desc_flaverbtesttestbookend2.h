// --------------------------------------------------------------------------
// |              _    _ _______     .----.      _____         _____        |
// |         /\  | |  | |__   __|  .  ____ .    / ____|  /\   |  __ \       |
// |        /  \ | |  | |  | |    .  / __ \ .  | (___   /  \  | |__) |      |
// |       / /\ \| |  | |  | |   .  / / / / v   \___ \ / /\ \ |  _  /       |
// |      / /__\ \ |__| |  | |   . / /_/ /  .   ____) / /__\ \| | \ \       |
// |     /________\____/   |_|   ^ \____/  .   |_____/________\_|  \_\      |
// |                              . _ _  .                                  |
// --------------------------------------------------------------------------
//
// All Rights Reserved.
// Any use of this source code is subject to a license agreement with the
// AUTOSAR development cooperation.
// More information is available at www.autosar.org.
//
// Disclaimer
//
// This work (specification and/or software implementation) and the material
// contained in it, as released by AUTOSAR, is for the purpose of information
// only. AUTOSAR and the companies that have contributed to it shall not be
// liable for any use of the work.
//
// The material contained in this work is protected by copyright and other
// types of intellectual property rights. The commercial exploitation of the
// material contained in this work requires a license to such intellectual
// property rights.
//
// This work may be utilized or reproduced without any modification, in any
// form or by any means, for informational purposes only. For any other
// purpose, no part of the work may be utilized or reproduced, in any form
// or by any means, without permission in writing from the publisher.
//
// The work has been developed for automotive applications only. It has
// neither been developed, nor tested for non-automotive applications.
//
// The word AUTOSAR and the AUTOSAR logo are registered trademarks.
// --------------------------------------------------------------------------

#ifndef franca_sample_vsomeip_service_desc_flaverbtesttestbookend2_h
#define franca_sample_vsomeip_service_desc_flaverbtesttestbookend2_h

#include "/flaverbtesttestbookend2_common.h"

#include "ara/com/internal/vsomeip/vsomeip_types.h"

namespace flaverbtesttestbookend2_binding {
namespace vsomeip {
namespace descriptors {


namespace internal {
    struct Service {
        static constexpr ara::com::internal::vsomeip::types::ServiceId service_id = 0x2d;
        static constexpr ara::com::internal::vsomeip::types::ServiceVersionMajor service_version = 0x1;
        static constexpr ara::com::internal::vsomeip::types::ServiceVersionMinor minor_service_version = 0x0;
    };
}

struct requstAttributes: public internal::Service {
  static constexpr ara::com::internal::vsomeip::types::MethodId method_id = 0x7530;
  static constexpr bool is_reliable = false;
};

struct input1 : public internal::Service {
    static constexpr ara::com::internal::vsomeip::types::EventId event_id = 0xa028;
    static constexpr ara::com::internal::vsomeip::types::MethodId get_method_id = 0x7531;
    static constexpr bool is_getter_reliable = false;
    static constexpr ara::com::internal::vsomeip::types::EventGroupId event_groups[] { 0xabe1 };
    static constexpr ara::com::internal::vsomeip::types::MethodId set_method_id = 0x7532;
    static constexpr bool is_setter_reliable = false;
};
struct input2 : public internal::Service {
    static constexpr ara::com::internal::vsomeip::types::EventId event_id = 0xa410;
    static constexpr ara::com::internal::vsomeip::types::MethodId get_method_id = 0x7533;
    static constexpr bool is_getter_reliable = false;
    static constexpr ara::com::internal::vsomeip::types::EventGroupId event_groups[] { 0xabe2 };
    static constexpr ara::com::internal::vsomeip::types::MethodId set_method_id = 0x7534;
    static constexpr bool is_setter_reliable = false;
};
struct attributeResponse1 : public internal::Service {
  static constexpr ara::com::internal::vsomeip::types::EventId event_id = 0x9c41;
  static constexpr ara::com::internal::vsomeip::types::EventGroupId event_groups[] { 0xafc9 };
};

struct attributeResponse2 : public internal::Service {
  static constexpr ara::com::internal::vsomeip::types::EventId event_id = 0x9c42;
  static constexpr ara::com::internal::vsomeip::types::EventGroupId event_groups[] { 0xafca };
};

struct attributeResponse3 : public internal::Service {
  static constexpr ara::com::internal::vsomeip::types::EventId event_id = 0x9c43;
  static constexpr ara::com::internal::vsomeip::types::EventGroupId event_groups[] { 0xafcb };
};

struct attributeResponse4 : public internal::Service {
  static constexpr ara::com::internal::vsomeip::types::EventId event_id = 0x9c44;
  static constexpr ara::com::internal::vsomeip::types::EventGroupId event_groups[] { 0xafcc };
};

struct attributeResponse5 : public internal::Service {
  static constexpr ara::com::internal::vsomeip::types::EventId event_id = 0x9c45;
  static constexpr ara::com::internal::vsomeip::types::EventGroupId event_groups[] { 0xafcd };
};

struct attributeResponse6 : public internal::Service {
  static constexpr ara::com::internal::vsomeip::types::EventId event_id = 0x9c46;
  static constexpr ara::com::internal::vsomeip::types::EventGroupId event_groups[] { 0xafce };
};

struct attributeResponse7 : public internal::Service {
  static constexpr ara::com::internal::vsomeip::types::EventId event_id = 0x9c47;
  static constexpr ara::com::internal::vsomeip::types::EventGroupId event_groups[] { 0xafcf };
};

} // namespace descriptors
} // namespace vsomeip
} // namespace flaverbtesttestbookend2_binding

#endif // franca_sample_vsomeip_service_desc_flaverbtesttestbookend2_h

