#  --------------------------------------------------------------------------
#  |              _    _ _______     .----.      _____         _____        |
#  |         /\  | |  | |__   __|  .  ____ .    / ____|  /\   |  __ \       |
#  |        /  \ | |  | |  | |    .  / __ \ .  | (___   /  \  | |__) |      |
#  |       / /\ \| |  | |  | |   .  / / / / v   \___ \ / /\ \ |  _  /       |
#  |      / /__\ \ |__| |  | |   . / /_/ /  .   ____) / /__\ \| | \ \       |
#  |     /________\____/   |_|   ^ \____/  .   |_____/________\_|  \_\      |
#  |                              . _ _  .                                  |
#  --------------------------------------------------------------------------
#
#  All Rights Reserved.
#  Any use of this source code is subject to a license agreement with the
#  AUTOSAR development cooperation.
#  More information is available at www.autosar.org.
#
#  Disclaimer
#
#  This work (specification and/or software implementation) and the material
#  contained in it, as released by AUTOSAR, is for the purpose of information
#  only. AUTOSAR and the companies that have contributed to it shall not be
#  liable for any use of the work.
#
#  The material contained in this work is protected by copyright and other
#  types of intellectual property rights. The commercial exploitation of the
#  material contained in this work requires a license to such intellectual
#  property rights.
#
#  This work may be utilized or reproduced without any modification, in any
#  form or by any means, for informational purposes only. For any other
#  purpose, no part of the work may be utilized or reproduced, in any form
#  or by any means, without permission in writing from the publisher.
#
#  The work has been developed for automotive applications only. It has
#  neither been developed, nor tested for non-automotive applications.
#
#  The word AUTOSAR and the AUTOSAR logo are registered trademarks.
#  --------------------------------------------------------------------------

"""
View class for collecting data for used data types, both basetypes
and implementation data types.
"""

# Unused import check suppressed, because only used in type annotation,
# which is not found by PyLint
# pylint: disable=unused-import
from typing import List, Set
from generator.views.event_view import EventView
from generator.views.method_view import MethodView
from generator.views.field_view import FieldView
from generator.views.model_to_view import ViewManipulations
# pylint: enable=unused-import

from generator.views.service_view import ServiceView
from generator.intermediate_model.types.impl_type import ImplDataType
from generator.intermediate_model.types.base_type import BaseType


class DataTypeContainer(object):
    """
    Collects views to provide information for generating data type header files
    """
    def __init__(self, serviceView: ServiceView) -> None:
        self._service_view = serviceView
        self._events = serviceView.events   # type: List[EventView]
        self._methods = serviceView.methods # type: List[MethodView]
        self._fields = serviceView.all_fields   # type: List[FieldView]
        self._types_set = []
        self._get_types()

    @property
    def types(self):
        return self._types_set

    def _update_types_set(self, view):
        if (view.to_be_generated) and (not view in self._types_set):
            for v in view.referred_views:
                self._update_types_set(v)
            self._types_set.append(view)

    def _get_types(self):
        for eventview in self._events:
            self._update_types_set(eventview.type_view)
        for fieldview in self._fields:
            self._update_types_set(fieldview.type_view)
        for methodview in self._methods:
            for arg in methodview.get_args:
                self._update_types_set(arg.type_view)

