#  --------------------------------------------------------------------------
#  |              _    _ _______     .----.      _____         _____        |
#  |         /\  | |  | |__   __|  .  ____ .    / ____|  /\   |  __ \       |
#  |        /  \ | |  | |  | |    .  / __ \ .  | (___   /  \  | |__) |      |
#  |       / /\ \| |  | |  | |   .  / / / / v   \___ \ / /\ \ |  _  /       |
#  |      / /__\ \ |__| |  | |   . / /_/ /  .   ____) / /__\ \| | \ \       |
#  |     /________\____/   |_|   ^ \____/  .   |_____/________\_|  \_\      |
#  |                              . _ _  .                                  |
#  --------------------------------------------------------------------------
#
#  All Rights Reserved.
#  Any use of this source code is subject to a license agreement with the
#  AUTOSAR development cooperation.
#  More information is available at www.autosar.org.
#
#  Disclaimer
#
#  This work (specification and/or software implementation) and the material
#  contained in it, as released by AUTOSAR, is for the purpose of information
#  only. AUTOSAR and the companies that have contributed to it shall not be
#  liable for any use of the work.
#
#  The material contained in this work is protected by copyright and other
#  types of intellectual property rights. The commercial exploitation of the
#  material contained in this work requires a license to such intellectual
#  property rights.
#
#  This work may be utilized or reproduced without any modification, in any
#  form or by any means, for informational purposes only. For any other
#  purpose, no part of the work may be utilized or reproduced, in any form
#  or by any means, without permission in writing from the publisher.
#
#  The work has been developed for automotive applications only. It has
#  neither been developed, nor tested for non-automotive applications.
#
#  The word AUTOSAR and the AUTOSAR logo are registered trademarks.
#  --------------------------------------------------------------------------

# pylint: disable=too-many-lines,too-many-public-methods
import logging
from generator.parser.exception_handling import handle_method_exceptions
from generator.intermediate_model.types.base_type import BaseType
from generator.intermediate_model.communication_management.event import Event
from generator.intermediate_model.communication_management.method import Method
from generator.intermediate_model.communication_management.method import \
    Argument
from generator.intermediate_model.communication_management.method import \
    ErrorContext
# pylint: disable=line-too-long
from generator.intermediate_model.communication_management.error_domain import ApError, ApErrorDomain
from generator.intermediate_model.communication_management.application_error_exception import ApplicationErrorException  # noqa
from generator.intermediate_model.communication_management.field import Field
# pylint: enable=line-too-long
from generator.intermediate_model.types.impl_type import ImplDataType
from generator.intermediate_model.types.structure_impl_type \
    import StructureImplDataType
from generator.intermediate_model.types.enum_impl_type import EnumImplDataType
from generator.intermediate_model.types.allocator import Allocator
from generator.intermediate_model.types.linear_vector_impl_type \
    import LinearVectorImplDataType
from generator.intermediate_model.types.array_impl_type import ArrayImplDataType
from generator.intermediate_model.types.map_impl_type import MapImplDataType
from generator.intermediate_model.types.string_impl_type import StringImplDataType
from generator.views.error_domain_view import ErrorDomainView
from generator.parser.tree_helper import get_element, get_element_or_die, get_element_or_none, short_name
from generator.parser.autosar_mapping import AUTOSARMapping
from generator.intermediate_model.communication_management.transformation_props_to_service_element_mapping \
    import TransformationPropsToServiceInterfaceElementMapping
from generator.intermediate_model.communication_management.ap_someip_transformation_props \
    import ApSomeipTransformationProps
from generator.intermediate_model.communication_management.tld_data_id_definition import TlvDataIdDefinition

# Datatype tags
_A_DATA_PROT = "ARGUMENT-DATA-PROTOTYPE"
_IMPL_DATA_TYPE = "IMPLEMENTATION-DATA-TYPE"
_IMPL_DATA_TYPE_ELEMENT = "IMPLEMENTATION-DATA-TYPE-ELEMENT"
_IMPL_DATA_TYPE_EXTENSION = "IMPLEMENTATION-DATA-TYPE-EXTENSION"
_IMPL_DATA_TYPE_REF = "IMPLEMENTATION-DATA-TYPE-REF"
_SW_DATA_DEF_PROPS = "SW-DATA-DEF-PROPS"
_SW_DATA_DEF_PROPS_VARIANTS = "SW-DATA-DEF-PROPS-VARIANTS"
_SW_DATA_DEF_PROPS_CONDITIONAL = "SW-DATA-DEF-PROPS-CONDITIONAL"
_TYPE_TREF = "TYPE-TREF"
_V_DATA_PROT = "VARIABLE-DATA-PROTOTYPE"
_BASE_TYPE = "SW-BASE-TYPE"
_BASE_TYPE_REF = "BASE-TYPE-REF"
_COMPUMETHOD_REF = "COMPU-METHOD-REF"
_COMPU_SCALES = "COMPU-SCALES"
_COMPU_SCALE = "COMPU-SCALE"
_LOWER_LIMIT = "LOWER-LIMIT"
_UPPER_LIMIT = "UPPER-LIMIT"
_ARRAY_SIZE = "ARRAY-SIZE"

# Interface tags
_APPL_ERR = "APPLICATION-ERROR"
_ARGS = "ARGUMENTS"
_CS_OPER = "CLIENT-SERVER-OPERATION"
_ERR_CON_REF = "ERROR-CONTEXT-REF"
_ERR_CON_REFS = "ERROR-CONTEXT-REFS"
_EVENTS = "EVENTS"
_EVENT_REF = "EVENT-REF"
_FIELDS = "FIELDS"
_FIELD = "FIELD"
_GET = "GET"
_METHODS = "METHODS"
_NOTIFIER = "NOTIFIER"
_SET = "SET"

_SYMBOL_PROPS = "SYMBOL-PROPS"
_TRANSFORMATION_PROPS_REF = "TRANSFORMATION-PROPS-REF"
_PTD_MAPPINGS = "PORT-INTERFACE-TO-DATA-TYPE-MAPPING"
_TP_TO_SI_ELEMENT_MAPPING = "TRANSFORMATION-PROPS-TO-SERVICE-INTERFACE-ELEMENT-MAPPING"
_TLV_DATA_IDS = "TLV-DATA-IDS"
_TLV_DATA_ID_DEFINITION = "TLV-DATA-ID-DEFINITION"


def _is_true(text):
    """Check if text equals true, case insensitive"""
    return text is not None and str(text).strip().lower() == 'true'

class InterfaceBuilder():

    def __init__(self, model, package_path_fallback):
        self._log = logging.getLogger(__name__)
        self.model = model
        self._package_path_fallback = package_path_fallback
        self._error_domains = self.get_error_domains()
        self._error_domain_views = self._error_domains_to_views(self._error_domains)
        self._appl_to_cpp_mappings = {}
        self._tp_to_si_elements = self._parse_transformation_props()

    def _error_domains_to_views(self, error_domains):
        # just put to views, no meaningful processing
        # needed for uniformity with current architecture
        return [ErrorDomainView(ed) for ed in error_domains]

    @staticmethod
    def _parse_namespaces(namespaces):
        symbol_props = namespaces.find_elements_of_type(_SYMBOL_PROPS)
        namespace_list = []

        for symbol_prop in symbol_props:
            if symbol_prop.SYMBOL:
                namespace_list.append(symbol_prop.SYMBOL)
            else:
                namespace_list.append(symbol_prop.SHORT_NAME)
        return [x.lower() for x in namespace_list]

    def _parse_transformation_props(self) -> [TransformationPropsToServiceInterfaceElementMapping]:
        ar_tp_to_si_element_mappings = self.model.find_elements_of_type(_TP_TO_SI_ELEMENT_MAPPING)

        elements = [TransformationPropsToServiceInterfaceElementMapping(ar_tp_to_si_mapping.SHORT_NAME) for
                    ar_tp_to_si_mapping in ar_tp_to_si_element_mappings]

        for ar_mapping, element in zip(ar_tp_to_si_element_mappings, elements):
            element.data_ids = self._get_data_ids(ar_mapping)
            element.transformation_props = self._get_transformation_props(ar_mapping)
            element.event_references = ar_mapping.find_elements_of_type("EVENT-REF")
            element.method_references = ar_mapping.find_elements_of_type("METHOD-REF")
            element.field_references = ar_mapping.find_elements_of_type("FIELD-REF")

        return elements

    @staticmethod
    def _get_data_ids(ar_entity: AUTOSARMapping) -> [TlvDataIdDefinition]:
        if_id_definitions = getattr(ar_entity, _TLV_DATA_IDS, None)
        if if_id_definitions is None:
            return []

        ar_id_defs = ar_entity.find_elements_of_type(_TLV_DATA_ID_DEFINITION)
        tlv_id_defs = [TlvDataIdDefinition(ar_id_def.ID) for ar_id_def in ar_id_defs]
        for ar_def, tlv_def in zip(ar_id_defs, tlv_id_defs):
            tlv_def.impl_type = get_element_or_die(ar_def, "TLV-SUB-ELEMENT-REF")

        return tlv_id_defs

    def _get_transformation_props(self, ar_entity: AUTOSARMapping) -> [ApSomeipTransformationProps]:
        transformation_props_ref = getattr(ar_entity, _TRANSFORMATION_PROPS_REF, None)
        if transformation_props_ref is None:
            return None

        ar_transformation_props = self.model.find_referable(transformation_props_ref)

        return ApSomeipTransformationProps(get_element_or_die(ar_transformation_props, "SHORT-NAME"),
                                           get_element_or_die(ar_transformation_props, "SIZE-OF-STRUCT-LENGTH-FIELD"))

    @staticmethod
    def _get_literal_values(compumethod):
        """
        Takes a Compumethod of catogory TEXTTABLE generates a list over the
        literals and values for an enum
        """

        literals = list()
        compu_scales = compumethod.find_elements_of_type(_COMPU_SCALE)
        for compuscale in compu_scales:
            # literal symbols could be named either by SYMBOL, COMPU-CONST/VT
            # or SHORT-LABEL. Order is as per SWS_CM_00425

            # @uptrace{SWS_CM_00425}
            literal_name = get_element_or_none(compuscale, "SYMBOL")

            if literal_name is None:
                literal_name = get_element_or_none(compuscale, "COMPU-CONST/VT")

            if literal_name is None:
                literal_name = get_element_or_none(compuscale, "SHORT-LABEL")

            if literal_name is None:
                # @uptrace{SWS_CM_00426}
                assert False, "Unable to fetch enum value name for {}".format(compuscale.get_fqn())

            # Only set literalvalue if lowerlimit and upperlimit are equal and both have "closed" interval type.
            # Set to "absent" (i.e. None) if both lowerlimit and upperlimit are absent.
            # Otherwise remove the literal from the table because it fails into category "non-point" and shall be simply skipped.
            literal_value = None
            lower_limit = get_element_or_none(compuscale, _LOWER_LIMIT)
            upper_limit = get_element_or_none(compuscale, _UPPER_LIMIT)
            # @uptrace{SWS_CM_10376}
            if (lower_limit is None) and (upper_limit is None):
                # normal case, use the name and do not use the value.
                pass
            elif (lower_limit is not None) and (upper_limit is not None):
                if (lower_limit.get('INTERVAL-TYPE').upper() != "CLOSED"):
                    #non-point literal, flush it from table
                    literal_name = ""
                elif (upper_limit.get('INTERVAL-TYPE').upper() != "CLOSED"):
                    #non-point literal, flush it from table
                    literal_name = ""
                elif lower_limit != upper_limit:
                    #non-point literal, flush it from table
                    literal_name = ""
                else:
                    #everything is fine, pick up the value
                    literal_value = lower_limit
            else:
                #non-point literal, flush it from table
                literal_name = ""

            if literal_name != "":
                literals.append((literal_name, literal_value))

        return literals

    def _get_cpp_type_namespaces(self, cpp_type):
        result = []
        if hasattr(cpp_type, 'NAMESPACES'):
            namespaces = cpp_type.NAMESPACES
            if namespaces is not None:
                result = InterfaceBuilder._parse_namespaces(namespaces)
        return result


    def _get_impl_type_namespaces(self, impl_type):
        """Get the namespace of an impl type as a list"""
        log = logging.getLogger(__name__)
        impl_type_ext = self.model.find_elements_of_type(
            _IMPL_DATA_TYPE_EXTENSION,
            accept=lambda e: str(
                e.IMPLEMENTATION_DATA_TYPE_REF) == impl_type.get_fqn())

        if impl_type_ext is not None and len(impl_type_ext) == 1:
            if hasattr(impl_type_ext[0], 'NAMESPACES'):
                namespaces = impl_type_ext[0].NAMESPACES
                return InterfaceBuilder._parse_namespaces(namespaces)
        else:
            if len(impl_type_ext) > 1:
                log.warning("More than 1 extension found for %s!",
                            impl_type.get_fqn())
                return []

        if self._package_path_fallback:
            log.warning("No namespaces were found in the following Implementation Type %s! Fallback to "
                        "Packages hierarchy", impl_type.SHORT_NAME)
            return impl_type.get_parent_package_hierarchy_as_list()
        else:
            log.warning("No namespaces were found in the following Implementation Type %s!",
                        impl_type.SHORT_NAME)
            return []

    def _get_service_namespaces(self, ar_interface):
        """Extract the service namespaces from a service-interface ar-object"""
        log = logging.getLogger(__name__)

        if hasattr(ar_interface, 'NAMESPACES'):
            namespaces = ar_interface.NAMESPACES
            if namespaces is not None:
                return InterfaceBuilder._parse_namespaces(namespaces)
        else:
            if self._package_path_fallback:
                log.warning("No namespaces were found in the following interface %s! Fallback to Packages hierarchy",
                            ar_interface.SHORT_NAME)
                return ar_interface.get_parent_package_hierarchy_as_list()
            else:
                log.warning("No namespaces were found in the following interface %s!",
                            ar_interface.SHORT_NAME)
                return []


    def _get_structure_impl_type(self, ar_type, namespace):
        """
        Creates and populates a StructureImplDataType object including
        subelements
        """
        subelements = list()
        subelems = ar_type.find_elements_of_type(_IMPL_DATA_TYPE_ELEMENT)
        for elem in subelems:
            subelemtyperef = elem.find_elements_of_type(_IMPL_DATA_TYPE_REF)
            if subelemtyperef:
                self._log.debug(
                    "SUBELEMENT='%s' '%s'", str(elem.SHORT_NAME),
                    subelemtyperef[0])
            elem_type_refs = elem.find_elements_of_type(
                _IMPL_DATA_TYPE_REF, DEST=_IMPL_DATA_TYPE)
            if elem_type_refs:
                basetyperef = self.get_impl_type(elem_type_refs[0])

            subelement_tuple = ((str(elem.SHORT_NAME)), basetyperef, False, None)
            subelements.append(subelement_tuple)
        return StructureImplDataType(ar_type.SHORT_NAME,
                                     None,
                                     subelements,
                                     namespace)

    def _get_structure_cpp_type(self, ar_type, namespace):
        subelements = list()
        subelems = get_element_or_die(ar_type, "SUB-ELEMENTS/CPP-IMPLEMENTATION-DATA-TYPE-ELEMENT")
        data_id_counter = 0
        for elem in subelems:
            subelemtyperef = get_element_or_die(elem, "TYPE-REFERENCE/TYPE-REFERENCE-REF")
            ar_element_type = self.model.find_referable(subelemtyperef.text)
            element_type = self.get_cpp_type(ar_element_type)
            is_optional = hasattr(elem, 'IS-OPTIONAL') and _is_true(elem.IS_OPTIONAL)
            data_id = self._get_tlv_data_id(elem)
            if data_id is not None:
                data_id_counter += 1
            subelement_tuple = ((str(elem.SHORT_NAME)), element_type, is_optional, data_id)
            subelements.append(subelement_tuple)

        # Check TLV data ids. All sub elements shall be tlv encoded if there is at least one member with data id.
        if len(subelems) != data_id_counter and data_id_counter != 0:
            raise AssertionError(
                "All sub elements shell be referenced by a tlv data id. Location: " + ar_type.get_fqn())

        structure_cpp_type = StructureImplDataType(ar_type.SHORT_NAME,
                                                   self._get_cpp_type_emitter(ar_type),
                                                   subelements,
                                                   namespace)

        structure_cpp_type.size_of_struct_length_field = self._get_size_of_struct_length_field(ar_type)

        # Check length field size availability. The size of struct length field size is mandatory in case of TLV.
        if data_id_counter > 0 and structure_cpp_type.size_of_struct_length_field == 0:
            raise AssertionError("Size of struct length field size shall be configured for: " + ar_type.get_fqn())

        # Check data id availability if there is any optional member.
        if structure_cpp_type.has_optional and data_id_counter == 0:
            raise AssertionError(
                "All sub elements shell be referenced by a tlv data id. Location: " + ar_type.get_fqn())

        return structure_cpp_type

    def _get_size_of_struct_length_field(self, ar_struct_type):
        # Find the appropriate transformation props for this structure
        # and return with the size_of_struct_length field
        for element_mapping in self._tp_to_si_elements:
            event_method_field_refs = element_mapping.event_references + element_mapping.method_references + \
                                        element_mapping.field_references
            for ar_object_with_type_ref in event_method_field_refs:
                ar_event_method_or_field = self.model.find_referable(ar_object_with_type_ref.text)
                typeref = get_element_or_die(ar_event_method_or_field, "TYPE-TREF")
                if ar_struct_type.get_fqn() == typeref.text:
                    return element_mapping.transformation_props.size_of_struct_length_field
        # In case of no transformation props: return with 0 which means no length field is needed.
        return 0

    def _get_tlv_data_id(self, ar_cpp_impl_data_type):
        for element_mapping in self._tp_to_si_elements:
            for data_id in element_mapping.data_ids:
                if data_id.impl_type == ar_cpp_impl_data_type.get_fqn():
                    return data_id.id
        return None

    def _get_typeref_impl_type(self, ar_type, namespace):
        """Creates and populates a ImplDataType object for an aliased type,
        or an EnumImplDataType objects for enum"""

        compumethod_ref = ar_type.find_elements_of_type(_COMPUMETHOD_REF)
        if compumethod_ref:
            # There should be only one Compumethod.
            compumethod = self.model.find_referable(str(compumethod_ref[0]))
            if compumethod is not None:
                self._log.debug(
                    "compumethod NAME='%s' CATEGORY='%s'",
                    compumethod.SHORT_NAME, compumethod.CATEGORY)
                literal_table = InterfaceBuilder._get_literal_values(compumethod)

            enum_impltype_ref = ar_type.find_elements_of_type(
                _IMPL_DATA_TYPE_REF)
            if enum_impltype_ref:
                # There should be only one implementation type
                basetyperef = self.get_impl_type(enum_impltype_ref[0])
                self._log.debug("enum IMPL TYPE NAME='%s'", basetyperef.name)

            return EnumImplDataType(ar_type.SHORT_NAME,
                                    None,
                                    basetyperef,
                                    literal_table,
                                    namespace)
        else:
            # No enum. Create a normal typedef translation
            typeref_impltype_ref = ar_type.find_elements_of_type(
                _IMPL_DATA_TYPE_REF)
            if typeref_impltype_ref:
                # There should be only one implementation type
                typeref_impl_type = self.get_impl_type(typeref_impltype_ref[0])
                self._log.debug(
                    "typeref IMPL TYPE NAME='%s' typeref BASE_TYPE='%s'",
                    ar_type.SHORT_NAME, typeref_impl_type.name)

            return ImplDataType(ar_type.SHORT_NAME,
                                None,
                                [typeref_impl_type],
                                namespace)

    @handle_method_exceptions(error_string_template="{exception_text}")
    def _get_typeref_cpp_type(self, ar_type, namespace):
        compumethod_ref = get_element_or_none(ar_type,
                                              "SW-DATA-DEF-PROPS"
                                              "/SW-DATA-DEF-PROPS-VARIANTS"
                                              "/SW-DATA-DEF-PROPS-CONDITIONAL"
                                              "/COMPU-METHOD-REF")
        if compumethod_ref:
            # this is an enum
            assert len(compumethod_ref) == 1, \
                "Only one table of values expected for {}".format(ar_type)
            assert compumethod_ref.get('DEST') == 'COMPU-METHOD', \
                "COMPU-METHOD-REF must point to COMPU-METHOD ({})".format(ar_type)
            compumethod = self.model.find_referable(compumethod_ref.text)
            assert compumethod is not None, \
                "unable to resolve COMPU-METHOD-REF for {}".format(ar_type)

            self._log.debug(
                "compumethod NAME='%s' CATEGORY='%s'",
                compumethod.SHORT_NAME, compumethod.CATEGORY)
            literal_table = InterfaceBuilder._get_literal_values(compumethod)

            enum_type_ref = get_element_or_die(ar_type, "TYPE-REFERENCE-REF")
            assert enum_type_ref.get('DEST') == 'STD-CPP-IMPLEMENTATION-DATA-TYPE', \
                "TYPE-REFERENCE-REF must point to STD-CPP-IMPLEMENTATION-DATA-TYPE ({])".format(ar_type)

            basetyperef = self.get_cpp_type(enum_type_ref)
            self._log.debug("enum CPP TYPE NAME='%s'", basetyperef.name)

            return EnumImplDataType(ar_type.SHORT_NAME,
                                    self._get_cpp_type_emitter(ar_type),
                                    basetyperef,
                                    literal_table,
                                    namespace)
        else:
            # just typedef
            typeref_cpptype_ref = get_element_or_die(ar_type, "TYPE-REFERENCE-REF")
            assert typeref_cpptype_ref.get('DEST') == 'STD-CPP-IMPLEMENTATION-DATA-TYPE', \
                "TYPE-REFERENCE-REF must point to STD-CPP-IMPLEMENTATION-DATA-TYPE ({})".format(ar_type)

            typeref_cpp_type = self.get_cpp_type(typeref_cpptype_ref[0])
            self._log.debug(
                "typeref cpp TYPE NAME='%s' typeref BASE_TYPE='%s'", ar_type.SHORT_NAME, typeref_cpp_type.name)

            return ImplDataType(ar_type.SHORT_NAME,
                                self._get_cpp_type_emitter(ar_type),
                                [typeref_cpp_type],
                                namespace)

    def _get_vector_impl_type(self, ar_type, namespace):
        """
        Creates and populates a LinearVectorImplDataType object for a
        Vector type.
        """
        allocator = Allocator.MAX_HEAP_SIZE
        subelems = ar_type.find_elements_of_type(_IMPL_DATA_TYPE_ELEMENT)
        if subelems:
            subelemtyperef = subelems[0].find_elements_of_type(
                _IMPL_DATA_TYPE_REF)
            if subelemtyperef:
                subelemtypename = subelemtyperef[0]

            self._log.debug("VECTOR ELEMENT TYPE='%s'", subelemtyperef[0])

            elem_type_refs = subelems[0].find_elements_of_type(
                _IMPL_DATA_TYPE_REF, DEST=_IMPL_DATA_TYPE)
            if elem_type_refs:
                basetyperef = self.get_impl_type(elem_type_refs[0])

        return LinearVectorImplDataType(ar_type.SHORT_NAME,
                                        None,
                                        basetyperef,
                                        allocator,
                                        namespace)

    def _get_vector_cpp_type(self, ar_type, namespace):
        template_args = get_element_or_die(ar_type, "TEMPLATE-ARGUMENTS/CPP-TEMPLATE-ARGUMENT")
        assert len(template_args) in [1, 2], "One or two template argument(s) expected for {0}".format(ar_type)
        element_type_ref = get_element_or_die(template_args[0], "TEMPLATE-TYPE-REF")
        ar_element_type = self.model.find_referable(element_type_ref.text)
        element_type = self.get_cpp_type(ar_element_type)
        allocator = None
        assert len(template_args) == 1, "allocator found, handle this for {0}".format(ar_type)
        return LinearVectorImplDataType(ar_type.SHORT_NAME,
                                        self._get_cpp_type_emitter(ar_type),
                                        element_type,
                                        allocator,
                                        namespace)

    def _get_array_impl_type(self, ar_type, namespace):
        """
        Creates and pupulates a ArrayImplDataType object.
        """
        subelems = ar_type.find_elements_of_type(_IMPL_DATA_TYPE_ELEMENT)
        if subelems:
            subelemtyperef = subelems[0].find_elements_of_type(
                _IMPL_DATA_TYPE_REF)
            if subelemtyperef:
                subelemtypename = subelemtyperef[0]

            self._log.debug("ARRAY ELEMENT TYPE='%s'", subelemtyperef[0])

            elem_type_refs = subelems[0].find_elements_of_type(
                _IMPL_DATA_TYPE_REF, DEST=_IMPL_DATA_TYPE)
            if elem_type_refs:
                basetyperef = self.get_impl_type(elem_type_refs[0])

            array_size = subelems[0].find_elements_of_type(_ARRAY_SIZE)
            assert array_size, \
                'Array size required. ' + ar_type.get_fqn()
            arraysize = array_size[0]
        return ArrayImplDataType(ar_type.SHORT_NAME,
                                 None,
                                 basetyperef,
                                 arraysize,
                                 namespace)

    def _get_array_cpp_type(self, ar_type, namespace):
        array_size = get_element_or_die(ar_type, "ARRAY-SIZE")
        template_args = get_element_or_die(ar_type, "TEMPLATE-ARGUMENTS/CPP-TEMPLATE-ARGUMENT")
        assert len(template_args) in [1, 2], "One or two template argument(s) expected for {0}".format(ar_type)
        element_type_ref = get_element_or_die(template_args[0], "TEMPLATE-TYPE-REF")
        ar_element_type = self.model.find_referable(element_type_ref.text)
        element_type = self.get_cpp_type(ar_element_type)
        assert len(template_args) == 1, "allocator found, handle this for {0}".format(ar_type)
        return ArrayImplDataType(ar_type.SHORT_NAME,
                                 self._get_cpp_type_emitter(ar_type),
                                 element_type,
                                 array_size,
                                 namespace)

    def _get_map_impl_type(self, ar_type, namespace):
        """
        Creates and populates an MapImplDataType object.
        """
        subelems = ar_type.find_elements_of_type(_IMPL_DATA_TYPE_ELEMENT)
        assert len(subelems) == 2, \
            'Wrong number of sub-elements for type: ' + ar_type.get_fqn()
        key_type = None
        for elem in subelems:
            subelemtyperef = elem.find_elements_of_type(_IMPL_DATA_TYPE_REF)
            if subelemtyperef:
                self._log.debug(
                    "SUBELEMENT='%s' '%s'",
                    str(elem.SHORT_NAME), subelemtyperef[0])
            elem_type_refs = elem.find_elements_of_type(
                _IMPL_DATA_TYPE_REF, DEST=_IMPL_DATA_TYPE)
            if elem_type_refs:
                basetyperef = self.get_impl_type(elem_type_refs[0])

            if key_type is None:
                key_type = basetyperef
            else:
                value_type = basetyperef
        return MapImplDataType(ar_type.SHORT_NAME,
                               None,
                               key_type,
                               value_type,
                               namespace)

    def _get_map_cpp_type(self, ar_type, namespace):
        template_args = get_element_or_die(ar_type, "TEMPLATE-ARGUMENTS/CPP-TEMPLATE-ARGUMENT")
        assert len(template_args) in [2, 3], "2 or 3 template arguments expected for {0}".format(ar_type)
        key_type_ref   = get_element_or_die(template_args[0], "TEMPLATE-TYPE-REF")
        value_type_ref = get_element_or_die(template_args[1], "TEMPLATE-TYPE-REF")
        ar_key_type   = self.model.find_referable(key_type_ref.text)
        ar_value_type = self.model.find_referable(value_type_ref.text)
        key_type = self.get_cpp_type(ar_key_type)
        value_type = self.get_cpp_type(ar_value_type)
        assert len(template_args) == 2, "allocator found, handle this for {0}".format(ar_type)
        return MapImplDataType(ar_type.SHORT_NAME,
                               self._get_cpp_type_emitter(ar_type),
                               key_type,
                               value_type,
                               namespace)

    def get_impl_type(self, ar_type_ref):
        """Get the impl type from the type reference"""
        ar_type = self.model.find_referable(str(ar_type_ref))
        namespace = self._get_impl_type_namespaces(ar_type)
        self._log.debug(
            "CATEGORY='%s' '%s'", str(ar_type.CATEGORY),
            str(ar_type.SHORT_NAME))
        if ar_type.CATEGORY == 'STRUCTURE':
            return self._get_structure_impl_type(ar_type, namespace)
        elif ar_type.CATEGORY == 'TYPE_REFERENCE':
            return self._get_typeref_impl_type(ar_type, namespace)
        elif ar_type.CATEGORY == 'VECTOR':
            return self._get_vector_impl_type(ar_type, namespace)
        elif ar_type.CATEGORY == 'ARRAY':
            return self._get_array_impl_type(ar_type, namespace)
        elif ar_type.CATEGORY == 'ASSOCIATIVE_MAP':
            return self._get_map_impl_type(ar_type, namespace)
        elif ar_type.CATEGORY == 'STRING':
            impl_type = StringImplDataType(ar_type.SHORT_NAME,
                                           None,
                                           1,
                                           namespace)
        elif ar_type.CATEGORY == 'VALUE':
            base_type_ref = get_element_or_die(ar_type,
                                               "SW-DATA-DEF-PROPS"
                                               "/SW-DATA-DEF-PROPS-VARIANTS"
                                               "/SW-DATA-DEF-PROPS-CONDITIONAL"
                                               "/BASE-TYPE-REF")
            base_type_name = short_name(base_type_ref)
            impl_type = ImplDataType(ar_type.SHORT_NAME,
                                     None,
                                     [BaseType(base_type_name, None)],
                                     namespace)
        else:
            assert False, "Unknown type category"

        return impl_type

    def _get_cpp_type_emitter(self, ar_type):
        type_emitter = ""
        if hasattr(ar_type, "TYPE_EMITTER"):
            type_emitter = str(ar_type.TYPE_EMITTER).strip()
        return type_emitter


    def get_cpp_type(self, ar_type_ref):
        ar_type = self.model.find_referable(str(ar_type_ref))
        namespaces = self._get_cpp_type_namespaces(ar_type)

        if ar_type.CATEGORY == 'STRUCTURE':
            return self._get_structure_cpp_type(ar_type, namespaces)
        elif ar_type.CATEGORY == 'TYPE_REFERENCE':
            return self._get_typeref_cpp_type(ar_type, namespaces)
        elif ar_type.CATEGORY == 'VECTOR':
            return self._get_vector_cpp_type(ar_type, namespaces)
        elif ar_type.CATEGORY == 'ARRAY':
            return self._get_array_cpp_type(ar_type, namespaces)
        elif ar_type.CATEGORY == 'ASSOCIATIVE_MAP':
            return self._get_map_cpp_type(ar_type, namespaces)
        elif ar_type.CATEGORY == 'STRING':
            impl_type = StringImplDataType(ar_type.SHORT_NAME,
                                           self._get_cpp_type_emitter(ar_type),
                                           1,
                                           namespaces)
        elif ar_type.CATEGORY == 'VALUE':
            impl_type = BaseType(ar_type.SHORT_NAME,
                                 self._get_cpp_type_emitter(ar_type))
        else:
            assert False, "Unknown type category"

        return impl_type

    def validate_appl_to_cpp_type(self, ar_appl_data_type, ar_cpp_type_ref, mappings):
        """Ensure that an application data type aligns with all related cpp implementation data types."""
        ar_appl_data_type_kind = ar_appl_data_type.short_tag()
        ar_cpp_type = self.model.find_referable(str(ar_cpp_type_ref))
        cpp_category = get_element_or_die(ar_cpp_type, "CATEGORY")
        while cpp_category == "TYPE_REFERENCE":
            typeref_cpptype_ref = get_element_or_die(ar_cpp_type, "TYPE-REFERENCE-REF")
            if typeref_cpptype_ref.get('DEST') != 'STD-CPP-IMPLEMENTATION-DATA-TYPE':
                return False
            ar_cpp_type = self.model.find_referable(str(typeref_cpptype_ref))
            cpp_category = get_element_or_die(ar_cpp_type, "CATEGORY")

        if ar_appl_data_type_kind == 'APPLICATION-PRIMITIVE-DATA-TYPE':
            if cpp_category not in ["STRING", "VALUE"]:
                return False
            return True
        elif ar_appl_data_type_kind == 'APPLICATION-ARRAY-DATA-TYPE':
            appl_array_element = get_element_or_die(ar_appl_data_type, "ELEMENT")

            appl_dynamic_array_size_profile = ar_appl_data_type.find_elements_of_type("DYNAMIC-ARRAY-SIZE-PROFILE")
            if len(appl_dynamic_array_size_profile) > 0 and appl_dynamic_array_size_profile[0] == "VSA_LINEAR":
                if cpp_category != "VECTOR":
                    return False
            else:
                if cpp_category != "ARRAY":
                    return False
                appl_array_element_max_num_elements = get_element_or_die(appl_array_element, "MAX-NUMBER-OF-ELEMENTS")
                cpp_template_argument = get_element_or_die(ar_cpp_type, "ARRAY-SIZE")
                if appl_array_element_max_num_elements != cpp_template_argument:
                    return False

            appl_array_element_type_ref = get_element_or_die(appl_array_element, "TYPE-TREF")
            appl_array_element_type = self.model.find_referable(str(appl_array_element_type_ref))

            cpp_template_argument = get_element_or_die(ar_cpp_type,
                                                       "TEMPLATE-ARGUMENTS/CPP-TEMPLATE-ARGUMENT")[0]
            cpp_array_element_type = get_element_or_die(cpp_template_argument, "TEMPLATE-TYPE-REF")

            return self.validate_appl_to_cpp_type(appl_array_element_type, cpp_array_element_type, mappings)
        elif ar_appl_data_type_kind == 'APPLICATION-RECORD-DATA-TYPE':
            appl_record_elements = get_element_or_die(ar_appl_data_type,
                                                      "ELEMENTS/APPLICATION-RECORD-ELEMENT")

            cpp_impl_data_type_elements = get_element_or_die(ar_cpp_type,
                                                             "SUB-ELEMENTS/CPP-IMPLEMENTATION-DATA-TYPE-ELEMENT")

            if len(appl_record_elements) != len(cpp_impl_data_type_elements):
                return False

            for appl_record_element, cpp_impl_data_type_element in \
                    zip(appl_record_elements, cpp_impl_data_type_elements):
                appl_record_type_refs = appl_record_element.find_elements_of_type(_TYPE_TREF)
                if len(appl_record_type_refs) != 1:
                    return False
                appl_record_type_ref = appl_record_type_refs[0]
                appl_record_type = self.model.find_referable(str(appl_record_type_ref))

                cpp_element_ref = get_element_or_die(cpp_impl_data_type_element,
                                                     "TYPE-REFERENCE/TYPE-REFERENCE-REF")

                if self.validate_appl_to_cpp_type(appl_record_type, cpp_element_ref, mappings) == False:
                    return False
            return True

    def get_data_type_maps(self, ar_interface):
        """Collect and cache all data mappings related to a specific interface."""
        if ar_interface.get_fqn() not in self._appl_to_cpp_mappings:
            mappings = {}
            port_interface_to_data_type_mappings = self.model.find_elements_of_type(_PTD_MAPPINGS,
                                                                                    PORT_INTERFACE_REF=ar_interface.get_fqn())
            for port_interface_to_data_type_mapping in port_interface_to_data_type_mappings:
                data_type_mapping_set_refs = port_interface_to_data_type_mapping.find_elements_of_type(
                    'DATA-TYPE-MAPPING-SET-REF', DEST='DATA-TYPE-MAPPING-SET')
                for data_type_mapping_set_ref in data_type_mapping_set_refs:
                    data_type_mapping_set = self.model.find_referable(str(data_type_mapping_set_ref))
                    data_type_maps = data_type_mapping_set.find_elements_of_type('DATA-TYPE-MAP')
                    for data_type_map in data_type_maps:
                        ar_application_data_type_refs = \
                            data_type_map.find_elements_of_type('APPLICATION-DATA-TYPE-REF')
                        assert len(ar_application_data_type_refs) == 1, \
                            "Exactly one {0} expected for {1}, found {2}".format(
                                'APPLICATION-DATA-TYPE-REF',
                                data_type_map.get_fqn(),
                                len(ar_application_data_type_refs))
                        ar_application_data_type = \
                            self.model.find_referable(str(ar_application_data_type_refs[0]))

                        ar_implementation_data_type_refs = \
                            data_type_map.find_elements_of_type('IMPLEMENTATION-DATA-TYPE-REF')
                        assert len(ar_implementation_data_type_refs) == 1, \
                            "Exactly one {0} expected for {1}, found {2}".format(
                                'IMPLEMENTATION-DATA-TYPE-REF',
                                data_type_map.get_fqn(),
                                len(ar_implementation_data_type_refs))
                        impl_type_kind = ar_implementation_data_type_refs[0].get('DEST')

                        if ar_application_data_type is not None and \
                                impl_type_kind == 'STD-CPP-IMPLEMENTATION-DATA-TYPE':
                            if ar_application_data_type not in mappings:
                                mappings[ar_application_data_type] = ar_implementation_data_type_refs[0]
                            else:
                                self._log.warning("Found multiple {0} for {1}. The first is taken.".format(
                                    "STD-CPP-IMPLEMENTATION-DATA-TYPE", ar_application_data_type))
            self._appl_to_cpp_mappings[ar_interface.get_fqn()] = mappings

        return self._appl_to_cpp_mappings[ar_interface.get_fqn()]

    def get_cpp_from_appl_type(self, ar_type_ref, ar_interface):
        ar_type = self.model.find_referable(str(ar_type_ref))
        data_type_maps = self.get_data_type_maps(ar_interface)

        if ar_type not in data_type_maps:
            return None

        if not self.validate_appl_to_cpp_type(ar_type, data_type_maps[ar_type], data_type_maps):
            return None

        return self.get_data_type_maps(ar_interface)[ar_type]

    def get_type(self, ar_entity, ar_interface):
        ar_type_refs = ar_entity.find_elements_of_type(_TYPE_TREF)
        assert len(ar_type_refs) == 1, "Exactly one {0} expected for {1}, found {2}".format(
            _TYPE_TREF, ar_entity.get_fqn(), len(ar_type_refs))

        type_kind = ar_type_refs[0].get('DEST')

        if type_kind.startswith('APPLICATION'):
            appl_type_ref = ar_type_refs[0]
            ar_type_refs[0] = self.get_cpp_from_appl_type(appl_type_ref, ar_interface)
            assert ar_type_refs[0] is not None, \
                "Could not resolve {0} {1}. The mapping to {2} is broken.".format(
                type_kind, appl_type_ref, "STD-CPP-IMPLEMENTATION-DATA-TYPE")
            type_kind = ar_type_refs[0].get('DEST')

        if type_kind == 'STD-CPP-IMPLEMENTATION-DATA-TYPE':
            result = self.get_cpp_type(ar_type_refs[0])
        elif type_kind == _IMPL_DATA_TYPE:
            result = self.get_impl_type(ar_type_refs[0])
        else:
            assert False, "Wrong reference"

        #        print(objectify.dump(ar_type_refs[0]))
        #        print("-----%s" % ar_type_refs[0].get('DEST'))

        return result

    @staticmethod
    def _arg_is_an_exception(arg_fqn, service):
        for err in service.errors:
            for ctx in err.error_contexts:
                if (ctx.referable_fqn == arg_fqn):
                    return True
        return False

    def get_method_arguments(self, ar_method, method, service, ar_interface):
        """Get the method arguments"""
        arguments = getattr(ar_method, _ARGS, None)
        if arguments is None:
            return
        ar_args = ar_method.find_elements_of_type(_A_DATA_PROT)
        output = []
        for ar_arg in ar_args:
            arg_impl_type = self.get_type(ar_arg, ar_interface)
            arg_direction = ar_arg.DIRECTION.lower()
            arg_is_exception = InterfaceBuilder._arg_is_an_exception(str(ar_arg), service)
            argument = Argument(ar_arg.SHORT_NAME, arg_impl_type, arg_is_exception)
            method.add_argument(argument, arg_direction)

    def find_error(self, error_fqn):
        for error_domain in self._error_domains:
            for error in error_domain.errors:
                if error.fqn == error_fqn:
                    return error
        return None

    def get_method_errors(self, ar_method, method):
        ar_error_refs = get_element_or_none(ar_method, "POSSIBLE-AP-ERROR-REFS/POSSIBLE-AP-ERROR-REF")
        if ar_error_refs is not None:
            for ar_error_ref in ar_error_refs:
                ar_error = self.model.find_referable(ar_error_ref.text)
                error = self.find_error(ar_error.get_fqn())
                method.add_error(error)

    def _get_error_contexts(self, ar_appl_err):
        """Get the error contexts of an application error"""
        ar_err_cont_refs_cont = getattr(ar_appl_err, _ERR_CON_REFS, None)
        if ar_err_cont_refs_cont is None:
            return []
        ar_err_cont_refs = ar_err_cont_refs_cont.find_elements_of_type(
            _ERR_CON_REF, DEST=_A_DATA_PROT)

        error_contexts = []
        for ar_error_ref in ar_err_cont_refs:
            ar_error_cont = self.model.find_referable(str(ar_error_ref))
            ar_type_refs = ar_error_cont.find_elements_of_type(
                _TYPE_TREF, DEST="STD-CPP-IMPLEMENTATION-DATA-TYPE")
            if len(ar_type_refs) == 1:
                impl_type = self.get_cpp_type(ar_type_refs[0])
            else:
                ar_type_refs = ar_error_cont.find_elements_of_type(
                    _TYPE_TREF, DEST="IMPLEMENTATION-DATA-TYPE")
                impl_type = self.get_impl_type(ar_type_refs[0])

            error_contexts.append(ErrorContext(impl_type, str(ar_error_ref)))
        return error_contexts


    def get_events(self, ar_interface):
        """Get the events contained in an interface"""
        if_events = getattr(ar_interface, _EVENTS, None)
        if if_events is None:
            return []
        ar_events = if_events.find_elements_of_type(_V_DATA_PROT)
        events = [Event(ar_event.SHORT_NAME) for ar_event in ar_events]
        for ar_event, event in zip(ar_events, events):
            event.impl_type = self.get_type(ar_event, ar_interface)
        return events


    def get_fields(self, ar_interface):
        """Get the fields of a service interface"""
        if_fields = getattr(ar_interface, _FIELDS, None)
        if if_fields is None:
            return []
        ar_fields = if_fields.find_elements_of_type(_FIELD)
        fields = [Field(ar_field.SHORT_NAME) for ar_field in ar_fields]
        for ar_field, field in zip(ar_fields, fields):
            field.impl_type = self.get_type(ar_field, ar_interface)
            field.has_notifier = _is_true(ar_field.HAS_NOTIFIER)
            field.has_getter = _is_true(ar_field.HAS_GETTER)
            field.has_setter = _is_true(ar_field.HAS_SETTER)
        return fields

    def get_methods(self, ar_interface, service):
        """Get the methods of a service interface"""
        if_methods = getattr(ar_interface, _METHODS, None)
        if if_methods is None:
            return []
        ar_methods = if_methods.find_elements_of_type(_CS_OPER)
        methods = [Method(ar_method.SHORT_NAME) for ar_method in ar_methods]
        for ar_method, method in zip(ar_methods, methods):
            self.get_method_arguments(ar_method, method, service, ar_interface)
            self.get_method_errors(ar_method, method)
        return methods

    def get_errors(self, ar_interface):
        """Get the errors of a service interface"""
        ar_appl_errors = ar_interface.find_elements_of_type(_APPL_ERR)
        appl_errors = []
        for ar_appl_err in ar_appl_errors:
            error_contexts = self._get_error_contexts(ar_appl_err)
            appl_errors.append(ApplicationErrorException(
                str(ar_appl_err.SHORT_NAME),
                ar_appl_err.ERROR_CODE, error_contexts))
        return appl_errors

    def get_error_domains(self):
        domains = {}
        ar_error_domains = self.model.find_elements_of_type("AP-APPLICATION-ERROR-DOMAIN")
        for ar_error_domain in ar_error_domains:
            namespaces = self._get_cpp_type_namespaces(ar_error_domain)
            value = ar_error_domain.VALUE
            fqn = ar_error_domain.get_fqn()
            error_domain = ApErrorDomain(fqn, namespaces, value)
            domains[fqn] = error_domain

        ar_errors = self.model.find_elements_of_type("AP-APPLICATION-ERROR")
        for ar_error in ar_errors:
            domain_ref = ar_error.ERROR_DOMAIN_REF
            fqn = ar_error.get_fqn()
            error_code = ar_error.ERROR_CODE
            desc = get_element_or_none(ar_error, "DESC/L-2")
            error = ApError(fqn, desc, error_code)
            corresponding_domain = domains[domain_ref]
            corresponding_domain.add_error(error)

        return list(domains.values())

    def get_error_domain_views(self):
        return self._error_domain_views

    def populate_interface(self, ar_interface, service):
        service.namespaces = self._get_service_namespaces(ar_interface)
        for error in self.get_errors(ar_interface):
            service.add_error(error)
        for event in self.get_events(ar_interface):
            service.add_event(event)
        for field in self.get_fields(ar_interface):
            service.add_field(field)
        for method in self.get_methods(ar_interface, service):
            service.add_method(method)
