// --------------------------------------------------------------------------
// |              _    _ _______     .----.      _____         _____        |
// |         /\  | |  | |__   __|  .  ____ .    / ____|  /\   |  __ \       |
// |        /  \ | |  | |  | |    .  / __ \ .  | (___   /  \  | |__) |      |
// |       / /\ \| |  | |  | |   .  / / / / v   \___ \ / /\ \ |  _  /       |
// |      / /__\ \ |__| |  | |   . / /_/ /  .   ____) / /__\ \| | \ \       |
// |     /________\____/   |_|   ^ \____/  .   |_____/________\_|  \_\      |
// |                              . _ _  .                                  |
// --------------------------------------------------------------------------
//
// All Rights Reserved.
// Any use of this source code is subject to a license agreement with the
// AUTOSAR development cooperation.
// More information is available at www.autosar.org.
//
// Disclaimer
//
// This work (specification and/or software implementation) and the material
// contained in it, as released by AUTOSAR, is for the purpose of information
// only. AUTOSAR and the companies that have contributed to it shall not be
// liable for any use of the work.
//
// The material contained in this work is protected by copyright and other
// types of intellectual property rights. The commercial exploitation of the
// material contained in this work requires a license to such intellectual
// property rights.
//
// This work may be utilized or reproduced without any modification, in any
// form or by any means, for informational purposes only. For any other
// purpose, no part of the work may be utilized or reproduced, in any form
// or by any means, without permission in writing from the publisher.
//
// The work has been developed for automotive applications only. It has
// neither been developed, nor tested for non-automotive applications.
//
// The word AUTOSAR and the AUTOSAR logo are registered trademarks.
// --------------------------------------------------------------------------

#ifndef diagnostics_vsomeip_ara_diag_example_adapter_inputvalueinterface_h
#define diagnostics_vsomeip_ara_diag_example_adapter_inputvalueinterface_h

#include "ara/com/internal/vsomeip/skeleton/vsomeip_skeleton_base.h"
#include "service_desc_inputvalueinterface.h"
#include "ara/diag/example/inputvalueinterface_skeleton.h"

namespace ara {
namespace diag {
namespace example {
namespace inputvalueinterface_binding {
namespace vsomeip {

class InputValueInterfaceServiceAdapter : public ::ara::com::internal::vsomeip::skeleton::ServiceImplBase {
 public:
  using ServiceInterface = skeleton::InputValueInterfaceSkeleton;
  using ServiceDescriptor = descriptors::internal::Service;

  InputValueInterfaceServiceAdapter(ServiceInterface& service, ara::com::internal::InstanceId instance) :
    ::ara::com::internal::vsomeip::skeleton::ServiceImplBase(service, instance),
    input1(instance),
    input2(instance) {
    Connect(service);
    OfferService(ServiceDescriptor::service_id, GetInstanceId(), ServiceDescriptor::service_version, ServiceDescriptor::minor_service_version);
    OfferField(ServiceDescriptor::service_id, GetInstanceId(), descriptors::input1::event_id, descriptors::input1::event_groups);
    OfferField(ServiceDescriptor::service_id, GetInstanceId(), descriptors::input2::event_id, descriptors::input2::event_groups);
  }

  virtual ~InputValueInterfaceServiceAdapter() {
    StopOfferField(descriptors::input1::service_id, GetInstanceId(), descriptors::input1::event_id);
    StopOfferField(descriptors::input2::service_id, GetInstanceId(), descriptors::input2::event_id);
    StopOfferService(ServiceDescriptor::service_id, GetInstanceId());
    Disconnect(dynamic_cast<ServiceInterface&>(service_));
  }

 private:
  void Connect(ServiceInterface& service) {
    service.AddDelegate(*this);
    service.input1.AddDelegate(input1);
    service.input2.AddDelegate(input2);
  }

  void Disconnect(ServiceInterface& service) {
    service.RemoveDelegate(*this);
    service.input1.RemoveDelegate(input1);
    service.input2.RemoveDelegate(input2);
  }

  ara::com::internal::vsomeip::skeleton::MutableFieldImpl<std::int32_t, descriptors::input1> input1;
  ara::com::internal::vsomeip::skeleton::MutableFieldImpl<std::int32_t, descriptors::input2> input2;
};

} // namespace vsomeip
} // namespace inputvalueinterface_binding
} // namespace example
} // namespace diag
} // namespace ara

#endif // diagnostics_vsomeip_ara_diag_example_adapter_inputvalueinterface_h

