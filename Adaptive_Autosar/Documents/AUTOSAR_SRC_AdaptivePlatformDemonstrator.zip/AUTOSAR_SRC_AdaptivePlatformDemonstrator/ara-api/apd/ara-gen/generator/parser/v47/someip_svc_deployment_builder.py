#  --------------------------------------------------------------------------
#  |              _    _ _______     .----.      _____         _____        |
#  |         /\  | |  | |__   __|  .  ____ .    / ____|  /\   |  __ \       |
#  |        /  \ | |  | |  | |    .  / __ \ .  | (___   /  \  | |__) |      |
#  |       / /\ \| |  | |  | |   .  / / / / v   \___ \ / /\ \ |  _  /       |
#  |      / /__\ \ |__| |  | |   . / /_/ /  .   ____) / /__\ \| | \ \       |
#  |     /________\____/   |_|   ^ \____/  .   |_____/________\_|  \_\      |
#  |                              . _ _  .                                  |
#  --------------------------------------------------------------------------
#
#  All Rights Reserved.
#  Any use of this source code is subject to a license agreement with the
#  AUTOSAR development cooperation.
#  More information is available at www.autosar.org.
#
#  Disclaimer
#
#  This work (specification and/or software implementation) and the material
#  contained in it, as released by AUTOSAR, is for the purpose of information
#  only. AUTOSAR and the companies that have contributed to it shall not be
#  liable for any use of the work.
#
#  The material contained in this work is protected by copyright and other
#  types of intellectual property rights. The commercial exploitation of the
#  material contained in this work requires a license to such intellectual
#  property rights.
#
#  This work may be utilized or reproduced without any modification, in any
#  form or by any means, for informational purposes only. For any other
#  purpose, no part of the work may be utilized or reproduced, in any form
#  or by any means, without permission in writing from the publisher.
#
#  The work has been developed for automotive applications only. It has
#  neither been developed, nor tested for non-automotive applications.
#
#  The word AUTOSAR and the AUTOSAR logo are registered trademarks.
#  --------------------------------------------------------------------------

"""
SOMEIP service deployment builder class.
"""

# pylint: disable=too-many-lines,too-many-public-methods
from generator.parser.someip_svc_deployment_builder import SomeIpServiceDeploymentBuilder\
    as DefaultSomeIpServiceDeploymentBuilder

from generator.parser.tree_helper import get_element_or_none, to_milliseconds

class SomeIpServiceDeploymentBuilder(DefaultSomeIpServiceDeploymentBuilder):
    """
    Handles parsing the ARXML part, related to someip network binding.
    """

    def __init__(self, model):
        super().__init__(model)


    def get_provided_si_deployment(self, provided_si):
        """
        Extract provided someip deployment information, will be returned as a
        dict with information
        """
        sd_config_ref = get_element_or_none(provided_si, "SD-SERVER-CONFIG-REF")
        sd_config = self.model.find_referable(str(sd_config_ref)) \
            if sd_config_ref is not None else None
        initial_offer = get_element_or_none(sd_config, "INITIAL-OFFER-BEHAVIOR")
        initial_delay_max = get_element_or_none(initial_offer, "INITIAL-DELAY-MAX-VALUE")
        initial_delay_min = get_element_or_none(initial_offer, "INITIAL-DELAY-MIN-VALUE")
        base_delay = get_element_or_none(initial_offer, "INITIAL-REPETITIONS-BASE-DELAY")
        initial_repetitions_max = get_element_or_none(initial_offer, "INITIAL-REPETITIONS-MAX")
        offer_cyclic_delay = get_element_or_none(sd_config, "OFFER-CYCLIC-DELAY")
        service_offer_time_to_live = get_element_or_none(sd_config, "SERVICE-OFFER-TIME-TO-LIVE")
        request_response_delay_max = get_element_or_none(sd_config, "REQUEST-RESPONSE-DELAY/MAX-VALUE")
        request_response_delay_min = get_element_or_none(sd_config, "REQUEST-RESPONSE-DELAY/MIN-VALUE")
        instance_id = get_element_or_none(provided_si, "SERVICE-INSTANCE-ID")

        result = {
            "sd_config": {
                "initial_delay_max": to_milliseconds(initial_delay_max),
                "initial_delay_min": to_milliseconds(initial_delay_min),
                "initial_repetitions_base_delay": to_milliseconds(base_delay),
                "initial_repetitions_max": initial_repetitions_max,
                "cyclic_delay": to_milliseconds(offer_cyclic_delay),
                "ttl": service_offer_time_to_live,
                "request_response_delay_max": to_milliseconds(request_response_delay_max),
                "request_response_delay_min": to_milliseconds(request_response_delay_min)
            },
            "instance_id": instance_id
        }

        return result

    def get_required_si_deployment(self, required_si):
        """
        Extract required someip deployment information, will be returned as a
        dict with information
        """
        sd_config_ref = get_element_or_none(required_si, "SD-CLIENT-CONFIG-REF")
        sd_config = self.model.find_referable(str(sd_config_ref)) \
            if sd_config_ref is not None else None
        service_find_time_to_live = get_element_or_none(sd_config, "SERVICE-FIND-TIME-TO-LIVE")
        initial_offer = get_element_or_none(sd_config, "INITIAL-FIND-BEHAVIOR")
        base_delay = get_element_or_none(initial_offer, "INITIAL-REPETITIONS-BASE-DELAY")
        initial_delay_max = get_element_or_none(initial_offer, "INITIAL-DELAY-MAX-VALUE")
        initial_delay_min = get_element_or_none(initial_offer, "INITIAL-DELAY-MIN-VALUE")
        initial_repetitions_max = get_element_or_none(initial_offer, "INITIAL-REPETITIONS-MAX")
        instance_id = get_element_or_none(required_si, "REQUIRED-SERVICE-INSTANCE-ID")

        result = {
            "sd_config": {
                "initial_delay_max": to_milliseconds(initial_delay_max),
                "initial_delay_min": to_milliseconds(initial_delay_min),
                "initial_repetitions_base_delay": to_milliseconds(base_delay),
                "initial_repetitions_max": initial_repetitions_max,
                "ttl": service_find_time_to_live
            },
            "instance_id": instance_id
        }

        return result

