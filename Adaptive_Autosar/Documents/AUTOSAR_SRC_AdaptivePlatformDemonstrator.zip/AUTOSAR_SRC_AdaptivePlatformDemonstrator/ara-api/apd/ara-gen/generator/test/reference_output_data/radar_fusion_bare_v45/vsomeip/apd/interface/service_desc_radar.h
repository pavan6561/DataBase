// --------------------------------------------------------------------------
// |              _    _ _______     .----.      _____         _____        |
// |         /\  | |  | |__   __|  .  ____ .    / ____|  /\   |  __ \       |
// |        /  \ | |  | |  | |    .  / __ \ .  | (___   /  \  | |__) |      |
// |       / /\ \| |  | |  | |   .  / / / / v   \___ \ / /\ \ |  _  /       |
// |      / /__\ \ |__| |  | |   . / /_/ /  .   ____) / /__\ \| | \ \       |
// |     /________\____/   |_|   ^ \____/  .   |_____/________\_|  \_\      |
// |                              . _ _  .                                  |
// --------------------------------------------------------------------------
//
// All Rights Reserved.
// Any use of this source code is subject to a license agreement with the
// AUTOSAR development cooperation.
// More information is available at www.autosar.org.
//
// Disclaimer
//
// This work (specification and/or software implementation) and the material
// contained in it, as released by AUTOSAR, is for the purpose of information
// only. AUTOSAR and the companies that have contributed to it shall not be
// liable for any use of the work.
//
// The material contained in this work is protected by copyright and other
// types of intellectual property rights. The commercial exploitation of the
// material contained in this work requires a license to such intellectual
// property rights.
//
// This work may be utilized or reproduced without any modification, in any
// form or by any means, for informational purposes only. For any other
// purpose, no part of the work may be utilized or reproduced, in any form
// or by any means, without permission in writing from the publisher.
//
// The work has been developed for automotive applications only. It has
// neither been developed, nor tested for non-automotive applications.
//
// The word AUTOSAR and the AUTOSAR logo are registered trademarks.
// --------------------------------------------------------------------------

#ifndef radar_fusion_bare_v45_vsomeip_apd_interface_service_desc_radar_h
#define radar_fusion_bare_v45_vsomeip_apd_interface_service_desc_radar_h

#include "apd/interface/radar_common.h"

#include "ara/com/internal/vsomeip/vsomeip_types.h"

namespace apd {
namespace interface {
namespace radar_binding {
namespace vsomeip {
namespace descriptors {


namespace internal {
    struct Service {
        static constexpr ara::com::internal::vsomeip::types::ServiceId service_id = 0x63;
        static constexpr ara::com::internal::vsomeip::types::ServiceVersionMajor service_version = 0x1;
        static constexpr ara::com::internal::vsomeip::types::ServiceVersionMinor minor_service_version = 0x0;
    };
}

struct Adjust: public internal::Service {
  static constexpr ara::com::internal::vsomeip::types::MethodId method_id = 0x143;
  static constexpr bool is_reliable = false;
};

struct Calibrate: public internal::Service {
  static constexpr ara::com::internal::vsomeip::types::MethodId method_id = 0x144;
  static constexpr bool is_reliable = false;
};

struct FrontObjectDistance : public internal::Service {
    static constexpr ara::com::internal::vsomeip::types::EventId event_id = 0x7d0;
    static constexpr ara::com::internal::vsomeip::types::MethodId get_method_id = ara::com::internal::vsomeip::types::UndefinedMethodId;
    static constexpr bool is_getter_reliable = false;
    static constexpr ara::com::internal::vsomeip::types::EventGroupId event_groups[] { 0x4 };
};
struct ObjectDetectionLimit : public internal::Service {
    static constexpr ara::com::internal::vsomeip::types::EventId event_id = ara::com::internal::vsomeip::types::UndefinedEventId;
    static constexpr ara::com::internal::vsomeip::types::MethodId get_method_id = ara::com::internal::vsomeip::types::UndefinedMethodId;
    static constexpr bool is_getter_reliable = false;
    static constexpr ara::com::internal::vsomeip::types::EventGroupId event_groups[] { 0x0 };
    static constexpr ara::com::internal::vsomeip::types::MethodId set_method_id = 0x7d1;
    static constexpr bool is_setter_reliable = true;
};
struct RearObjectDistance : public internal::Service {
    static constexpr ara::com::internal::vsomeip::types::EventId event_id = ara::com::internal::vsomeip::types::UndefinedEventId;
    static constexpr ara::com::internal::vsomeip::types::MethodId get_method_id = 0x7d2;
    static constexpr bool is_getter_reliable = true;
    static constexpr ara::com::internal::vsomeip::types::EventGroupId event_groups[] { 0x0 };
};
struct UpdateRate : public internal::Service {
    static constexpr ara::com::internal::vsomeip::types::EventId event_id = 0x7d4;
    static constexpr ara::com::internal::vsomeip::types::MethodId get_method_id = 0x7d3;
    static constexpr bool is_getter_reliable = true;
    static constexpr ara::com::internal::vsomeip::types::EventGroupId event_groups[] { 0x3 };
    static constexpr ara::com::internal::vsomeip::types::MethodId set_method_id = 0x7d5;
    static constexpr bool is_setter_reliable = true;
};
struct brakeEvent : public internal::Service {
  static constexpr ara::com::internal::vsomeip::types::EventId event_id = 0x3e8;
  static constexpr ara::com::internal::vsomeip::types::EventGroupId event_groups[] { 0x1 };
};

struct parkingBrakeEvent : public internal::Service {
  static constexpr ara::com::internal::vsomeip::types::EventId event_id = 0x3e9;
  static constexpr ara::com::internal::vsomeip::types::EventGroupId event_groups[] { 0x2 };
};

} // namespace descriptors
} // namespace vsomeip
} // namespace radar_binding
} // namespace interface
} // namespace apd

#endif // radar_fusion_bare_v45_vsomeip_apd_interface_service_desc_radar_h

