#  --------------------------------------------------------------------------
#  |              _    _ _______     .----.      _____         _____        |
#  |         /\  | |  | |__   __|  .  ____ .    / ____|  /\   |  __ \       |
#  |        /  \ | |  | |  | |    .  / __ \ .  | (___   /  \  | |__) |      |
#  |       / /\ \| |  | |  | |   .  / / / / v   \___ \ / /\ \ |  _  /       |
#  |      / /__\ \ |__| |  | |   . / /_/ /  .   ____) / /__\ \| | \ \       |
#  |     /________\____/   |_|   ^ \____/  .   |_____/________\_|  \_\      |
#  |                              . _ _  .                                  |
#  --------------------------------------------------------------------------
#
#  All Rights Reserved.
#  Any use of this source code is subject to a license agreement with the
#  AUTOSAR development cooperation.
#  More information is available at www.autosar.org.
#
#  Disclaimer
#
#  This work (specification and/or software implementation) and the material
#  contained in it, as released by AUTOSAR, is for the purpose of information
#  only. AUTOSAR and the companies that have contributed to it shall not be
#  liable for any use of the work.
#
#  The material contained in this work is protected by copyright and other
#  types of intellectual property rights. The commercial exploitation of the
#  material contained in this work requires a license to such intellectual
#  property rights.
#
#  This work may be utilized or reproduced without any modification, in any
#  form or by any means, for informational purposes only. For any other
#  purpose, no part of the work may be utilized or reproduced, in any form
#  or by any means, without permission in writing from the publisher.
#
#  The work has been developed for automotive applications only. It has
#  neither been developed, nor tested for non-automotive applications.
#
#  The word AUTOSAR and the AUTOSAR logo are registered trademarks.
#  --------------------------------------------------------------------------

from generator.views.basetype_view import BaseTypeView
from generator.views.impltype_view import StructImplTypeView, \
    EnumImplTypeView, MapImplTypeView, AliasedImplTypeView, AliasedBaseImplTypeView,\
    VectorImplTypeView, StringImplTypeView, ArrayImplTypeView

class ViewManipulations(object):
    # cpp types according to SWS_AdaptivePlatformTypes
    _basetypes_dict = {'boolean': 'bool',
                       'cpp_bool': 'bool',
                       'std_int8_t': 'std::int8_t',
                       'std_int16_t': 'std::int16_t',
                       'std_int32_t': 'std::int32_t',
                       'std_int64_t': 'std::int64_t',
                       'std_int8_least_t': 'std::int_least8_t',
                       'std_int16_least_t': 'std::int_least16_t',
                       'std_int32_least_t': 'std::int_least32_t',
                       'std_uint8_t': 'std::uint8_t',
                       'std_uint16_t': 'std::uint16_t',
                       'std_uint32_t': 'std::uint32_t',
                       'std_uint64_t': 'std::uint64_t',
                       'std_uint8_least_t': 'std::uint_least8_t',
                       'std_uint16_least_t': 'std::uint_least16_t',
                       'std_uint32_least_t': 'std::uint_least32_t',
                       'std_float32_t': 'float',
                       'std_float64_t': 'double'}


    @staticmethod
    def _std_type_name(path):
        """
        Extract the basetype name from a type path. If no path then return
        the string itself
        """
        if "/" in path:
            path_list = path.split("/")
            type_name = str(path_list[len(path_list) - 1])
        else:
            type_name = path
        return type_name


    @staticmethod
    def _cppname(basetype):
        btype_name = ViewManipulations._std_type_name(str(basetype.name))
        return ViewManipulations._basetypes_dict[btype_name]


    @staticmethod
    def get_view_kind(view):
        classname = view.__class__.__name__
        if classname == 'StringImplTypeView':
            kind = 'string'
        elif classname == 'StructImplTypeView':
            kind = 'structure'
        elif classname == 'EnumImplTypeView':
            kind = 'enum'
        elif classname == 'MapImplTypeView':
            kind = 'map'
        elif classname == 'VectorImplTypeView':
            kind = 'vector'
        elif classname == 'ArrayImplTypeView':
            kind = 'array'
        elif classname == 'AliasedImplTypeView':
            kind = 'aliased_impltype'
        elif classname == 'AliasedBaseImplTypeView':
            kind = 'aliased_basetype'
        elif classname == 'BaseTypeView':
            kind = 'basetype'
        else:
            kind = 'unknown'

        return kind


    @staticmethod
    def to_view(_type):
        result = None
        classname = _type.__class__.__name__
        if classname == 'StringImplDataType':
            result = StringImplTypeView(_type)
        elif classname == 'StructureImplDataType':
            result = StructImplTypeView(_type)
        elif classname == 'EnumImplDataType':
            result = EnumImplTypeView(_type)
        elif classname == 'MapImplDataType':
            result = MapImplTypeView(_type)
        elif classname == 'LinearVectorImplDataType':
            result = VectorImplTypeView(_type)
        elif classname == 'ArrayImplDataType':
            result = ArrayImplTypeView(_type)
        elif classname == 'ImplDataType':
            assert _type.referred_types, \
                '{} must have type it based on'.format(_type.name)
            result = AliasedImplTypeView(_type)
            if not _type.type_is_new:
                if _type.referred_types[0].__class__.__name__ == 'BaseType':
                    result = AliasedBaseImplTypeView(_type)
        elif classname == 'BaseType':
            if _type.type_is_new:
                result = BaseTypeView(_type, None)
            else:
                result = BaseTypeView(_type, ViewManipulations._cppname(_type))
        else:
            assert False, "unexpected type {}".format(classname)

        return result


    @staticmethod
    def _convert_to_view_tree(_type):
        view = ViewManipulations.to_view(_type)
        for t in _type.referred_types:
            vt = ViewManipulations._convert_to_view_tree(t)
            view.add_referred_view(vt)
        return view
