#  --------------------------------------------------------------------------
#  |              _    _ _______     .----.      _____         _____        |
#  |         /\  | |  | |__   __|  .  ____ .    / ____|  /\   |  __ \       |
#  |        /  \ | |  | |  | |    .  / __ \ .  | (___   /  \  | |__) |      |
#  |       / /\ \| |  | |  | |   .  / / / / v   \___ \ / /\ \ |  _  /       |
#  |      / /__\ \ |__| |  | |   . / /_/ /  .   ____) / /__\ \| | \ \       |
#  |     /________\____/   |_|   ^ \____/  .   |_____/________\_|  \_\      |
#  |                              . _ _  .                                  |
#  --------------------------------------------------------------------------
#
#  All Rights Reserved.
#  Any use of this source code is subject to a license agreement with the
#  AUTOSAR development cooperation.
#  More information is available at www.autosar.org.
#
#  Disclaimer
#
#  This work (specification and/or software implementation) and the material
#  contained in it, as released by AUTOSAR, is for the purpose of information
#  only. AUTOSAR and the companies that have contributed to it shall not be
#  liable for any use of the work.
#
#  The material contained in this work is protected by copyright and other
#  types of intellectual property rights. The commercial exploitation of the
#  material contained in this work requires a license to such intellectual
#  property rights.
#
#  This work may be utilized or reproduced without any modification, in any
#  form or by any means, for informational purposes only. For any other
#  purpose, no part of the work may be utilized or reproduced, in any form
#  or by any means, without permission in writing from the publisher.
#
#  The work has been developed for automotive applications only. It has
#  neither been developed, nor tested for non-automotive applications.
#
#  The word AUTOSAR and the AUTOSAR logo are registered trademarks.
#  --------------------------------------------------------------------------

import os
import logging
from generator.views.service_view import ServiceView
from generator.views.component_view import ComponentView
from generator.parser.exception_handling import handle_method_exceptions

class VsomeipBinding(object):
    def __init__(self, template_loader, template_renderer, output_dir) -> None:
        self._render_template = template_renderer
        self._load_template = template_loader
        self._output_dir = output_dir
        self._log = logging.getLogger(__name__)

    @property
    def vsomeip_root_dir(self):
        return os.path.join(self._output_dir, 'vsomeip')

    def vsomeip_service_dir(self, service: ServiceView):
        if service.namespaces is not None:
            return os.path.join(self.vsomeip_root_dir, *service.namespaces)
        else:
            return self.vsomeip_root_dir

    @handle_method_exceptions(error_string_template="VSOMEIP service description generation ERROR: {exception_text}")
    def generate_service_desc(self, service_interface):
        """Generate the cpp and h files for service description"""
        si_desc_template_h = self._load_template(
            "vsomeip_binding/service_desc_xxx_h.j2", True)
        si_desc_template_cpp = self._load_template(
            "vsomeip_binding/service_desc_xxx_cpp.j2", True)

        file_output_dir = self.vsomeip_service_dir(service_interface)

        self._log.debug("Writing service_desc_%s.h content to file",
                        service_interface.standard_name)
        self._render_template(si_desc_template_h, file_output_dir,
                              "service_desc_" + service_interface.standard_name + ".h",
                              service=service_interface)

        self._log.debug("Writing service_desc_%s.cpp content to file",
                        service_interface.standard_name)
        self._render_template(
            si_desc_template_cpp, file_output_dir,
            "service_desc_" + service_interface.standard_name + ".cpp",
            service=service_interface)

        si_err_template_h = self._load_template(
            "vsomeip_binding/errors_xxx_h.j2", True)

        self._render_template(si_err_template_h, file_output_dir,
                              "errors_" + service_interface.standard_name + ".h",
                              service=service_interface)

    @handle_method_exceptions(error_string_template="VSOMEIP JSON config generation ERROR: {exception_text}")
    def generate_vsomeip_json(self, machine, logging_settings):
        """Generate the vsomeip json file required by genivi vsomeip"""
        vsomeip_template = self._load_template("vsomeip_binding/xxx_vsomeip_json.j2", True)

        self._render_template(vsomeip_template, self.vsomeip_root_dir,
                              machine.standard_name + "_vsomeip.json",
                              applications=machine.process_views,
                              machine=machine,
                              services=machine.provided_services_list,
                              log_settings=logging_settings)

    def generate_proxy(self, service: ServiceView):
        """Generate the proxy h file required by application"""
        proxy_vsomeip_template = self._load_template(
            "vsomeip_binding/proxy_vsomeip_xxx_h.j2", True)

        file_output_dir = self.vsomeip_service_dir(service)

        self._log.debug("Writing content to file proxy_vsomeip_%s",
                        service.standard_name + ".h")
        self._render_template(proxy_vsomeip_template, file_output_dir,
                              "proxy_vsomeip_" + service.standard_name + ".h",
                              service=service)

    def generate_si_adapter(self, service: ServiceView):
        """Generate the adapter_<name>.h file for the service interface"""
        si_adapter_template = self._load_template(
            "vsomeip_binding/adapter_xxx_h.j2", True)

        file_output_dir = self.vsomeip_service_dir(service)

        self._log.debug("Writing content of adapter_%s.h to file",
                        service.standard_name)
        self._render_template(si_adapter_template, file_output_dir,
                              "adapter_" + service.standard_name + ".h",
                              service=service)

    def generate_sm_definition(self, component: ComponentView, services_list: list):
        """
        Generate the vsomeip_service_mapping-<>.cpp
        for the service mapping
        """
        sm_def_template_cpp = self._load_template(
            "vsomeip_binding/vsomeip_service_mapping-xxx_cpp.j2")

        file_output_dir = self.vsomeip_root_dir
        self._render_template(
            sm_def_template_cpp, file_output_dir,
            "vsomeip_service_mapping-" + component.name + ".cpp",
            component=component, services_list=services_list)

    def generate_machine_config(self, machine, logging_settings):
        self.generate_vsomeip_json(machine, logging_settings)
