// --------------------------------------------------------------------------
// |              _    _ _______     .----.      _____         _____        |
// |         /\  | |  | |__   __|  .  ____ .    / ____|  /\   |  __ \       |
// |        /  \ | |  | |  | |    .  / __ \ .  | (___   /  \  | |__) |      |
// |       / /\ \| |  | |  | |   .  / / / / v   \___ \ / /\ \ |  _  /       |
// |      / /__\ \ |__| |  | |   . / /_/ /  .   ____) / /__\ \| | \ \       |
// |     /________\____/   |_|   ^ \____/  .   |_____/________\_|  \_\      |
// |                              . _ _  .                                  |
// --------------------------------------------------------------------------
//
// All Rights Reserved.
// Any use of this source code is subject to a license agreement with the
// AUTOSAR development cooperation.
// More information is available at www.autosar.org.
//
// Disclaimer
//
// This work (specification and/or software implementation) and the material
// contained in it, as released by AUTOSAR, is for the purpose of information
// only. AUTOSAR and the companies that have contributed to it shall not be
// liable for any use of the work.
//
// The material contained in this work is protected by copyright and other
// types of intellectual property rights. The commercial exploitation of the
// material contained in this work requires a license to such intellectual
// property rights.
//
// This work may be utilized or reproduced without any modification, in any
// form or by any means, for informational purposes only. For any other
// purpose, no part of the work may be utilized or reproduced, in any form
// or by any means, without permission in writing from the publisher.
//
// The work has been developed for automotive applications only. It has
// neither been developed, nor tested for non-automotive applications.
//
// The word AUTOSAR and the AUTOSAR logo are registered trademarks.
// --------------------------------------------------------------------------

#ifndef diagnostics_vsomeip_vsomeip_service_mapping_dcmCalculatorPluginTyped_cpp
#define diagnostics_vsomeip_vsomeip_service_mapping_dcmCalculatorPluginTyped_cpp

#include "ara/com/internal/vsomeip/vsomeip_service_mapping.h"
#include "ara/com/internal/vsomeip/vsomeip_service_mapping_impl.h"

#include "ara/diag/example/proxy_vsomeip_addinterface.h"
#include "ara/diag/example/proxy_vsomeip_diag_addarginterface.h"
#include "ara/diag/example/proxy_vsomeip_inputvalueinterface.h"
#include "ara/diag/example/proxy_vsomeip_outputvalueinterface.h"

namespace ara {
namespace com {
namespace internal {
namespace vsomeip {
namespace runtime {

namespace {

ServiceMappingImpl<
  ara::diag::example::AddInterface::service_id,
  ara::diag::example::addinterface_binding::vsomeip::descriptors::internal::Service::service_id,
  ara::diag::example::addinterface_binding::vsomeip::AddInterfaceImpl,
  NoAdapter
> ara__diag__example__addinterface__mapping;

ServiceMappingImpl<
  ara::diag::example::Diag_AddArgInterface::service_id,
  ara::diag::example::diag_addarginterface_binding::vsomeip::descriptors::internal::Service::service_id,
  ara::diag::example::diag_addarginterface_binding::vsomeip::Diag_AddArgInterfaceImpl,
  NoAdapter
> ara__diag__example__diag_addarginterface__mapping;

ServiceMappingImpl<
  ara::diag::example::InputValueInterface::service_id,
  ara::diag::example::inputvalueinterface_binding::vsomeip::descriptors::internal::Service::service_id,
  ara::diag::example::inputvalueinterface_binding::vsomeip::InputValueInterfaceImpl,
  NoAdapter
> ara__diag__example__inputvalueinterface__mapping;

ServiceMappingImpl<
  ara::diag::example::OutputValueInterface::service_id,
  ara::diag::example::outputvalueinterface_binding::vsomeip::descriptors::internal::Service::service_id,
  ara::diag::example::outputvalueinterface_binding::vsomeip::OutputValueInterfaceImpl,
  NoAdapter
> ara__diag__example__outputvalueinterface__mapping;

}

const VSomeIPServiceMapping::Mapping* VSomeIPServiceMapping::GetMappingForServiceId(ServiceId service_id) {
  switch (service_id) {
    case ara::diag::example::AddInterface::service_id:
      return &ara__diag__example__addinterface__mapping;
    case ara::diag::example::Diag_AddArgInterface::service_id:
      return &ara__diag__example__diag_addarginterface__mapping;
    case ara::diag::example::InputValueInterface::service_id:
      return &ara__diag__example__inputvalueinterface__mapping;
    case ara::diag::example::OutputValueInterface::service_id:
      return &ara__diag__example__outputvalueinterface__mapping;
    default:
      return nullptr;
  }
}

VSomeIPServiceMapping::MultiMapping VSomeIPServiceMapping::GetMappingForVSomeIPServiceId(::vsomeip::service_t service_id) {
  switch(service_id) {
    case ara::diag::example::addinterface_binding::vsomeip::descriptors::internal::Service::service_id:
      return {
        &ara__diag__example__addinterface__mapping,
      };
    case ara::diag::example::diag_addarginterface_binding::vsomeip::descriptors::internal::Service::service_id:
      return {
        &ara__diag__example__diag_addarginterface__mapping,
      };
    case ara::diag::example::inputvalueinterface_binding::vsomeip::descriptors::internal::Service::service_id:
      return {
        &ara__diag__example__inputvalueinterface__mapping,
      };
    case ara::diag::example::outputvalueinterface_binding::vsomeip::descriptors::internal::Service::service_id:
      return {
        &ara__diag__example__outputvalueinterface__mapping,
      };
    default:
      return {};
  }
}

} // namespace runtime
} // namespace vsomeip
} // namespace internal
} // namespace com
} // namespace ara

#endif // diagnostics_vsomeip_vsomeip_service_mapping_dcmCalculatorPluginTyped_cpp

