#  --------------------------------------------------------------------------
#  |              _    _ _______     .----.      _____         _____        |
#  |         /\  | |  | |__   __|  .  ____ .    / ____|  /\   |  __ \       |
#  |        /  \ | |  | |  | |    .  / __ \ .  | (___   /  \  | |__) |      |
#  |       / /\ \| |  | |  | |   .  / / / / v   \___ \ / /\ \ |  _  /       |
#  |      / /__\ \ |__| |  | |   . / /_/ /  .   ____) / /__\ \| | \ \       |
#  |     /________\____/   |_|   ^ \____/  .   |_____/________\_|  \_\      |
#  |                              . _ _  .                                  |
#  --------------------------------------------------------------------------
#
#  All Rights Reserved.
#  Any use of this source code is subject to a license agreement with the
#  AUTOSAR development cooperation.
#  More information is available at www.autosar.org.
#
#  Disclaimer
#
#  This work (specification and/or software implementation) and the material
#  contained in it, as released by AUTOSAR, is for the purpose of information
#  only. AUTOSAR and the companies that have contributed to it shall not be
#  liable for any use of the work.
#
#  The material contained in this work is protected by copyright and other
#  types of intellectual property rights. The commercial exploitation of the
#  material contained in this work requires a license to such intellectual
#  property rights.
#
#  This work may be utilized or reproduced without any modification, in any
#  form or by any means, for informational purposes only. For any other
#  purpose, no part of the work may be utilized or reproduced, in any form
#  or by any means, without permission in writing from the publisher.
#
#  The work has been developed for automotive applications only. It has
#  neither been developed, nor tested for non-automotive applications.
#
#  The word AUTOSAR and the AUTOSAR logo are registered trademarks.
#  --------------------------------------------------------------------------

"""
MachineView corresponding to a Machine IM object.
"""

from generator.intermediate_model.execution_management.machine \
    import Machine
from generator.views.process_view import ProcessView
from generator.views.service_view import ServiceView
from generator.views.view import View
from generator.views.component_view import ComponentView
from generator.views.view_factory import ViewFactory


class MachineView(View):
    """Specialized View of a Machine."""

    def __init__(self, machine: Machine) -> None:
        self._machine = machine
        self._required_services = list(set([ViewFactory.create_service_view(service)
            for process in self._machine.processes
            for component in process.executable.components
            for service in component.required_services]))
        self._provided_services = list(set([ViewFactory.create_service_view(service)
            for process in self._machine.processes
            for component in process.executable.components
            for service in component.provided_services]))
        self._process_views  = list([ProcessView(process)
            for process in self._machine.processes])

        provided_sd_config_list = list([service.service_deployment.sd_config
            for service in self._provided_services])
        required_sd_config_list = list([service.service_deployment.sd_config
            for service in self._required_services])
        self._sd_config = dict()
        for config in provided_sd_config_list + required_sd_config_list:
            for key, value in config.items():
                if value is None:
                    continue
                if key not in self._sd_config:
                    self._sd_config[key] = value
                elif not value == self._sd_config[key]:
                    raise RuntimeError("Inconsistent Configuration for SOME/IP Service Discovery Configuration Value '{0}'. First: {1}, Second: {2}".format(key, self._sd_config[key], value))

        super().__init__(machine)

    @property
    def get_machine(self):
        """Get the machine in the view"""
        return self._machine

    @property
    def sd_config(self):
        """Get the service discovery configuration for the machine"""
        return self._sd_config

    def get_components(self):
        """Get the ComponentView of all SoftwareComonent in this machine"""
        return [ComponentView(component) for process in self._machine.processes for component in
                process.executable.components]

    def service_is_required(self, serviceview: ServiceView):
        return serviceview in self._required_services

    def service_is_provided(self, serviceview: ServiceView):
        return serviceview in self._provided_services

    @property
    def process_views(self):
        return self._process_views

    @property
    def services_list(self):
        _services = list(set(self._required_services + self._provided_services))
        _services.sort(key=lambda field: field.fqn.lower())
        return _services

    @property
    def provided_services_list(self):
        return sorted(self._provided_services)
