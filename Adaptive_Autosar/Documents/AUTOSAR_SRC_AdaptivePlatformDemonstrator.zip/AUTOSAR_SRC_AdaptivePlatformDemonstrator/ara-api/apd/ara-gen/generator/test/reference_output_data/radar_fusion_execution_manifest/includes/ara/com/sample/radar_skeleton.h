// --------------------------------------------------------------------------
// |              _    _ _______     .----.      _____         _____        |
// |         /\  | |  | |__   __|  .  ____ .    / ____|  /\   |  __ \       |
// |        /  \ | |  | |  | |    .  / __ \ .  | (___   /  \  | |__) |      |
// |       / /\ \| |  | |  | |   .  / / / / v   \___ \ / /\ \ |  _  /       |
// |      / /__\ \ |__| |  | |   . / /_/ /  .   ____) / /__\ \| | \ \       |
// |     /________\____/   |_|   ^ \____/  .   |_____/________\_|  \_\      |
// |                              . _ _  .                                  |
// --------------------------------------------------------------------------
//
// All Rights Reserved.
// Any use of this source code is subject to a license agreement with the
// AUTOSAR development cooperation.
// More information is available at www.autosar.org.
//
// Disclaimer
//
// This work (specification and/or software implementation) and the material
// contained in it, as released by AUTOSAR, is for the purpose of information
// only. AUTOSAR and the companies that have contributed to it shall not be
// liable for any use of the work.
//
// The material contained in this work is protected by copyright and other
// types of intellectual property rights. The commercial exploitation of the
// material contained in this work requires a license to such intellectual
// property rights.
//
// This work may be utilized or reproduced without any modification, in any
// form or by any means, for informational purposes only. For any other
// purpose, no part of the work may be utilized or reproduced, in any form
// or by any means, without permission in writing from the publisher.
//
// The work has been developed for automotive applications only. It has
// neither been developed, nor tested for non-automotive applications.
//
// The word AUTOSAR and the AUTOSAR logo are registered trademarks.
// --------------------------------------------------------------------------

#ifndef radar_fusion_execution_manifest_includes_ara_com_sample_radar_skeleton_h
#define radar_fusion_execution_manifest_includes_ara_com_sample_radar_skeleton_h

#include "ara/com/internal/skeleton/ara_skeleton_base.h"

#include "ara/com/illegal_state_exception.h"
#include "radar_common.h"

namespace ara {
namespace com {
namespace sample {
namespace skeleton {

namespace fields {
  /// @uptrace{SWS_CM_00007}
  using UpdateRate = ara::com::internal::skeleton::MutableFieldDispatcher<std::uint32_t>;
  using FrontObjectDistance = ara::com::internal::skeleton::FieldDispatcher<std::uint16_t>;
  using RearObjectDistance = ara::com::internal::skeleton::FieldDispatcher<std::uint16_t>;
  using ObjectDetectionLimit = ara::com::internal::skeleton::MutableFieldDispatcher<std::uint16_t>;
} // namespace fields

namespace events {
  /// @uptrace{SWS_CM_00003}
  using brakeEvent = ara::com::internal::skeleton::EventDispatcher<::ara::com::sample::RadarObjects>;
  using parkingBrakeEvent = ara::com::internal::skeleton::EventDispatcher<::ara::com::sample::RadarObjects>;
} // namespace events

/// @uptrace{SWS_CM_00002}
class radarSkeleton : public ara::com::sample::radar, public ara::com::internal::skeleton::TypedServiceImplBase<radarSkeleton> {
public:
  /// @uptrace{SWS_CM_00130}
  radarSkeleton(ara::com::InstanceIdentifier instance_id, ara::com::MethodCallProcessingMode mode = ara::com::MethodCallProcessingMode::kEvent) : ara::com::internal::skeleton::TypedServiceImplBase<radarSkeleton>(instance_id, mode) {}
  virtual ~radarSkeleton() {
    StopOfferService();
  }

  /// @brief Skeleton shall be move constructable.
  ///
  /// @uptrace{SWS_CM_00135}
  explicit radarSkeleton(radarSkeleton&&) = default;

  /// @brief Skeleton shall be move assignable.
  ///
  /// @uptrace{SWS_CM_00135}
  radarSkeleton& operator=(radarSkeleton&&) = default;

  /// @brief Skeleton shall not be copy constructable.
  ///
  /// @uptrace{SWS_CM_00134}
  explicit radarSkeleton(const radarSkeleton&) = delete;

  /// @brief Skeleton shall not be copy assignable.
  ///
  /// @uptrace{SWS_CM_00134}
  radarSkeleton& operator=(const radarSkeleton&) = delete;

  void OfferService() {
    if(!UpdateRate.IsInitialized()) {
      throw ara::com::IllegalStateException("Attempt to offer service \"/apd/da/radar\" with uninitialized field \"UpdateRate\"");
    }
    if(!FrontObjectDistance.IsInitialized()) {
      throw ara::com::IllegalStateException("Attempt to offer service \"/apd/da/radar\" with uninitialized field \"FrontObjectDistance\"");
    }
    if(!RearObjectDistance.IsInitialized()) {
      throw ara::com::IllegalStateException("Attempt to offer service \"/apd/da/radar\" with uninitialized field \"RearObjectDistance\"");
    }
    if(!ObjectDetectionLimit.IsInitialized()) {
      throw ara::com::IllegalStateException("Attempt to offer service \"/apd/da/radar\" with uninitialized field \"ObjectDetectionLimit\"");
    }

    ara::com::internal::skeleton::TypedServiceImplBase<radarSkeleton>::OfferService();
  }

  /// @uptrace{SWS_CM_00191}
  using ara::com::sample::radar::AdjustOutput;
  virtual ara::core::Future<AdjustOutput> Adjust(const ::ara::com::sample::Position& target_position) = 0;
  using ara::com::sample::radar::CalibrateOutput;
  virtual ara::core::Future<CalibrateOutput> Calibrate(const ::String& configuration,const ::ara::com::sample::FusionVariant& variant) = 0;
  fields::UpdateRate UpdateRate;
  fields::FrontObjectDistance FrontObjectDistance;
  fields::RearObjectDistance RearObjectDistance;
  fields::ObjectDetectionLimit ObjectDetectionLimit;
  events::brakeEvent brakeEvent;
  events::parkingBrakeEvent parkingBrakeEvent;
};

} // namespace skeleton
} // namespace sample
} // namespace com
} // namespace ara

#endif // radar_fusion_execution_manifest_includes_ara_com_sample_radar_skeleton_h

