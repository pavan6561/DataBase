// --------------------------------------------------------------------------
// |              _    _ _______     .----.      _____         _____        |
// |         /\  | |  | |__   __|  .  ____ .    / ____|  /\   |  __ \       |
// |        /  \ | |  | |  | |    .  / __ \ .  | (___   /  \  | |__) |      |
// |       / /\ \| |  | |  | |   .  / / / / v   \___ \ / /\ \ |  _  /       |
// |      / /__\ \ |__| |  | |   . / /_/ /  .   ____) / /__\ \| | \ \       |
// |     /________\____/   |_|   ^ \____/  .   |_____/________\_|  \_\      |
// |                              . _ _  .                                  |
// --------------------------------------------------------------------------
//
// All Rights Reserved.
// Any use of this source code is subject to a license agreement with the
// AUTOSAR development cooperation.
// More information is available at www.autosar.org.
//
// Disclaimer
//
// This work (specification and/or software implementation) and the material
// contained in it, as released by AUTOSAR, is for the purpose of information
// only. AUTOSAR and the companies that have contributed to it shall not be
// liable for any use of the work.
//
// The material contained in this work is protected by copyright and other
// types of intellectual property rights. The commercial exploitation of the
// material contained in this work requires a license to such intellectual
// property rights.
//
// This work may be utilized or reproduced without any modification, in any
// form or by any means, for informational purposes only. For any other
// purpose, no part of the work may be utilized or reproduced, in any form
// or by any means, without permission in writing from the publisher.
//
// The work has been developed for automotive applications only. It has
// neither been developed, nor tested for non-automotive applications.
//
// The word AUTOSAR and the AUTOSAR logo are registered trademarks.
// --------------------------------------------------------------------------

#ifndef map_sample_v45_includes_ara_gen_map_proxy_h
#define map_sample_v45_includes_ara_gen_map_proxy_h

#include "ara/com/internal/proxy/ara_proxy_base.h"
#include "map_common.h"

namespace ara {
namespace gen {
namespace proxy {


namespace fields {
using SimpleMapField = ara::com::internal::proxy::Field<::ara::diag::datatypes::MetaInfoTypeInt>;
template <typename T, bool E2E = ara::com::internal::e2e::is_e2e_enabled<T>::value>
class SimpleMapProxy {
private:
  SimpleMapField& field;

public:
  explicit SimpleMapProxy(SimpleMapField& field_base)
      : field(field_base)
  { }
  /// @brief Field.
  /// @uptrace{SWS_CM_00132}
  ara::core::Future<::ara::diag::datatypes::MetaInfoTypeInt> Get() {
    return field.Get();
  }

};
/// @uptrace{SWS_CM_00008}
using SimpleMap = SimpleMapProxy<::ara::diag::datatypes::MetaInfoTypeInt>;
using FullMapField = ara::com::internal::proxy::Field<::ara::diag::datatypes::MetaInfoType>;
template <typename T, bool E2E = ara::com::internal::e2e::is_e2e_enabled<T>::value>
class FullMapProxy {
private:
  FullMapField& field;

public:
  explicit FullMapProxy(FullMapField& field_base)
      : field(field_base)
  { }
  /// @brief Field.
  /// @uptrace{SWS_CM_00132}
  ara::core::Future<::ara::diag::datatypes::MetaInfoType> Get() {
    return field.Get();
  }

};
/// @uptrace{SWS_CM_00008}
using FullMap = FullMapProxy<::ara::diag::datatypes::MetaInfoType>;
} // namespace fields


class mapProxyBase : public ara::com::internal::proxy::ProxyBindingBase, public ara::gen::map {
public:
  virtual fields::SimpleMapField& GetSimpleMap() = 0;
  virtual fields::FullMapField& GetFullMap() = 0;
};

/// @uptrace{SWS_CM_00004}
class mapProxy : public ara::com::internal::proxy::ProxyBase<mapProxyBase>, public ara::gen::map {
private:
  fields::SimpleMapField& SimpleMapField;
  fields::FullMapField& FullMapField;

public:
  /// @brief Proxy constructor.
  ///
  /// @uptrace{SWS_CM_00131}
  explicit mapProxy(const HandleType& proxy_base_factory)
      : ara::com::internal::proxy::ProxyBase<mapProxyBase>(proxy_base_factory)
      , SimpleMapField(proxy_base_->GetSimpleMap())
      , FullMapField(proxy_base_->GetFullMap())
      , SimpleMap(SimpleMapField)
      , FullMap(FullMapField)
  {}

  /// @brief Proxy shall be move constructable.
  ///
  /// @uptrace{SWS_CM_00137}
  explicit mapProxy(mapProxy&&) = default;

  /// @brief Proxy shall be move assignable.
  ///
  /// @uptrace{SWS_CM_00137}
  mapProxy& operator=(mapProxy&&) = default;

  /// @brief Proxy shall not be copy constructable.
  ///
  /// @uptrace{SWS_CM_00136}
  explicit mapProxy(const mapProxy&) = delete;

  /// @brief Proxy shall not be copy assignable.
  ///
  /// @uptrace{SWS_CM_00136}
  mapProxy& operator=(const mapProxy&) = delete;

  fields::SimpleMap SimpleMap;
  fields::FullMap FullMap;
};

} // namespace proxy
} // namespace gen
} // namespace ara

#endif // map_sample_v45_includes_ara_gen_map_proxy_h

