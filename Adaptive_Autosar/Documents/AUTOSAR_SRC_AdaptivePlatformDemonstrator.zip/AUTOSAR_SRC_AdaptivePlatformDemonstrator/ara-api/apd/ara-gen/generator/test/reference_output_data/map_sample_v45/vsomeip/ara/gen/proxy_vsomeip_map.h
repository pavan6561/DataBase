// --------------------------------------------------------------------------
// |              _    _ _______     .----.      _____         _____        |
// |         /\  | |  | |__   __|  .  ____ .    / ____|  /\   |  __ \       |
// |        /  \ | |  | |  | |    .  / __ \ .  | (___   /  \  | |__) |      |
// |       / /\ \| |  | |  | |   .  / / / / v   \___ \ / /\ \ |  _  /       |
// |      / /__\ \ |__| |  | |   . / /_/ /  .   ____) / /__\ \| | \ \       |
// |     /________\____/   |_|   ^ \____/  .   |_____/________\_|  \_\      |
// |                              . _ _  .                                  |
// --------------------------------------------------------------------------
//
// All Rights Reserved.
// Any use of this source code is subject to a license agreement with the
// AUTOSAR development cooperation.
// More information is available at www.autosar.org.
//
// Disclaimer
//
// This work (specification and/or software implementation) and the material
// contained in it, as released by AUTOSAR, is for the purpose of information
// only. AUTOSAR and the companies that have contributed to it shall not be
// liable for any use of the work.
//
// The material contained in this work is protected by copyright and other
// types of intellectual property rights. The commercial exploitation of the
// material contained in this work requires a license to such intellectual
// property rights.
//
// This work may be utilized or reproduced without any modification, in any
// form or by any means, for informational purposes only. For any other
// purpose, no part of the work may be utilized or reproduced, in any form
// or by any means, without permission in writing from the publisher.
//
// The work has been developed for automotive applications only. It has
// neither been developed, nor tested for non-automotive applications.
//
// The word AUTOSAR and the AUTOSAR logo are registered trademarks.
// --------------------------------------------------------------------------

#ifndef map_sample_v45_vsomeip_ara_gen_proxy_vsomeip_map_h
#define map_sample_v45_vsomeip_ara_gen_proxy_vsomeip_map_h

#include "service_desc_map.h"
#include "ara/gen/map_proxy.h"

namespace ara {
namespace gen {
namespace map_binding {
namespace vsomeip {

class mapImpl : public proxy::mapProxyBase, public ::ara::com::internal::vsomeip::proxy::ProxyImplBase {
 public:
  using ProxyInterface = proxy::mapProxy;
  using ServiceDescriptor = descriptors::internal::Service;

  explicit mapImpl(ara::com::internal::InstanceId instance) :
      ::ara::com::internal::vsomeip::proxy::ProxyImplBase(ServiceDescriptor::service_id, instance, ServiceDescriptor::service_version),
      SimpleMap(instance),
      FullMap(instance) {}

  virtual ~mapImpl() {}

  virtual proxy::fields::SimpleMapField& GetSimpleMap() override { return SimpleMap; }
  virtual proxy::fields::FullMapField& GetFullMap() override { return FullMap; }

 private:
  ara::com::internal::vsomeip::proxy::FieldImpl<descriptors::SimpleMap, ::ara::diag::datatypes::MetaInfoTypeInt> SimpleMap;
  ara::com::internal::vsomeip::proxy::FieldImpl<descriptors::FullMap, ::ara::diag::datatypes::MetaInfoType> FullMap;
};

} // namespace vsomeip
} // namespace map_binding
} // namespace gen
} // namespace ara

#endif // map_sample_v45_vsomeip_ara_gen_proxy_vsomeip_map_h

