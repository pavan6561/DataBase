// --------------------------------------------------------------------------
// |              _    _ _______     .----.      _____         _____        |
// |         /\  | |  | |__   __|  .  ____ .    / ____|  /\   |  __ \       |
// |        /  \ | |  | |  | |    .  / __ \ .  | (___   /  \  | |__) |      |
// |       / /\ \| |  | |  | |   .  / / / / v   \___ \ / /\ \ |  _  /       |
// |      / /__\ \ |__| |  | |   . / /_/ /  .   ____) / /__\ \| | \ \       |
// |     /________\____/   |_|   ^ \____/  .   |_____/________\_|  \_\      |
// |                              . _ _  .                                  |
// --------------------------------------------------------------------------
//
// All Rights Reserved.
// Any use of this source code is subject to a license agreement with the
// AUTOSAR development cooperation.
// More information is available at www.autosar.org.
//
// Disclaimer
//
// This work (specification and/or software implementation) and the material
// contained in it, as released by AUTOSAR, is for the purpose of information
// only. AUTOSAR and the companies that have contributed to it shall not be
// liable for any use of the work.
//
// The material contained in this work is protected by copyright and other
// types of intellectual property rights. The commercial exploitation of the
// material contained in this work requires a license to such intellectual
// property rights.
//
// This work may be utilized or reproduced without any modification, in any
// form or by any means, for informational purposes only. For any other
// purpose, no part of the work may be utilized or reproduced, in any form
// or by any means, without permission in writing from the publisher.
//
// The work has been developed for automotive applications only. It has
// neither been developed, nor tested for non-automotive applications.
//
// The word AUTOSAR and the AUTOSAR logo are registered trademarks.
// --------------------------------------------------------------------------

#ifndef adt_sample_vsomeip_ara_gen_adapter_events_h
#define adt_sample_vsomeip_ara_gen_adapter_events_h

#include "ara/com/internal/vsomeip/skeleton/vsomeip_skeleton_base.h"
#include "service_desc_events.h"
#include "ara/gen/events_skeleton.h"

namespace ara {
namespace gen {
namespace events_binding {
namespace vsomeip {

class eventsServiceAdapter : public ::ara::com::internal::vsomeip::skeleton::ServiceImplBase {
 public:
  using ServiceInterface = skeleton::eventsSkeleton;
  using ServiceDescriptor = descriptors::internal::Service;

  eventsServiceAdapter(ServiceInterface& service, ara::com::internal::InstanceId instance) :
    ::ara::com::internal::vsomeip::skeleton::ServiceImplBase(service, instance),
    Array(instance),
    Vector(instance),
    ArrayOfStruct(instance),
    StructOfArray(instance),
    Structure(instance),
    TypeRef(instance) {
    Connect(service);
    OfferService(ServiceDescriptor::service_id, GetInstanceId(), ServiceDescriptor::service_version, ServiceDescriptor::minor_service_version);
    OfferEvent(ServiceDescriptor::service_id, GetInstanceId(), descriptors::Array::event_id, descriptors::Array::event_groups);
    OfferEvent(ServiceDescriptor::service_id, GetInstanceId(), descriptors::Vector::event_id, descriptors::Vector::event_groups);
    OfferEvent(ServiceDescriptor::service_id, GetInstanceId(), descriptors::ArrayOfStruct::event_id, descriptors::ArrayOfStruct::event_groups);
    OfferEvent(ServiceDescriptor::service_id, GetInstanceId(), descriptors::StructOfArray::event_id, descriptors::StructOfArray::event_groups);
    OfferEvent(ServiceDescriptor::service_id, GetInstanceId(), descriptors::Structure::event_id, descriptors::Structure::event_groups);
    OfferEvent(ServiceDescriptor::service_id, GetInstanceId(), descriptors::TypeRef::event_id, descriptors::TypeRef::event_groups);
  }

  virtual ~eventsServiceAdapter() {
    StopOfferEvent(descriptors::Array::service_id, GetInstanceId(), descriptors::Array::event_id);
    StopOfferEvent(descriptors::Vector::service_id, GetInstanceId(), descriptors::Vector::event_id);
    StopOfferEvent(descriptors::ArrayOfStruct::service_id, GetInstanceId(), descriptors::ArrayOfStruct::event_id);
    StopOfferEvent(descriptors::StructOfArray::service_id, GetInstanceId(), descriptors::StructOfArray::event_id);
    StopOfferEvent(descriptors::Structure::service_id, GetInstanceId(), descriptors::Structure::event_id);
    StopOfferEvent(descriptors::TypeRef::service_id, GetInstanceId(), descriptors::TypeRef::event_id);
    StopOfferService(ServiceDescriptor::service_id, GetInstanceId());
    Disconnect(dynamic_cast<ServiceInterface&>(service_));
  }

 private:
  void Connect(ServiceInterface& service) {
    service.AddDelegate(*this);
    service.Array.AddDelegate(Array);
    service.Vector.AddDelegate(Vector);
    service.ArrayOfStruct.AddDelegate(ArrayOfStruct);
    service.StructOfArray.AddDelegate(StructOfArray);
    service.Structure.AddDelegate(Structure);
    service.TypeRef.AddDelegate(TypeRef);
  }

  void Disconnect(ServiceInterface& service) {
    service.RemoveDelegate(*this);
    service.Array.RemoveDelegate(Array);
    service.Vector.RemoveDelegate(Vector);
    service.ArrayOfStruct.RemoveDelegate(ArrayOfStruct);
    service.StructOfArray.RemoveDelegate(StructOfArray);
    service.Structure.RemoveDelegate(Structure);
    service.TypeRef.RemoveDelegate(TypeRef);
  }

  ara::com::internal::vsomeip::skeleton::EventImpl<::ArrayCppIdt, descriptors::Array> Array;
  ara::com::internal::vsomeip::skeleton::EventImpl<::VectorCppIdt, descriptors::Vector> Vector;
  ara::com::internal::vsomeip::skeleton::EventImpl<::ComplexCppIdt_ArrayOfStruct, descriptors::ArrayOfStruct> ArrayOfStruct;
  ara::com::internal::vsomeip::skeleton::EventImpl<::ComplexCppIdt_StructOfArray, descriptors::StructOfArray> StructOfArray;
  ara::com::internal::vsomeip::skeleton::EventImpl<::StructureCppIdt, descriptors::Structure> Structure;
  ara::com::internal::vsomeip::skeleton::EventImpl<::TypeRefCppIdt, descriptors::TypeRef> TypeRef;
};

} // namespace vsomeip
} // namespace events_binding
} // namespace gen
} // namespace ara

#endif // adt_sample_vsomeip_ara_gen_adapter_events_h

