#  --------------------------------------------------------------------------
#  |              _    _ _______     .----.      _____         _____        |
#  |         /\  | |  | |__   __|  .  ____ .    / ____|  /\   |  __ \       |
#  |        /  \ | |  | |  | |    .  / __ \ .  | (___   /  \  | |__) |      |
#  |       / /\ \| |  | |  | |   .  / / / / v   \___ \ / /\ \ |  _  /       |
#  |      / /__\ \ |__| |  | |   . / /_/ /  .   ____) / /__\ \| | \ \       |
#  |     /________\____/   |_|   ^ \____/  .   |_____/________\_|  \_\      |
#  |                              . _ _  .                                  |
#  --------------------------------------------------------------------------
#
#  All Rights Reserved.
#  Any use of this source code is subject to a license agreement with the
#  AUTOSAR development cooperation.
#  More information is available at www.autosar.org.
#
#  Disclaimer
#
#  This work (specification and/or software implementation) and the material
#  contained in it, as released by AUTOSAR, is for the purpose of information
#  only. AUTOSAR and the companies that have contributed to it shall not be
#  liable for any use of the work.
#
#  The material contained in this work is protected by copyright and other
#  types of intellectual property rights. The commercial exploitation of the
#  material contained in this work requires a license to such intellectual
#  property rights.
#
#  This work may be utilized or reproduced without any modification, in any
#  form or by any means, for informational purposes only. For any other
#  purpose, no part of the work may be utilized or reproduced, in any form
#  or by any means, without permission in writing from the publisher.
#
#  The work has been developed for automotive applications only. It has
#  neither been developed, nor tested for non-automotive applications.
#
#  The word AUTOSAR and the AUTOSAR logo are registered trademarks.
#  --------------------------------------------------------------------------

"""
Network binding class.
"""

# pylint: disable=too-many-lines,too-many-public-methods
import logging
from generator.parser.network_binding_builder import NetworkBindingBuilder as DefaultNetworkBindingBuilder
from generator.parser.v47.someip_svc_deployment_builder import SomeIpServiceDeploymentBuilder


class NetworkBindingBuilder(DefaultNetworkBindingBuilder):
    """
    Handles parsing the ARXML part, related to network binding, and provides service deployment objects.
    """

    def __init__(self, model):
        super().__init__(model)
        self._log = logging.getLogger(__name__)
        self.someip_svc_deployment = SomeIpServiceDeploymentBuilder(model)

    def _get_si_to_machine_mappings(self, ar_si_fqn):
        si_to_machine_mappings = self.model.find_elements_of_type(
            'SOMEIP-SERVICE-INSTANCE-TO-MACHINE-MAPPING',
            accept=lambda e: str(
                e.SERVICE_INSTANCE_REFS.SERVICE_INSTANCE_REF) == ar_si_fqn)
        if not si_to_machine_mappings:
            si_to_machine_mappings = self.model.find_elements_of_type(
                'DDS-SERVICE-INSTANCE-TO-MACHINE-MAPPING',
                accept=lambda e: str(
                    e.SERVICE_INSTANCE_REFS.SERVICE_INSTANCE_REF) == ar_si_fqn)
        if not si_to_machine_mappings:
            si_to_machine_mappings = self.model.find_elements_of_type(
                'USER-DEFINED-SERVICE-INSTANCE-TO-MACHINE-MAPPING',
                accept=lambda e: str(
                    e.SERVICE_INSTANCE_REFS.SERVICE_INSTANCE_REF) == ar_si_fqn)
        assert len(si_to_machine_mappings) == 1, \
            "Need exactly one " + \
            "SERVICE-INSTANCE-TO-MACHINE-MAPPING " + \
            "for SERVICE-INSTANCE: " + \
            ar_si_fqn()
        return si_to_machine_mappings[0]
