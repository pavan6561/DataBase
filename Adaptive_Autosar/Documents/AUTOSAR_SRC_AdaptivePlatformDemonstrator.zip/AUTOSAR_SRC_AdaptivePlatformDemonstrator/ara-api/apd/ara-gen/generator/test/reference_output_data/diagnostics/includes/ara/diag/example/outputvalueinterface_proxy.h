// --------------------------------------------------------------------------
// |              _    _ _______     .----.      _____         _____        |
// |         /\  | |  | |__   __|  .  ____ .    / ____|  /\   |  __ \       |
// |        /  \ | |  | |  | |    .  / __ \ .  | (___   /  \  | |__) |      |
// |       / /\ \| |  | |  | |   .  / / / / v   \___ \ / /\ \ |  _  /       |
// |      / /__\ \ |__| |  | |   . / /_/ /  .   ____) / /__\ \| | \ \       |
// |     /________\____/   |_|   ^ \____/  .   |_____/________\_|  \_\      |
// |                              . _ _  .                                  |
// --------------------------------------------------------------------------
//
// All Rights Reserved.
// Any use of this source code is subject to a license agreement with the
// AUTOSAR development cooperation.
// More information is available at www.autosar.org.
//
// Disclaimer
//
// This work (specification and/or software implementation) and the material
// contained in it, as released by AUTOSAR, is for the purpose of information
// only. AUTOSAR and the companies that have contributed to it shall not be
// liable for any use of the work.
//
// The material contained in this work is protected by copyright and other
// types of intellectual property rights. The commercial exploitation of the
// material contained in this work requires a license to such intellectual
// property rights.
//
// This work may be utilized or reproduced without any modification, in any
// form or by any means, for informational purposes only. For any other
// purpose, no part of the work may be utilized or reproduced, in any form
// or by any means, without permission in writing from the publisher.
//
// The work has been developed for automotive applications only. It has
// neither been developed, nor tested for non-automotive applications.
//
// The word AUTOSAR and the AUTOSAR logo are registered trademarks.
// --------------------------------------------------------------------------

#ifndef diagnostics_includes_ara_diag_example_outputvalueinterface_proxy_h
#define diagnostics_includes_ara_diag_example_outputvalueinterface_proxy_h

#include "ara/com/internal/proxy/ara_proxy_base.h"
#include "outputvalueinterface_common.h"

namespace ara {
namespace diag {
namespace example {
namespace proxy {


namespace fields {
using OutputValueField = ara::com::internal::proxy::Field<std::int32_t>;
template <typename T, bool E2E = ara::com::internal::e2e::is_e2e_enabled<T>::value>
class OutputValueProxy {
private:
  OutputValueField& field;

public:
  explicit OutputValueProxy(OutputValueField& field_base)
      : field(field_base)
  { }

  // Event Base.
  void Subscribe(ara::com::EventCacheUpdatePolicy policy, std::size_t cacheSize) {
    field.Subscribe(policy, cacheSize);
  }
  
  bool IsSubscribed() const {
    return field.IsSubscribed();
  }

  void Unsubscribe() {
    return field.Unsubscribe();
  }

  void Cleanup() {
    field.Cleanup();
  }

  void SetReceiveHandler(ara::com::EventReceiveHandler handler) {
    field.SetReceiveHandler(handler);
  }

  void UnsetReceiveHandler() {
    field.UnsetReceiveHandler();
  }

  void SetSubscriptionStateChangeHandler(ara::com::SubscriptionStateChangeHandler handler) {
    field.SetSubscriptionStateChangeHandler(handler);
  }

  void UnsetSubscriptionStateChangeHandler() {
    field.UnsetSubscriptionStateChangeHandler();
  }

  using container_type = OutputValueField::container_type;

  // Event.
  bool Update() {
    return field.Update();
  }

  bool Update(ara::com::FilterFunction<T> filter) {
    return field.Update(filter);
  }

  const container_type &GetCachedSamples() const {
    return field.GetCachedSamples();
  }

  template <typename U=T, typename = std::enable_if_t<E2E, U>>
  ara::com::e2exf::E2EResult GetE2EResult() const noexcept {
    return field.GetE2EResult();
  }

  /// @brief Field.
  /// @uptrace{SWS_CM_00132}
  ara::core::Future<std::int32_t> Get() {
    return field.Get();
  }

};
/// @uptrace{SWS_CM_00008}
using OutputValue = OutputValueProxy<std::int32_t>;
} // namespace fields


class OutputValueInterfaceProxyBase : public ara::com::internal::proxy::ProxyBindingBase, public ara::diag::example::OutputValueInterface {
public:
  virtual fields::OutputValueField& GetOutputValue() = 0;
};

/// @uptrace{SWS_CM_00004}
class OutputValueInterfaceProxy : public ara::com::internal::proxy::ProxyBase<OutputValueInterfaceProxyBase>, public ara::diag::example::OutputValueInterface {
private:
  fields::OutputValueField& OutputValueField;

public:
  /// @brief Proxy constructor.
  ///
  /// @uptrace{SWS_CM_00131}
  explicit OutputValueInterfaceProxy(const HandleType& proxy_base_factory)
      : ara::com::internal::proxy::ProxyBase<OutputValueInterfaceProxyBase>(proxy_base_factory)
      , OutputValueField(proxy_base_->GetOutputValue())
      , OutputValue(OutputValueField)
  {}

  /// @brief Proxy shall be move constructable.
  ///
  /// @uptrace{SWS_CM_00137}
  explicit OutputValueInterfaceProxy(OutputValueInterfaceProxy&&) = default;

  /// @brief Proxy shall be move assignable.
  ///
  /// @uptrace{SWS_CM_00137}
  OutputValueInterfaceProxy& operator=(OutputValueInterfaceProxy&&) = default;

  /// @brief Proxy shall not be copy constructable.
  ///
  /// @uptrace{SWS_CM_00136}
  explicit OutputValueInterfaceProxy(const OutputValueInterfaceProxy&) = delete;

  /// @brief Proxy shall not be copy assignable.
  ///
  /// @uptrace{SWS_CM_00136}
  OutputValueInterfaceProxy& operator=(const OutputValueInterfaceProxy&) = delete;

  fields::OutputValue OutputValue;
};

} // namespace proxy
} // namespace example
} // namespace diag
} // namespace ara

#endif // diagnostics_includes_ara_diag_example_outputvalueinterface_proxy_h

