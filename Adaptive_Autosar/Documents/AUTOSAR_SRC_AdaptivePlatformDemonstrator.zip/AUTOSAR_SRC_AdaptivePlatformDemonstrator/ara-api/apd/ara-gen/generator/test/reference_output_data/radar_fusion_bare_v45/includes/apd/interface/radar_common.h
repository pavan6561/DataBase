// --------------------------------------------------------------------------
// |              _    _ _______     .----.      _____         _____        |
// |         /\  | |  | |__   __|  .  ____ .    / ____|  /\   |  __ \       |
// |        /  \ | |  | |  | |    .  / __ \ .  | (___   /  \  | |__) |      |
// |       / /\ \| |  | |  | |   .  / / / / v   \___ \ / /\ \ |  _  /       |
// |      / /__\ \ |__| |  | |   . / /_/ /  .   ____) / /__\ \| | \ \       |
// |     /________\____/   |_|   ^ \____/  .   |_____/________\_|  \_\      |
// |                              . _ _  .                                  |
// --------------------------------------------------------------------------
//
// All Rights Reserved.
// Any use of this source code is subject to a license agreement with the
// AUTOSAR development cooperation.
// More information is available at www.autosar.org.
//
// Disclaimer
//
// This work (specification and/or software implementation) and the material
// contained in it, as released by AUTOSAR, is for the purpose of information
// only. AUTOSAR and the companies that have contributed to it shall not be
// liable for any use of the work.
//
// The material contained in this work is protected by copyright and other
// types of intellectual property rights. The commercial exploitation of the
// material contained in this work requires a license to such intellectual
// property rights.
//
// This work may be utilized or reproduced without any modification, in any
// form or by any means, for informational purposes only. For any other
// purpose, no part of the work may be utilized or reproduced, in any form
// or by any means, without permission in writing from the publisher.
//
// The work has been developed for automotive applications only. It has
// neither been developed, nor tested for non-automotive applications.
//
// The word AUTOSAR and the AUTOSAR logo are registered trademarks.
// --------------------------------------------------------------------------

#ifndef radar_fusion_bare_v45_includes_apd_interface_radar_common_h
#define radar_fusion_bare_v45_includes_apd_interface_radar_common_h

#include <string.h>
#include "ara/core/array.h"

#include "ara/com/types.h"

#include "ara/com/exception.h"
#include "ara/core/error_code.h"
#include "impl_type_boolean.h"
#include "impl_type_fusionvariant.h"
#include "impl_type_position.h"
#include "impl_type_radarobjects.h"
#include "impl_type_string.h"
#include "impl_type_uint16.h"
#include "impl_type_uint32.h"
namespace apd {
namespace interface {

class radar {
 public:
  static constexpr ara::com::internal::ServiceId service_id = 0x5bb2;
  static constexpr ara::com::internal::ServiceVersion service_version = 0x01000000;
  static constexpr ara::core::Array<ara::core::ErrorCode, 0> Adjust_PossibleErrors =
  {
  };

  struct AdjustOutput {
    ::Boolean success;
    ::Position effective_position;

    using IsEnumerableTag = void;
    template<typename F>
    void enumerate(F& fun) {
      fun(success);
      fun(effective_position);
    }
  };
  static constexpr ara::core::Array<ara::core::ErrorCode, 0> Calibrate_PossibleErrors =
  {
  };

  struct CalibrateOutput {
    ::Boolean result;

    using IsEnumerableTag = void;
    template<typename F>
    void enumerate(F& fun) {
      fun(result);
    }
  };
};


class GeneralFailure : public ara::com::ApplicationErrorException {
public:
    GeneralFailure() :
        ara::com::ApplicationErrorException()
        {}


  const char *what() const noexcept final override { return errorMessage_; }

    using IsEnumerableTag = void;
    template<typename F>
    void enumerate(F& fun) {
        fun(errorCode_);
    }
    template<typename F>
    void enumerate(F& fun) const {
        fun(errorCode_);
    }

private:
    std::uint8_t errorCode_ = 12 & 0x3F;
    static constexpr const char* errorMessage_ = "GeneralFailure in radar with ErrorCode: 12 & 0x3F";
};


class InvalidConfigString : public ara::com::ApplicationErrorException {
public:
    InvalidConfigString() :
        ara::com::ApplicationErrorException()
        {}

    InvalidConfigString(::String Calibrate_currentValidConfig,::String Calibrate_invalidConfig) : 
        ara::com::ApplicationErrorException(),
        Calibrate_currentValidConfig_(std::move(Calibrate_currentValidConfig)),
        Calibrate_invalidConfig_(std::move(Calibrate_invalidConfig))
        {}

    const ::String& get_Calibrate_currentValidConfig() const { return Calibrate_currentValidConfig_; }
    const ::String& get_Calibrate_invalidConfig() const { return Calibrate_invalidConfig_; }

  const char *what() const noexcept final override { return errorMessage_; }

    using IsEnumerableTag = void;
    template<typename F>
    void enumerate(F& fun) {
        fun(errorCode_);
        fun(Calibrate_currentValidConfig_);
        fun(Calibrate_invalidConfig_);
    }
    template<typename F>
    void enumerate(F& fun) const {
        fun(errorCode_);
        fun(Calibrate_currentValidConfig_);
        fun(Calibrate_invalidConfig_);
    }

private:
    std::uint8_t errorCode_ = 5 & 0x3F;
    static constexpr const char* errorMessage_ = "InvalidConfigString in radar with ErrorCode: 5 & 0x3F";
    ::String Calibrate_currentValidConfig_;
    ::String Calibrate_invalidConfig_;
};

} // namespace interface
} // namespace apd

#endif // radar_fusion_bare_v45_includes_apd_interface_radar_common_h

