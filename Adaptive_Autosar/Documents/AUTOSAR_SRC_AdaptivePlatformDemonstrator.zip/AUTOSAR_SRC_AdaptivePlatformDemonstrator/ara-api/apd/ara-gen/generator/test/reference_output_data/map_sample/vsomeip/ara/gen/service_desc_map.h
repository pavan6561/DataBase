// --------------------------------------------------------------------------
// |              _    _ _______     .----.      _____         _____        |
// |         /\  | |  | |__   __|  .  ____ .    / ____|  /\   |  __ \       |
// |        /  \ | |  | |  | |    .  / __ \ .  | (___   /  \  | |__) |      |
// |       / /\ \| |  | |  | |   .  / / / / v   \___ \ / /\ \ |  _  /       |
// |      / /__\ \ |__| |  | |   . / /_/ /  .   ____) / /__\ \| | \ \       |
// |     /________\____/   |_|   ^ \____/  .   |_____/________\_|  \_\      |
// |                              . _ _  .                                  |
// --------------------------------------------------------------------------
//
// All Rights Reserved.
// Any use of this source code is subject to a license agreement with the
// AUTOSAR development cooperation.
// More information is available at www.autosar.org.
//
// Disclaimer
//
// This work (specification and/or software implementation) and the material
// contained in it, as released by AUTOSAR, is for the purpose of information
// only. AUTOSAR and the companies that have contributed to it shall not be
// liable for any use of the work.
//
// The material contained in this work is protected by copyright and other
// types of intellectual property rights. The commercial exploitation of the
// material contained in this work requires a license to such intellectual
// property rights.
//
// This work may be utilized or reproduced without any modification, in any
// form or by any means, for informational purposes only. For any other
// purpose, no part of the work may be utilized or reproduced, in any form
// or by any means, without permission in writing from the publisher.
//
// The work has been developed for automotive applications only. It has
// neither been developed, nor tested for non-automotive applications.
//
// The word AUTOSAR and the AUTOSAR logo are registered trademarks.
// --------------------------------------------------------------------------

#ifndef map_sample_vsomeip_ara_gen_service_desc_map_h
#define map_sample_vsomeip_ara_gen_service_desc_map_h

#include "ara/gen/map_common.h"

#include "ara/com/internal/vsomeip/vsomeip_types.h"

namespace ara {
namespace gen {
namespace map_binding {
namespace vsomeip {
namespace descriptors {


namespace internal {
    struct Service {
        static constexpr ara::com::internal::vsomeip::types::ServiceId service_id = 0x63;
        static constexpr ara::com::internal::vsomeip::types::ServiceVersionMajor service_version = 0x1;
        static constexpr ara::com::internal::vsomeip::types::ServiceVersionMinor minor_service_version = 0x0;
    };
}

struct SimpleMap : public internal::Service {
    static constexpr ara::com::internal::vsomeip::types::EventId event_id = ara::com::internal::vsomeip::types::UndefinedEventId;
    static constexpr ara::com::internal::vsomeip::types::MethodId get_method_id = 0xbbe;
    static constexpr bool is_getter_reliable = true;
    static constexpr ara::com::internal::vsomeip::types::EventGroupId event_groups[] { 0x0 };
};
struct FullMap : public internal::Service {
    static constexpr ara::com::internal::vsomeip::types::EventId event_id = ara::com::internal::vsomeip::types::UndefinedEventId;
    static constexpr ara::com::internal::vsomeip::types::MethodId get_method_id = 0xbc1;
    static constexpr bool is_getter_reliable = true;
    static constexpr ara::com::internal::vsomeip::types::EventGroupId event_groups[] { 0x0 };
};
} // namespace descriptors
} // namespace vsomeip
} // namespace map_binding
} // namespace gen
} // namespace ara

#endif // map_sample_vsomeip_ara_gen_service_desc_map_h

