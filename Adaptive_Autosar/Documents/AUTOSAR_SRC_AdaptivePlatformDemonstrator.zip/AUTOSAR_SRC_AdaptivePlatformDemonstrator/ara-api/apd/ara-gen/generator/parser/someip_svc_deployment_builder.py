#  --------------------------------------------------------------------------
#  |              _    _ _______     .----.      _____         _____        |
#  |         /\  | |  | |__   __|  .  ____ .    / ____|  /\   |  __ \       |
#  |        /  \ | |  | |  | |    .  / __ \ .  | (___   /  \  | |__) |      |
#  |       / /\ \| |  | |  | |   .  / / / / v   \___ \ / /\ \ |  _  /       |
#  |      / /__\ \ |__| |  | |   . / /_/ /  .   ____) / /__\ \| | \ \       |
#  |     /________\____/   |_|   ^ \____/  .   |_____/________\_|  \_\      |
#  |                              . _ _  .                                  |
#  --------------------------------------------------------------------------
#
#  All Rights Reserved.
#  Any use of this source code is subject to a license agreement with the
#  AUTOSAR development cooperation.
#  More information is available at www.autosar.org.
#
#  Disclaimer
#
#  This work (specification and/or software implementation) and the material
#  contained in it, as released by AUTOSAR, is for the purpose of information
#  only. AUTOSAR and the companies that have contributed to it shall not be
#  liable for any use of the work.
#
#  The material contained in this work is protected by copyright and other
#  types of intellectual property rights. The commercial exploitation of the
#  material contained in this work requires a license to such intellectual
#  property rights.
#
#  This work may be utilized or reproduced without any modification, in any
#  form or by any means, for informational purposes only. For any other
#  purpose, no part of the work may be utilized or reproduced, in any form
#  or by any means, without permission in writing from the publisher.
#
#  The work has been developed for automotive applications only. It has
#  neither been developed, nor tested for non-automotive applications.
#
#  The word AUTOSAR and the AUTOSAR logo are registered trademarks.
#  --------------------------------------------------------------------------

"""
SOMEIP service deployment builder class.
"""

# pylint: disable=too-many-lines,too-many-public-methods
import collections
from generator.intermediate_model.communication_management.ara_com_deployment.someip.event_deployment \
    import EventDeployment
from generator.intermediate_model.communication_management.ara_com_deployment.someip.method_deployment \
    import MethodDeployment
from generator.intermediate_model.communication_management.ara_com_deployment.someip.field_deployment \
    import FieldDeployment
from generator.intermediate_model.communication_management.ara_com_deployment.someip.event_group_deployment \
    import EventGroupDeployment
from generator.parser.tree_helper import short_name, get_element_or_die, get_element_or_none, to_milliseconds
from generator.parser.interface_builder import _GET, _SET, _NOTIFIER, _EVENT_REF

_SOMEIP_EVENT = "SOMEIP-EVENT-DEPLOYMENT"
_SOMEIP_EVENT_GROUP = "SOMEIP-EVENT-GROUP"
_SOMEIP_FIELD = "SOMEIP-FIELD-DEPLOYMENT"
_SOMEIP_METHOD = "SOMEIP-METHOD-DEPLOYMENT"

_TCP = "TCP-PORT"
_UDP = "UDP-PORT"


class SomeIpServiceDeploymentBuilder():
    """
    Handles parsing the ARXML part, related to someip network binding.
    """

    def __init__(self, model):
        self.model = model

    @staticmethod
    def _get_event_deployment(ar_event_depl):
        """
        Extract someip event deployment information, will be returned as
        a dict with information
        """
        return dict(
            name=ar_event_depl.get_fqn(),
            id=get_element_or_die(ar_event_depl, "EVENT-ID"),
            proto=get_element_or_die(ar_event_depl, "TRANSPORT-PROTOCOL")
        )

    @staticmethod
    def _get_field_deployment(ar_field_depl):
        """
        Extract someip field deployment information, will be returned as
        a dict with information
        """
        result = dict(getter={}, setter={}, notifier={})
        getter = getattr(ar_field_depl, _GET, None)
        if getter is not None:
            result['getter'] = dict(
                name=get_element_or_die(getter, "SHORT-NAME"),
                id=get_element_or_die(getter, "METHOD-ID"),
                proto=get_element_or_die(getter, "TRANSPORT-PROTOCOL")
            )
        setter = getattr(ar_field_depl, _SET, None)
        if setter is not None:
            result['setter'] = dict(
                name=get_element_or_die(setter, "SHORT-NAME"),
                id=get_element_or_die(setter, "METHOD-ID"),
                proto=get_element_or_die(setter, "TRANSPORT-PROTOCOL")
            )

        notifier = getattr(ar_field_depl, _NOTIFIER, None)
        if notifier is not None:
            result['notifier'] = dict(
                name=notifier.get_fqn(),
                id=get_element_or_die(notifier, "EVENT-ID"),
                proto=get_element_or_die(notifier, "TRANSPORT-PROTOCOL")
            )
        return result

    @staticmethod
    def _get_method_deployment(ar_method_depl):
        """
        Extract someip method deployment information, will be returned as
        a dict with information
        """
        result = dict(
            name=get_element_or_die(ar_method_depl, "SHORT-NAME"),
            id=get_element_or_die(ar_method_depl, "METHOD-ID"),
            proto=get_element_or_die(ar_method_depl, "TRANSPORT-PROTOCOL")
        )
        return result

    @staticmethod
    def _get_eventgrps_deployment(ar_event_groups, events_deployment, fields_deployment):
        """
        Extract someip event group deployment information, will be returned
        as a dict with information
        """
        event_group_depls = ar_event_groups.find_elements_of_type(
            _SOMEIP_EVENT_GROUP)
        inner = collections.OrderedDict()
        result = dict(event_groups=inner)
        for event_group in event_group_depls:
            fqn = event_group.get_fqn()
            result['event_groups'][fqn] = dict(
                id=event_group.EVENT_GROUP_ID, events=[])
            event_refs = event_group.find_elements_of_type(
                _EVENT_REF, DEST=_SOMEIP_EVENT)
            for event_ref in event_refs:
                for _, depl in events_deployment.items():
                    if depl['name'] == event_ref:
                        result['event_groups'][fqn]['events'].append(
                            depl['id'])
                        break
                for _, depl in fields_deployment.items():
                    if depl:
                        notifier_depl = depl['notifier']
                        if (notifier_depl and
                                notifier_depl['name'] == event_ref):
                            result['event_groups'][fqn]['events'].append(
                                notifier_depl['id'])
                            break
        return result

    def get_instance_deployment(self, ar_si):
        """
        Extract someip deployment information, will be returned as a
        dict with information
        """
        result = dict(service_id=get_element_or_die(ar_si, "SERVICE-INTERFACE-ID"),
                      events={}, methods={}, fields={}, event_groups={})
        event_group_depls = dict(event_groups={})

        if hasattr(ar_si, 'EVENT_DEPLOYMENTS'):
            event_depls = ar_si.EVENT_DEPLOYMENTS.find_elements_of_type(
                _SOMEIP_EVENT)
            for event_depl in event_depls:
                result['events'][event_depl.EVENT_REF] = \
                    self._get_event_deployment(event_depl)

        if hasattr(ar_si, 'FIELD_DEPLOYMENTS'):
            field_depls = ar_si.FIELD_DEPLOYMENTS.find_elements_of_type(
                _SOMEIP_FIELD)
            for field_depl in field_depls:
                result['fields'][field_depl.FIELD_REF] = \
                    self._get_field_deployment(field_depl)

        if hasattr(ar_si, 'METHOD_DEPLOYMENTS'):
            method_depls = ar_si.METHOD_DEPLOYMENTS.find_elements_of_type(
                _SOMEIP_METHOD)
            for method_depl in method_depls:
                result['methods'][method_depl.METHOD_REF] = \
                    self._get_method_deployment(method_depl)

        if hasattr(ar_si, 'EVENT_GROUPS'):
            event_group_depls = self._get_eventgrps_deployment(
                get_element_or_die(ar_si, "EVENT-GROUPS"),
                result['events'], result['fields'])
        result = {**result, **event_group_depls}
        return result

    def get_provided_si_deployment(self, provided_si):
        """
        Extract provided someip deployment information, will be returned as a
        dict with information
        """

        sd_config = get_element_or_none(provided_si, "SD-SERVER-CONFIG")
        initial_offer = get_element_or_none(sd_config, "INITIAL-OFFER-BEHAVIOR")
        initial_delay_max = get_element_or_none(initial_offer, "INITIAL-DELAY-MAX-VALUE")
        initial_delay_min = get_element_or_none(initial_offer, "INITIAL-DELAY-MIN-VALUE")
        base_delay = get_element_or_none(initial_offer, "INITIAL-REPETITIONS-BASE-DELAY")
        initial_repetitions_max = get_element_or_none(initial_offer, "INITIAL-REPETITIONS-MAX")
        offer_cyclic_delay = get_element_or_none(sd_config, "OFFER-CYCLIC-DELAY")
        service_offer_time_to_live = get_element_or_none(sd_config, "SERVICE-OFFER-TIME-TO-LIVE")
        request_response_delay_max = get_element_or_none(sd_config, "REQUEST-RESPONSE-DELAY/MAX-VALUE")
        request_response_delay_min = get_element_or_none(sd_config, "REQUEST-RESPONSE-DELAY/MIN_VALUE")
        instance_id = get_element_or_none(provided_si, "SERVICE-INSTANCE-ID")

        result = {
            "sd_config": {
                "initial_delay_max": to_milliseconds(initial_delay_max),
                "initial_delay_min": to_milliseconds(initial_delay_min),
                "initial_repetitions_base_delay": to_milliseconds(base_delay),
                "initial_repetitions_max": initial_repetitions_max,
                "cyclic_delay": to_milliseconds(offer_cyclic_delay),
                "ttl": service_offer_time_to_live,
                "request_response_delay_max": to_milliseconds(request_response_delay_max),
                "request_response_delay_min": to_milliseconds(request_response_delay_min)
            },
            "instance_id": instance_id
        }

        return result

    def get_required_si_deployment(self, required_si):
        """
        Extract required someip deployment information, will be returned as a
        dict with information
        """
        sd_config = get_element_or_none(required_si, "SD-CLIENT-CONFIG")
        service_find_time_to_live = get_element_or_none(sd_config, "SERVICE-FIND-TIME-TO-LIVE")
        initial_offer = get_element_or_none(sd_config, "INITIAL-FIND-BEHAVIOR")
        base_delay = get_element_or_none(initial_offer, "INITIAL-REPETITIONS-BASE-DELAY")
        initial_delay_max = get_element_or_none(initial_offer, "INITIAL-DELAY-MAX-VALUE")
        initial_delay_min = get_element_or_none(initial_offer, "INITIAL-DELAY-MIN-VALUE")
        initial_repetitions_max = get_element_or_none(initial_offer, "INITIAL-REPETITIONS-MAX")
        instance_id = get_element_or_none(required_si, "REQUIRED-SERVICE-INSTANCE-ID")

        result = {
            "sd_config": {
                "initial_delay_max": to_milliseconds(initial_delay_max),
                "initial_delay_min": to_milliseconds(initial_delay_min),
                "initial_repetitions_base_delay": to_milliseconds(base_delay),
                "initial_repetitions_max": initial_repetitions_max,
                "ttl": service_find_time_to_live
            },
            "instance_id": instance_id
        }

        return result

    def get_net_ports_config(self, ar_instance_mapping):
        """
        Get network port config information, will be returned as a dict
        with information
        """
        ports_config = dict()
        ar_tcp_port = getattr(ar_instance_mapping, _TCP, None)
        ar_udp_port = getattr(ar_instance_mapping, _UDP, None)
        if ar_tcp_port is not None:
            ports_config['tcp'] = ar_tcp_port
        if ar_udp_port is not None:
            ports_config['udp'] = ar_udp_port
        return ports_config

    def _populate_eventgrp_deployment(self, service_deployment, event_group_depls):
        """Populate an event group deployment"""
        for event_group_depl_dict in event_group_depls.values():
            event_group_id = int(event_group_depl_dict["id"])
            event_group_deployment = EventGroupDeployment(event_group_id)
            service_deployment.add_event_group_deployment(
                event_group_deployment)
            for event in event_group_depl_dict["events"]:
                event_group_deployment.add_event(int(event))

    def _populate_event_deployment(self, events, event_deployment):
        """Populate an event deployment"""
        for event_fqn, event_depl in event_deployment.items():
            event_name = short_name(event_fqn)
            for event in events:
                if event.name == event_name:
                    event.event_deployment = EventDeployment()
                    event.event_deployment.deployment_id = int(
                        event_depl['id'])
                    event.event_deployment.proto = event_depl['proto']

    def _populate_method_deployment(self, methods, method_deployment):
        """Populate a method deployment"""
        for method_fqn, method_depl in method_deployment.items():
            method_name = short_name(method_fqn)
            for method in methods:
                if method.name == method_name:
                    method.deployment = MethodDeployment()
                    method.deployment.deployment_id = method_depl['id']
                    method.deployment.proto = method_depl['proto']

    def _populate_field_deployment(self, fields, field_deployment):
        """Populate a field deployment"""
        for field_fqn, field_depl in field_deployment.items():
            field_name = short_name(field_fqn)
            if 'getter' in field_depl:
                field_getter = field_depl['getter']
            if 'setter' in field_depl:
                field_setter = field_depl['setter']
            if 'notifier' in field_depl:
                field_notifier = field_depl['notifier']
            for field in fields:
                if field.name == field_name:
                    field.deployment = FieldDeployment()
                    field.deployment['getter'] = field_getter
                    field.deployment['setter'] = field_setter
                    field.deployment['notifier'] = field_notifier

    def populate_deployment(self, service, deployment):
        """Populate a service deployment"""
        if deployment.required:
            self._populate_event_deployment(
                service.events, deployment.required['events'])
            self._populate_method_deployment(
                service.methods, deployment.required['methods'])
            self._populate_field_deployment(
                service.fields, deployment.required['fields'])
            self._populate_eventgrp_deployment(
                deployment,
                deployment.required["event_groups"])
        elif deployment.provided:
            self._populate_event_deployment(
                service.events, deployment.provided['events'])
            self._populate_method_deployment(
                service.methods, deployment.provided['methods'])
            self._populate_field_deployment(
                service.fields, deployment.provided['fields'])
            self._populate_eventgrp_deployment(
                deployment,
                deployment.provided["event_groups"])
