#  --------------------------------------------------------------------------
#  |              _    _ _______     .----.      _____         _____        |
#  |         /\  | |  | |__   __|  .  ____ .    / ____|  /\   |  __ \       |
#  |        /  \ | |  | |  | |    .  / __ \ .  | (___   /  \  | |__) |      |
#  |       / /\ \| |  | |  | |   .  / / / / v   \___ \ / /\ \ |  _  /       |
#  |      / /__\ \ |__| |  | |   . / /_/ /  .   ____) / /__\ \| | \ \       |
#  |     /________\____/   |_|   ^ \____/  .   |_____/________\_|  \_\      |
#  |                              . _ _  .                                  |
#  --------------------------------------------------------------------------
#
#  All Rights Reserved.
#  Any use of this source code is subject to a license agreement with the
#  AUTOSAR development cooperation.
#  More information is available at www.autosar.org.
#
#  Disclaimer
#
#  This work (specification and/or software implementation) and the material
#  contained in it, as released by AUTOSAR, is for the purpose of information
#  only. AUTOSAR and the companies that have contributed to it shall not be
#  liable for any use of the work.
#
#  The material contained in this work is protected by copyright and other
#  types of intellectual property rights. The commercial exploitation of the
#  material contained in this work requires a license to such intellectual
#  property rights.
#
#  This work may be utilized or reproduced without any modification, in any
#  form or by any means, for informational purposes only. For any other
#  purpose, no part of the work may be utilized or reproduced, in any form
#  or by any means, without permission in writing from the publisher.
#
#  The work has been developed for automotive applications only. It has
#  neither been developed, nor tested for non-automotive applications.
#
#  The word AUTOSAR and the AUTOSAR logo are registered trademarks.
#  --------------------------------------------------------------------------

"""
ARXML parser tests.
"""

import unittest
import os

import generator.parser
from generator.parser.parser import Parser


class ParserTest(unittest.TestCase):
    """
    Testing the parser class, including the mapping that is needed
    """
    def setUp(self):
        """
        Setup Method for all tests in this class
        """
        self.file_directory = os.path.dirname(os.path.realpath(__file__))
        self.radarfusion_arxml_path = os.path.join(self.file_directory, "data",
                                                   "radarfusion.arxml")

    def test_find_simple_short_name(self):
        """
        Test whether we can simple find a package by its short name
        """
        arxml_parser = Parser()
        tree = arxml_parser.parse(self.radarfusion_arxml_path)

        self.assertEqual(tree.find_referable('ara').SHORT_NAME, "ara")

    def test_find_short_name_with_path(self):
        """
        Test whether we can use the short name and its namespace to identify a
        package
        """
        arxml_parser = Parser()
        tree = arxml_parser.parse(self.radarfusion_arxml_path)

        self.assertEqual(tree.find_referable(
            'ara/stdtypes/Boolean').SHORT_NAME, "Boolean")

    def test_find_short_name_relative(self):
        """
        Test whether we can use find_referable also relative
        """
        arxml_parser = Parser()
        tree = arxml_parser.parse(self.radarfusion_arxml_path)
        self.assertEqual(
            tree.AR_PACKAGES.AR_PACKAGE.AR_PACKAGES.
            find_referable('stdtypes').SHORT_NAME, "stdtypes"
        )

    def test_name_space_model(self):
        """
        Test whether we get our custom object from objectify
        """
        arxml_parser = Parser()
        tree = arxml_parser.parse(self.radarfusion_arxml_path)
        app = tree.find(
            './/' + generator.parser.AR_NAMESPACE +
            'ADAPTIVE-APPLICATION-SW-COMPONENT-TYPE')
        self.assertEqual(app.get_application_name(), 'fusion')
        self.assertEqual(app.SHORT_NAME, 'fusion')
