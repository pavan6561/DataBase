#  --------------------------------------------------------------------------
#  |              _    _ _______     .----.      _____         _____        |
#  |         /\  | |  | |__   __|  .  ____ .    / ____|  /\   |  __ \       |
#  |        /  \ | |  | |  | |    .  / __ \ .  | (___   /  \  | |__) |      |
#  |       / /\ \| |  | |  | |   .  / / / / v   \___ \ / /\ \ |  _  /       |
#  |      / /__\ \ |__| |  | |   . / /_/ /  .   ____) / /__\ \| | \ \       |
#  |     /________\____/   |_|   ^ \____/  .   |_____/________\_|  \_\      |
#  |                              . _ _  .                                  |
#  --------------------------------------------------------------------------
#
#  All Rights Reserved.
#  Any use of this source code is subject to a license agreement with the
#  AUTOSAR development cooperation.
#  More information is available at www.autosar.org.
#
#  Disclaimer
#
#  This work (specification and/or software implementation) and the material
#  contained in it, as released by AUTOSAR, is for the purpose of information
#  only. AUTOSAR and the companies that have contributed to it shall not be
#  liable for any use of the work.
#
#  The material contained in this work is protected by copyright and other
#  types of intellectual property rights. The commercial exploitation of the
#  material contained in this work requires a license to such intellectual
#  property rights.
#
#  This work may be utilized or reproduced without any modification, in any
#  form or by any means, for informational purposes only. For any other
#  purpose, no part of the work may be utilized or reproduced, in any form
#  or by any means, without permission in writing from the publisher.
#
#  The work has been developed for automotive applications only. It has
#  neither been developed, nor tested for non-automotive applications.
#
#  The word AUTOSAR and the AUTOSAR logo are registered trademarks.
#  --------------------------------------------------------------------------

# pylint: disable=too-many-lines,too-many-public-methods
import logging
import sys
from generator.parser.exception_handling import handle_method_exceptions

from generator.parser import parser
from generator.intermediate_model.execution_management.machine import Machine
from generator.intermediate_model.execution_management.process import Process
from generator.intermediate_model.execution_management.executable import \
    Executable
from generator.intermediate_model.execution_management.component import \
    Component
from generator.intermediate_model.communication_management.service import \
    Service
# pylint: enable=line-too-long
from generator.parser.merge import merge_files
from generator.parser.merge import to_string
from generator.parser.autosar_mapping import AUTOSARMapping, PathError
from generator.views.machine_view import MachineView
from generator.views.component_view import ComponentView
from generator.parser.tree_helper import get_element, get_element_or_die, get_element_or_none, to_list, to_str, to_nanoseconds
from generator.parser.interface_builder import InterfaceBuilder
from generator.parser.network_binding_builder import NetworkBindingBuilder


# Application tags
_APPL_TYPE_TREF = "APPLICATION-TYPE-TREF"
_ADAPTIVE_APPL_TYPE = "ADAPTIVE-APPLICATION-SW-COMPONENT-TYPE"
_PTM_MAPPINGS = "PROCESS-TO-MACHINE-MAPPING"
_STM_MAPPINGS = "SOMEIP-SERVICE-INSTANCE-TO-MACHINE-MAPPING"
_STP_MAPPINGS = "SERVICE-INSTANCE-TO-PORT-PROTOTYPE-MAPPING"

'''
    naming convention we are trying to use (especially in parameter lists):
    1) Entities from ARXMLs should have ar_ prefix
    2) Entities representing views should have _view suffix
'''

class DefaultParser(parser.Parser):
    """
    Handles parsing the ARXML and providing the intermediate model that it
    represents.
    """

    def __init__(self, model, package_path_fallback=False):
        super().__init__()
        if isinstance(model, AUTOSARMapping):
            self.model = model
        else:
            self.model = self.parse(to_string(merge_files(model)))

        self.namespace = "{http://autosar.org/schema/r4.0}"
        self._name = "arxml_tree"
        self._log = logging.getLogger(__name__)
        self._package_path_fallback = package_path_fallback

        self._interface_builder = InterfaceBuilder(self.model, self._package_path_fallback)
        self._network_binding_builder = NetworkBindingBuilder(self.model)

    def read_em_info(self, ar_process):

        result = {"platform_application": None, "timer_granularity": None}
        ar_executable_ref = get_element_or_die(ar_process, "EXECUTABLE-REF")
        ar_executable = self.model.find_referable(ar_executable_ref.text)
        ar_category = get_element_or_none(ar_executable, "CATEGORY")
        ar_timer_granularity = get_element_or_none(ar_executable, "MINIMUM-TIMER-GRANULARITY")
        if ar_category:
            result["platform_application"] = ar_category.text.upper() == "PLATFORM_LEVEL"
        if ar_timer_granularity:
            result["timer_granularity"] = int(float(ar_timer_granularity.text))


        ar_md_startup_configs = get_element_or_none(ar_process, "MODE-DEPENDENT-STARTUP-CONFIGS/MODE-DEPENDENT-STARTUP-CONFIG")
        ar_md_startup_configs = to_list(ar_md_startup_configs)
        startup_configs = []
        for ar_md_startup_config in ar_md_startup_configs:

            dependencies = []
            ar_exec_dependencies = get_element_or_none(ar_md_startup_config, "EXECUTION-DEPENDENCYS/EXECUTION-DEPENDENCY")
            ar_exec_dependencies = to_list(ar_exec_dependencies)
            for ar_exec_dependency in ar_exec_dependencies:
                ar_mode_group_ref = get_element_or_die(ar_exec_dependency, "PROCESS-MODE-IREF/CONTEXT-MODE-DECLARATION-GROUP-PROTOTYPE-REF")
                ar_mode_ref = get_element_or_die(ar_exec_dependency, "PROCESS-MODE-IREF/TARGET-MODE-DECLARATION-REF")
                ar_mode = self.model.find_referable(ar_mode_ref.text)
                mode = ar_mode.SHORT_NAME
                process_ref = self.model.parent(ar_mode_group_ref.text)
                ar_process = self.model.find_referable(process_ref)
                process = ar_process.SHORT_NAME
                dependencies.append({"process": process, "mode": mode})

            fg_modes = []
            machine_states = []
            ar_fg_modes = get_element_or_none(ar_md_startup_config, "FUNCTION-GROUP-MODE-IREFS/FUNCTION-GROUP-MODE-IREF")
            ar_fg_modes = to_list(ar_fg_modes)
            for ar_fg_mode in ar_fg_modes:
                ar_mode_group_ref = get_element_or_die(ar_fg_mode, "CONTEXT-MODE-DECLARATION-GROUP-PROTOTYPE-REF")
                ar_mode_ref = get_element_or_die(ar_fg_mode, "TARGET-MODE-DECLARATION-REF")
                ar_mode_group = self.model.find_referable(ar_mode_group_ref.text)
                ar_mode = self.model.find_referable(ar_mode_ref.text)
                mode = ar_mode.SHORT_NAME
                mode_group = ar_mode_group.SHORT_NAME
                if mode_group == "MachineState":
                    machine_states.append(mode)
                else:
                    fg_modes.append({"mode_group": mode_group, "mode": mode})

            resource_group = None
            ar_resource_group_ref = get_element_or_none(ar_md_startup_config, "RESOURCE-GROUP-REF")
            if ar_resource_group_ref:
                ar_resource_group = self.model.find_referable(ar_resource_group_ref.text)
                resource_group = ar_resource_group.SHORT_NAME

            scheduling_policy = None
            scheduling_priority = None
            environment_vars = []
            arguments = []
            ar_startup_config_ref = get_element_or_none(ar_md_startup_config, "STARTUP-CONFIG-REF")
            if ar_startup_config_ref:
                ar_startup_config = self.model.find_referable(ar_startup_config_ref.text)
                scheduling_policy = to_str(get_element_or_none(ar_startup_config, "SCHEDULING-POLICY"))
                scheduling_priority = to_str(get_element_or_none(ar_startup_config, "SCHEDULING-PRIORITY"))

                # schema v45 does not have ENVIRONMENT-VARIABLES, just keep the list empty

                ar_args = get_element_or_none(ar_startup_config, "STARTUP-OPTIONS/STARTUP-OPTION")
                ar_args = to_list(ar_args)
                for ar_arg in ar_args:
                    kind = ar_arg.OPTION_KIND
                    long_form = kind == "COMMAND-LINE-LONG-FORM"
                    arg = to_str(get_element_or_none(ar_arg, "OPTION-ARGUMENT"))
                    name = to_str(get_element_or_none(ar_arg, "OPTION-NAME"))
                    arguments.append({"long_form": long_form, "arg": arg, "name": name})

            md_startup_config = {
                "dependencies": dependencies,
                "fg_modes": fg_modes,
                "machine_states": machine_states,
                "resource_group": resource_group,
                "scheduling_policy": scheduling_policy,
                "scheduling_priority": scheduling_priority,
                "environment_vars": environment_vars,
                "arguments": arguments,
            }

            startup_configs.append(md_startup_config)

        result["startup_configs"] = startup_configs
        #-----------------
        states = []
        mode_machine = None
        ar_mode_machine_ref = get_element_or_none(ar_process, "PROCESS-MODE-MACHINE/TYPE-TREF")
        if ar_mode_machine_ref:
            ar_mode_machine = self.model.find_referable(ar_mode_machine_ref.text)
            mode_machine = ar_mode_machine.SHORT_NAME
            ar_modes = get_element_or_none(ar_mode_machine, "MODE-DECLARATIONS/MODE-DECLARATION")
            ar_modes = to_list(ar_modes)
            for ar_mode in ar_modes:
                states.append(ar_mode.SHORT_NAME)
        result["application_states"] = {"mode_machine": mode_machine, "states": states}
        #-----------------
        return result

    def read_timeout(self, ar_timeout):
        ar_enter_timeout = get_element_or_none(ar_timeout, "ENTER-TIMEOUT-VALUE")
        ar_exit_timeout = get_element_or_none(ar_timeout, "EXIT-TIMEOUT-VALUE")
        return {
            "enter_timeout_ns": to_nanoseconds(ar_enter_timeout),
            "exit_timeout_ns": to_nanoseconds(ar_exit_timeout)
        }

    def read_machine_em_info(self, ar_machine):
        result = {}
        ar_default_timeout = get_element_or_none(ar_machine, "DEFAULT-APPLICATION-TIMEOUT")
        result["default"] = self.read_timeout(ar_default_timeout)

        fg_states = {}
        machine_states = []
        ar_timeouts = get_element_or_none(ar_machine, "PER-STATE-TIMEOUTS/PER-STATE-TIMEOUT")
        ar_timeouts = to_list(ar_timeouts)
        for ar_timeout in ar_timeouts:
            state_name = "ERROR! no reference to state declaration"
            state_group = "ERROR! unable to deduce group by state"
            ar_state_declaration_ref = get_element_or_none(ar_timeout, "STATE-REF")
            if ar_state_declaration_ref:
                group_fqn = self.model.parent(ar_state_declaration_ref.text)
                ar_group_declaration = self.model.find_referable(group_fqn)
                ar_state_declaration = self.model.find_referable(ar_state_declaration_ref.text)
                state_group = ar_group_declaration.SHORT_NAME
                state_name = ar_state_declaration.SHORT_NAME

            ar_state_timeout = get_element_or_none(ar_timeout, "TIMEOUT")

            state_description = {"state_name": state_name, "timeout": self.read_timeout(ar_state_timeout)}

            if state_group == "MachineState":
                machine_states.append(state_description)
            else:
                if state_group in fg_states:
                    fg_states[state_group].append(state_description)
                else:
                    fg_states[state_group] = [state_description]

        result["machine_states"] = sorted(machine_states, key = lambda x: x["state_name"])
        flat_fg_states = []
        for (key, value) in fg_states.items():
            value.sort(key = lambda x: x["state_name"])
            flat_fg_states.append({"function_group": key, "states": value})
        result["fg_states"] = sorted(flat_fg_states, key = lambda x: x["function_group"])

        resource_groups = []
        ar_os_instantiations = get_element_or_none(ar_machine, "MODULE-INSTANTIATIONS/OS-MODULE-INSTANTIATION")
        ar_os_instantiations = to_list(ar_os_instantiations)
        for ar_os_instantiation in ar_os_instantiations:
            ar_resource_groups = get_element_or_none(ar_os_instantiation, "RESOURCE-GROUPS/RESOURCE-GROUP")
            ar_resource_groups = to_list(ar_resource_groups)
            for ar_resource_group in ar_resource_groups:
                resource_groups.append({
                    "name": ar_resource_group.SHORT_NAME,
                    "cpu_usage": ar_resource_group.CPU_USAGE,
                    "mem_usage": ar_resource_group.MEM_USAGE
                })

        result["resource_groups"] = sorted(resource_groups, key = lambda x: x["name"])

        return result

    def get_processes(self, ar_machine):
        """Get the processes contained in a ar_machine"""
        ar_processes = []

        # Get the Process To Machine Mapping.
        proc_to_machine_mappings = self.model.find_elements_of_type(_PTM_MAPPINGS, MACHINE_REF=ar_machine.get_fqn())

        # If Process To Machine Mapping is given as Input.
        if proc_to_machine_mappings:
            for mapping in proc_to_machine_mappings:
                try:
                    ar_process = self.model.find_referable(mapping.PROCESS_REF)
                except PathError:
                    self._log.warning("PROCESS Ref {} used in machine {} is not found! Mapping will be ignored".
                                      format(mapping.PROCESS_REF, ar_machine))
                    continue

                ar_processes.append(ar_process)
        else:
            # Deduce the Process to Machine Mapping from SOMEIP-SERVICE-INSTANCE-TO-MACHINE-MAPPING &
            # SERVICE-INSTANCE-TO-PORT-PROTOTYPE-MAPPING
            self._log.warning("No PROCESS-TO-MACHINE-MAPPING is found in input data, trying to find Processes "
                              "for Machine {} ...".format(ar_machine))
            machine_design = self.get_machine_design(ar_machine)

            if machine_design is not None:
                communication_connector_fqn = self._get_communication_connector(machine_design).get_fqn()

                # Get the SOME/IP to Machine Mappings that match the communication connector of the current machine.
                self._log.debug("Getting SOME/IP to Machine Mappings that match the communication connector {}".
                                format(communication_connector_fqn))
                someip_to_machine_mappings = \
                    self.model.find_elements_of_type(_STM_MAPPINGS,
                                                     COMMUNICATION_CONNECTOR_REF=communication_connector_fqn)

                for someip_to_machine_mapping in someip_to_machine_mappings:
                    # Get the Service To Port Prototype Mappings that match the SERVICE INTERFACES
                    # of SOME/IP To Machines.
                    self._log.debug("Getting Service Instance To Port Prototype Mappings that match "
                                    "the Service Interface {}".format(someip_to_machine_mapping.SERVICE_INSTANCE_REF))
                    service_to_port_mappings = \
                        self.model.find_elements_of_type(_STP_MAPPINGS,
                                                         SERVICE_INSTANCE_REF=
                                                         someip_to_machine_mapping.SERVICE_INSTANCE_REF)
                    if service_to_port_mappings:
                        try:
                            self._log.debug("Getting the Process {} which maps to Machine {}"
                                            .format(service_to_port_mappings[0].PROCESS_REF,
                                                    ar_machine.get_fqn()))
                            ar_process = self.model.find_referable(service_to_port_mappings[0].PROCESS_REF)
                        except PathError:
                            self._log.warning("PROCESS Ref {} used in {} is not found! Mapping will be ignored"
                                              .format(service_to_port_mappings[0].PROCESS_REF,
                                                      service_to_port_mappings[0].SHORT_NAME))
                            continue

                        ar_processes.append(ar_process)

        processes = [Process(fqn=ar_process.get_fqn(),
                             executable=self.get_executable(ar_process),
                             em_info = self.read_em_info(ar_process))
                     for ar_process in ar_processes]

        if not processes:
            self._log.warning("No processes found for the Machine {}".format(ar_machine))
        else:
            self._log.debug("Processes {} are found for Machine {}".format(processes, ar_machine))

        return processes

    @handle_method_exceptions(error_string_template="{exception_text}")
    def get_machine_design(self, machine):
        machine_design_refs = machine.find_elements_of_type('MACHINE-DESIGN-REF',
                                                            DEST='MACHINE-DESIGN')

        if machine_design_refs is None:
            self._log.error("No MachineDesignRefs found for %s!", machine.name())
        elif len(machine_design_refs) > 1:
            self._log.warning("More than one MACHINE-DESIGN-REF found for %s! The first match is used", machine.name())

        return self.model.find_referable(str(machine_design_refs[0]))

    @handle_method_exceptions(error_string_template="{exception_text}")
    def get_unicast_address(self, machine):
        """ Returns unicast address: ip address and network mask """
        unicast_ref = get_element_or_die(machine,
                                  "COMMUNICATION-CONNECTORS"
                                  "/ETHERNET-COMMUNICATION-CONNECTOR"
                                  "/UNICAST-NETWORK-ENDPOINT-REF")
        endpoint_info = self.model.find_referable(unicast_ref.text)
        ip_address = get_element_or_die(endpoint_info,
                                 "NETWORK-ENDPOINT-ADDRESSES"
                                 "/IPV-4-CONFIGURATION"
                                 "/IPV-4-ADDRESS")
        netmask = get_element_or_die(endpoint_info,
                                 "NETWORK-ENDPOINT-ADDRESSES"
                                 "/IPV-4-CONFIGURATION"
                                 "/NETWORK-MASK")
        return {'ip-address': ip_address.text, 'netmask': netmask.text}

    @handle_method_exceptions(error_string_template="{exception_text}")
    def get_sd_ip(self, machine):
        """ Returns multicast (service discovery) ip address """
        multicast_sd_ref = get_element_or_die(machine,
                                       "SERVICE-DISCOVER-CONFIGS"
                                       "/SOMEIP-SERVICE-DISCOVERY"
                                       "/MULTICAST-SD-IP-ADDRESS-REF")
        endpoint_info = self.model.find_referable(multicast_sd_ref.text)
        ip_address = get_element_or_die(endpoint_info,
                                 "NETWORK-ENDPOINT-ADDRESSES"
                                 "/IPV-4-CONFIGURATION"
                                 "/IPV-4-ADDRESS")
        return ip_address.text

    @handle_method_exceptions(error_string_template="{exception_text}")
    def get_sd_port(self, machine):  # pylint: disable=no-self-use
        """ Returns service discovery port number """
        sd_port = get_element_or_die(machine,
                              "SERVICE-DISCOVER-CONFIGS"
                              "/SOMEIP-SERVICE-DISCOVERY"
                              "/SOMEIP-SERVICE-DISCOVERY-PORT")
        return sd_port.text

    def get_executable(self, ar_process):
        """Get the executables related to a process"""
        ar_executable = self.model.find_referable(ar_process.EXECUTABLE_REF)
        executable = Executable(ar_process.SHORT_NAME)
        for component in self.get_components(ar_executable=ar_executable):
            executable.add_component(component)
        return executable

    def get_components(self, ar_executable=None, components_list=None):
        """Get the adaptive autosar applications belonging to an executable or components specified in a list of
         components names or all if nothing is set"""
        if ar_executable is not None:
            ar_component_refs = ar_executable.find_elements_of_type(_APPL_TYPE_TREF, DEST=_ADAPTIVE_APPL_TYPE)
        else:
            ar_component_refs = self.model.find_elements_of_type(_ADAPTIVE_APPL_TYPE)

        ar_components = []
        for component_ref in ar_component_refs:
            ar_component = self.model.find_referable(str(component_ref))
            if components_list is None or ar_component.get_fqn() in components_list or \
                            ar_component.SHORT_NAME in components_list:
                ar_components.append(ar_component)

        components = [Component(ar_component.SHORT_NAME, ar_component.get_fqn()) for ar_component in ar_components]
        for ar_component, component in zip(ar_components, components):
            for provided_service in self._get_provided_services(
                    ar_component.PORTS):
                component.add_provided_service(provided_service)
            for required_service in self._get_required_services(
                    ar_component.PORTS):
                component.add_required_service(required_service)
        return components

    def _get_communication_connector(self, machine):
        communication_connector = get_element_or_die(machine,
                                              "COMMUNICATION-CONNECTORS"
                                              "/ETHERNET-COMMUNICATION-CONNECTOR")
        return communication_connector

    def _get_provided_services(self, ar_ports):
        """Extract provided services from ports"""
        ar_p_ports = ar_ports.find_elements_of_type('P-PORT-PROTOTYPE')
        services = list()
        for ar_port in ar_p_ports:
            ar_provided_interface_refs = ar_port.find_elements_of_type(
                'PROVIDED-INTERFACE-TREF',
                DEST='SERVICE-INTERFACE')
            ar_provided_interfaces = [
                self.model.find_referable(str(interface_ref))
                for interface_ref in ar_provided_interface_refs]
            provided_services = [Service(str(ar_provided_interface))
                                 for ar_provided_interface in
                                 ar_provided_interfaces]
            for ar_interface, service in zip(ar_provided_interfaces,
                                             provided_services):
                self._interface_builder.populate_interface(ar_interface, service)
                service_deployments = self._network_binding_builder.get_provided_svc_deployments(
                    ar_port)
                if len(service_deployments) is not 0:
                    self._log.trace("Provided Service info %s", service_deployments[0].provided)
                    self._network_binding_builder.populate_deployment(service, service_deployments[0])
                    service.service_deployment = service_deployments[0]
                else:
                    self._log.warning("At least one P-deployment must exist for '{}'".format(ar_port.get_fqn()))
            services.extend(provided_services)
        return services

    def _get_required_services(self, ar_ports):
        """ Extract required services from ports"""
        ar_p_ports = ar_ports.find_elements_of_type('R-PORT-PROTOTYPE')
        services = list()
        for ar_port in ar_p_ports:
            ar_required_interface_refs = ar_port.find_elements_of_type(
                'REQUIRED-INTERFACE-TREF',
                DEST='SERVICE-INTERFACE')
            ar_required_interfaces = [
                self.model.find_referable(str(interface_ref))
                for interface_ref in ar_required_interface_refs]
            required_services = [Service(str(ar_required_interface))
                                 for ar_required_interface in
                                 ar_required_interfaces]
            for ar_interface, service in zip(ar_required_interfaces,
                                             required_services):
                self._interface_builder.populate_interface(ar_interface, service)
                service_deployments = self._network_binding_builder.get_required_svc_deployments(
                    ar_port)
                if len(service_deployments) is not 0:
                    self._log.trace("Required Service info %s", service_deployments[0].required)
                    self._network_binding_builder.populate_deployment(service, service_deployments[0])
                    service.service_deployment = service_deployments[0]
                else:
                    self._log.warning("At least one R-deployment must exist for '{}'".format(ar_port.get_fqn()))

            services.extend(required_services)
        return services

    def _get_components_views(self, components_list=None):
        """Get a list of all components in the model wrapped in ComponentViews if no specific Components List
        is provided"""
        components = [ComponentView(component) for component in self.get_components(components_list=components_list)]
        return components

    def _get_machines_views(self, machines_list=None):
        """Get a list of all machines in the model wrapped in MachineViews if no specific Machines List
        is provided"""
        """Get a list of all machines in the model wrapped in MachineViews"""
        log = logging.getLogger(__name__)
        ar_machines = self.model.find_elements_of_type('MACHINE')

        machine_views = []
        for ar_machine in ar_machines:
            if machines_list is None or ar_machine.get_fqn() in machines_list or ar_machine.SHORT_NAME in machines_list:
                machine = Machine(ar_machine.get_fqn(), em_info = self.read_machine_em_info(ar_machine))
                processes = self.get_processes(ar_machine)
                for process in processes:
                    machine.add_process(process)

                ar_machine_design = self.get_machine_design(ar_machine)
                if ar_machine_design is not None:
                    unicast_addr = self.get_unicast_address(ar_machine_design)
                    machine.ip_address = unicast_addr["ip-address"]
                    machine.network_mask = unicast_addr["netmask"]
                    machine.sd_address = self.get_sd_ip(ar_machine_design)
                    machine.sd_port = self.get_sd_port(ar_machine_design)

                machine_view = MachineView(machine)
                machine_views.append(machine_view)

        return machine_views

    def _find_target_machines_or_abort(self, machines):
        target_machines_fqn = []
        unrecognized_machines = []

        for machine in machines:
            machine_name = machine.split("/")[-1]
            ar_machine = self.model.find_elements_of_type('MACHINE', SHORT_NAME=machine_name)

            if len(ar_machine) > 0:
                self._log.debug("Target machine %s is found", machine)
                target_machines_fqn.append(ar_machine[0].get_fqn())
            else:
                self._log.error("Target machine %s is not found!", machine)
                unrecognized_machines.append(machine)

        if unrecognized_machines:
            self._log.error("Generation failed for unrecognized machines %s!", unrecognized_machines)
            sys.exit("Generation failed for unrecognized machines {0}! Possible machines are {1}".format(
                unrecognized_machines,
                self.get_machines_fqn()))

        return target_machines_fqn

    def _find_target_applications_or_abort(self, applications):
        target_applications_fqn = []
        unrecognized_applications = []

        for application in applications:
            application_name = application.split("/")[-1]
            ar_application = self.model.find_elements_of_type(_ADAPTIVE_APPL_TYPE, SHORT_NAME=application_name)

            if len(ar_application) > 0:
                self._log.debug("Target application %s is found", application)
                target_applications_fqn.append(ar_application[0].get_fqn())
            else:
                self._log.error("Target application %s is not found!", application)
                unrecognized_applications.append(application)

        if unrecognized_applications:
            self._log.error("Generation failed for unrecognized applications %s!", unrecognized_applications)
            sys.exit("Generation failed for unrecognized applications {0}! Possible applications are {1}".format(
                unrecognized_applications,
                self.get_adaptive_applications_fqn()))

        return target_applications_fqn


    def get_machines_fqn(self):
        """Get a list of all machines fqn."""
        ar_machines = self.model.find_elements_of_type('MACHINE')
        return [machine.get_fqn() for machine in ar_machines]

    def get_adaptive_applications_fqn(self):
        """Get a list of all Adaptive Applications fqn."""
        ar_applications = self.model.find_elements_of_type(_ADAPTIVE_APPL_TYPE)
        return [ar_application.get_fqn() for ar_application in ar_applications]

    def create_intermediate_model(self, machines=None, applications=None):
        """
        Assuming that the ARXML is parsed, will build and provide the
        intermediate model.
        :returns: Dictionary of keys machines and components and their values as list of MachineViews and
        ComponentViews.
        """
        # TODO: The intermediate Model is assuming the EM is the start point for the generation as
        # TODO: Machine => Process => Executable => Component. There are cases when the EM is not needed and the user
        # TODO: is interested in generating the Component's (Application) Service Interfaces (i.e. Testing,
        # TODO: having manual Configuration, etc...). Thus, a new mode is needed where the start point is the
        # TODO: Application only. This mode is used when the user specifies the cmd line arg --applications.
        # TODO: This part is not optimum and could optimized as the the return will be a list MachineViews which
        # TODO: aggregates the ComponentViews for that Machine but also the return has a List of all ComponentViews
        # TODO: in the input. The relation between them should be decoupled to have an efficient design.

        # It's assumed that --applications and --machines cannot be used together.
        components = None
        # If the user has provided a list of applications, then generate for these applications.
        if applications is not None:
            # Find the target applications or abort
            target_applications = self._find_target_applications_or_abort(applications)

            # If Target Applications are found return the intermediate model with the required applications.
            if len(target_applications) > 0:
                components = self._get_components_views(target_applications)
        else:
            # If no applications are required, default mode is generate for machines.
            target_machines = None

            # If the user has set a specific target machines using all --machines
            if machines:
                # Find the target applications or abort
                target_machines = self._find_target_machines_or_abort(machines)
            # Generate for target_machines or all if none specified.
            machines = self._get_machines_views(target_machines)


        model = {"machines": machines, "components": components, "errors": self._interface_builder.get_error_domain_views()}
        return model

    @property
    def name(self):
        """Name of this parser"""
        return self._name
