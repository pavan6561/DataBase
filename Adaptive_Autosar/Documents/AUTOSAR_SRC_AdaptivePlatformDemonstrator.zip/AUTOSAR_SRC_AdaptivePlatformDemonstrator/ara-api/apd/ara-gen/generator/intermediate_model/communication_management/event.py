#  --------------------------------------------------------------------------
#  |              _    _ _______     .----.      _____         _____        |
#  |         /\  | |  | |__   __|  .  ____ .    / ____|  /\   |  __ \       |
#  |        /  \ | |  | |  | |    .  / __ \ .  | (___   /  \  | |__) |      |
#  |       / /\ \| |  | |  | |   .  / / / / v   \___ \ / /\ \ |  _  /       |
#  |      / /__\ \ |__| |  | |   . / /_/ /  .   ____) / /__\ \| | \ \       |
#  |     /________\____/   |_|   ^ \____/  .   |_____/________\_|  \_\      |
#  |                              . _ _  .                                  |
#  --------------------------------------------------------------------------
#
#  All Rights Reserved.
#  Any use of this source code is subject to a license agreement with the
#  AUTOSAR development cooperation.
#  More information is available at www.autosar.org.
#
#  Disclaimer
#
#  This work (specification and/or software implementation) and the material
#  contained in it, as released by AUTOSAR, is for the purpose of information
#  only. AUTOSAR and the companies that have contributed to it shall not be
#  liable for any use of the work.
#
#  The material contained in this work is protected by copyright and other
#  types of intellectual property rights. The commercial exploitation of the
#  material contained in this work requires a license to such intellectual
#  property rights.
#
#  This work may be utilized or reproduced without any modification, in any
#  form or by any means, for informational purposes only. For any other
#  purpose, no part of the work may be utilized or reproduced, in any form
#  or by any means, without permission in writing from the publisher.
#
#  The work has been developed for automotive applications only. It has
#  neither been developed, nor tested for non-automotive applications.
#
#  The word AUTOSAR and the AUTOSAR logo are registered trademarks.
#  --------------------------------------------------------------------------

"""
Event class.
"""

from ..types.impl_type import ImplDataType


class Event(object):
    """Describes an Event in a Service"""

    def __init__(self, name, impl_type=None, event_deployment=None):
        if name == "":
            raise AttributeError("An event must have a name")
        self._name = name
        self._impl_type = impl_type
        self._event_deployment = event_deployment

    @property
    def impl_type(self):
        """Get the ImplDataType of the Event."""
        return self._impl_type

    @impl_type.setter
    def impl_type(self, event_type: ImplDataType):
        """Set the ImplDataType of the Event."""
        self._impl_type = event_type

    @property
    def event_deployment(self):
        """Get the deployment of the Event."""
        return self._event_deployment

    @event_deployment.setter
    def event_deployment(self, event_deployment):
        """Set the event deployment of this Event."""
        self._event_deployment = event_deployment

    @property
    def name(self):
        """Get the name of the Event."""
        return self._name

    @name.setter
    def name(self, name: str):
        """Set the name of the Event."""
        self._name = name
