// --------------------------------------------------------------------------
// |              _    _ _______     .----.      _____         _____        |
// |         /\  | |  | |__   __|  .  ____ .    / ____|  /\   |  __ \       |
// |        /  \ | |  | |  | |    .  / __ \ .  | (___   /  \  | |__) |      |
// |       / /\ \| |  | |  | |   .  / / / / v   \___ \ / /\ \ |  _  /       |
// |      / /__\ \ |__| |  | |   . / /_/ /  .   ____) / /__\ \| | \ \       |
// |     /________\____/   |_|   ^ \____/  .   |_____/________\_|  \_\      |
// |                              . _ _  .                                  |
// --------------------------------------------------------------------------
//
// All Rights Reserved.
// Any use of this source code is subject to a license agreement with the
// AUTOSAR development cooperation.
// More information is available at www.autosar.org.
//
// Disclaimer
//
// This work (specification and/or software implementation) and the material
// contained in it, as released by AUTOSAR, is for the purpose of information
// only. AUTOSAR and the companies that have contributed to it shall not be
// liable for any use of the work.
//
// The material contained in this work is protected by copyright and other
// types of intellectual property rights. The commercial exploitation of the
// material contained in this work requires a license to such intellectual
// property rights.
//
// This work may be utilized or reproduced without any modification, in any
// form or by any means, for informational purposes only. For any other
// purpose, no part of the work may be utilized or reproduced, in any form
// or by any means, without permission in writing from the publisher.
//
// The work has been developed for automotive applications only. It has
// neither been developed, nor tested for non-automotive applications.
//
// The word AUTOSAR and the AUTOSAR logo are registered trademarks.
// --------------------------------------------------------------------------

#ifndef franca_sample_vsomeip_vsomeip_service_mapping_FrancaSample_cpp
#define franca_sample_vsomeip_vsomeip_service_mapping_FrancaSample_cpp

#include "ara/com/internal/vsomeip/vsomeip_service_mapping.h"
#include "ara/com/internal/vsomeip/vsomeip_service_mapping_impl.h"

#include "adapter_flaveratestbookend1.h"
#include "adapter_flaveratesttestbookend2.h"
#include "adapter_flaverbtestbookend1.h"
#include "adapter_flaverbtesttestbookend2.h"

namespace ara {
namespace com {
namespace internal {
namespace vsomeip {
namespace runtime {

namespace {

ServiceMappingImpl<
  ::flaverATestBookend1::service_id,
  ::flaveratestbookend1_binding::vsomeip::descriptors::internal::Service::service_id,
  NoProxy,
  ::flaveratestbookend1_binding::vsomeip::flaverATestBookend1ServiceAdapter
> flaveratestbookend1__mapping;

ServiceMappingImpl<
  ::flaverATesttestBookend2::service_id,
  ::flaveratesttestbookend2_binding::vsomeip::descriptors::internal::Service::service_id,
  NoProxy,
  ::flaveratesttestbookend2_binding::vsomeip::flaverATesttestBookend2ServiceAdapter
> flaveratesttestbookend2__mapping;

ServiceMappingImpl<
  ::flaverBTestBookend1::service_id,
  ::flaverbtestbookend1_binding::vsomeip::descriptors::internal::Service::service_id,
  NoProxy,
  ::flaverbtestbookend1_binding::vsomeip::flaverBTestBookend1ServiceAdapter
> flaverbtestbookend1__mapping;

ServiceMappingImpl<
  ::flaverBTesttestBookend2::service_id,
  ::flaverbtesttestbookend2_binding::vsomeip::descriptors::internal::Service::service_id,
  NoProxy,
  ::flaverbtesttestbookend2_binding::vsomeip::flaverBTesttestBookend2ServiceAdapter
> flaverbtesttestbookend2__mapping;

}

const VSomeIPServiceMapping::Mapping* VSomeIPServiceMapping::GetMappingForServiceId(ServiceId service_id) {
  switch (service_id) {
    case ::flaverATestBookend1::service_id:
      return &flaveratestbookend1__mapping;
    case ::flaverATesttestBookend2::service_id:
      return &flaveratesttestbookend2__mapping;
    case ::flaverBTestBookend1::service_id:
      return &flaverbtestbookend1__mapping;
    case ::flaverBTesttestBookend2::service_id:
      return &flaverbtesttestbookend2__mapping;
    default:
      return nullptr;
  }
}

VSomeIPServiceMapping::MultiMapping VSomeIPServiceMapping::GetMappingForVSomeIPServiceId(::vsomeip::service_t service_id) {
  switch(service_id) {
    case ::flaveratestbookend1_binding::vsomeip::descriptors::internal::Service::service_id:
      return {
        &flaveratestbookend1__mapping,
      };
    case ::flaveratesttestbookend2_binding::vsomeip::descriptors::internal::Service::service_id:
      return {
        &flaveratesttestbookend2__mapping,
      };
    case ::flaverbtestbookend1_binding::vsomeip::descriptors::internal::Service::service_id:
      return {
        &flaverbtestbookend1__mapping,
      };
    case ::flaverbtesttestbookend2_binding::vsomeip::descriptors::internal::Service::service_id:
      return {
        &flaverbtesttestbookend2__mapping,
      };
    default:
      return {};
  }
}

} // namespace runtime
} // namespace vsomeip
} // namespace internal
} // namespace com
} // namespace ara

#endif // franca_sample_vsomeip_vsomeip_service_mapping_FrancaSample_cpp

