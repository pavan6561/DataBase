# Document scope
This document is intended as a guide for developing the ARA generator on a host machine, without a strong need for a Yocto build (besides the versions of the Python 3 modules used for generator development).

The software requires the installation of some prerequisite packages. Some of these are system packages (for instance, the Python interpreter itself), whereas others are additional Python packages (for instance, the "Jinja2" templating system).

This document details how to install all of these, given only a typical Linux development host.

# Development environment setup
An Ubuntu 16.04-like system is assumed for the rest of these instructions. For other systems, the listed packages and dependencies are simply a guideline to be used with the specific package manager of the distro.

#### Initial Development environment setup

These steps have to be done only once for each development host you intend to use:

1.  Install system-wide prerequisites:

        $ sudo apt-get install libxml2-dev libxslt1-dev zlib1g-dev
        $ sudo apt-get install python3.5 python3.5-dev

     Please note that this package list might be different on other Linux distributions, or even on newer versions of Ubuntu.

     An alternative and, arguably, superior way of installing Python is to use [pyenv](https://github.com/pyenv/pyenv) instead of doing it via the distribution's tools such as apt-get. However, that is out of scope of this document.

2. Install pipenv:

        $ sudo python3 -m pip install pipenv

     This is the only Python package that you will have to install into your global Python installation. It offers a system for using "virtual environments", and adds dependency management on top of that.
     All other Python packages should only ever be installed into such a virtual environment. This keeps your global Python installation clean.

3.  Get the source code:

        Copy from AUTOSAR_SRC_AdaptivePlatformDemonstrator.zip where the generator is located at ara-api/apd/ara-gen and enter its directory.

4. Install the dependencies into the virtual environment:

        $ pipenv install --dev

     This command reads the `Pipfile.lock` file, which lists the exact revisions of all Python packages that are needed for both running and developing the software, and installs these into the virtual environment.

     (Background: These revisions have been extracted from the Yocto build, by running these commands in a separate terminal:)

        $ cd /path/to/ara-workspace/poky
        $ source oe-init-build-env
        $ bitbake -s | grep python3-jinja2
        python3-jinja2                                        :2.8-r0

        $ bitbake -s | grep python3-lxml
        nativesdk-python3-lxml                              :3.6.0-r0
        python3-lxml                                        :3.6.0-r0
        python3-lxml-native                                 :3.6.0-r0

5.  Activate the virtual environment:

        $ pyenv shell

6.  Run all tests:

        $ pytest

7.  Activate the git pre-commit hook for style checking:

        $ cd .git/hooks
        $ ln -s ../../scripts/pre-commit

    This will lead to each commit's code being checked for violations of the style guidelines.

#### Continuous development environment setup

And whenever you want to start working on this project, you need to do these steps:

1.  Activate virtual environment in a new subshell:

        $ pyenv shell

    This step is important, so that you are actually using the exact library package versions that are necessary for the generator development.
    With a common shell such as bash, you can see in your command prompt whether your current shell session has an activated virtual environment;
    with an activated virtual environment, it will show its name in the left-most part of the prompt, e.g.:

        (myapp) user@host:~$

    You can also test whether you have done this step by running e.g.:

        $ which python3
        /home/user/.local/share/virtualenvs/generator-abcdefg/bin/python3

    As can be seen, the Python interpreter is taken from within the virtual environment.

2.  Do your work

3.  Ensure that code is PEP8 compliant and conforms to our style guidelines:

        $ scripts/stylecheck.sh

4.  If you have finished, then simply terminate your subshell, e.g. with:

        $ exit
