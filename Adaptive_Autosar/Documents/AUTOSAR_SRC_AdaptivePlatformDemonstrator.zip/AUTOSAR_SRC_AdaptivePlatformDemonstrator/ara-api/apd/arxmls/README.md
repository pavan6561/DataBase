## TOC
1. Folder structure


## 1. Folder structure

The folder structure is:

    arxmls
    ├──


* Folder `arxmls` contains the platform related arxml files
